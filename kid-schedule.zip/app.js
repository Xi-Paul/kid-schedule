/* app.js — 화면과 로직.
 * 저장소 접근은 전부 github.js 의 GH.Repo 를 통합니다.
 * 토큰은 이 파일에 없습니다. 사용자가 설정 탭에서 넣은 값을 localStorage 에서 읽습니다.
 */
"use strict";

/* ===================== 상수 ===================== */
const DOW = ["일", "월", "화", "수", "목", "금", "토"];
const KINDS = [
  { id: "school",  name: "학교",          color: "#3B82F6", emoji: "🏫" },
  { id: "academy", name: "학원",          color: "#A855F7", emoji: "📚" },
  { id: "study",   name: "공부·숙제",     color: "#F59E0B", emoji: "✏️" },
  { id: "sport",   name: "운동",          color: "#10B981", emoji: "⚽" },
  { id: "life",    name: "생활",          color: "#EC4899", emoji: "🪥" },
  { id: "play",    name: "놀이·쉬는 시간", color: "#06B6D4", emoji: "🎮" },
  { id: "read",    name: "독서",          color: "#14B8A6", emoji: "📖" }
];

/* 일정마다 "무엇을 기록할지" 고르는 항목들.
   영어 숙제는 체크만, 수학은 페이지·채점·오답, 독서는 책 제목 — 이런 식으로 씁니다. */
const DETAIL_FIELDS = [
  { id: "pages",  label: "페이지",         type: "range" },   // 몇 쪽 ~ 몇 쪽
  { id: "graded", label: "채점",           type: "bool"  },
  { id: "redo",   label: "오답 다시 풀기", type: "bool"  },
  { id: "book",   label: "읽은 책",        type: "text", placeholder: "책 제목" },
  { id: "listen", label: "듣기",           type: "bool"  },
  { id: "speak",  label: "낭독",           type: "bool"  },
  { id: "words",  label: "단어",           type: "num", unit: "개" },
  { id: "memo",   label: "메모",           type: "text", placeholder: "한 줄" }
];
const detailById = id => DETAIL_FIELDS.find(f => f.id === id);
/** 기본 세부 항목 — 종류만 고르면 알아서 붙습니다 */
const DEFAULT_DETAIL = { read: ["book", "pages"], study: [] };
const kindOf = id => KINDS.find(k => k.id === id) || KINDS[0];

const STATE_LABEL = {
  locked:  "아직",
  todo:    "대기",
  running: "하는 중",
  done:    "완료",
  over:    "시간 초과",
  missed:  "놓침"
};

const LS = {
  conn:   "ks2.conn.v1",     // owner/repo/branch/statusRepo/role
  token:  "ks2.token.v1",
  sched:  "ks2.sched.cache.v1",
  notify: "ks2.notify.v1"
};

/* ===================== 상태 ===================== */
let cfg = null;              // config.json + 로컬 override
let conn = null;             // 접속 설정
let schedRepo = null, statusRepo = null;
let sched = null;            // 일정
let schedSha = null;
let dayKey = "";             // 오늘 YYYY-MM-DD

let who = "";                // 지금 보고 있는 아이 id, 또는 "all"(부모만)
let dayMap = {};             // 아이 id → { date, items }
let dirtyMap = {};           // 아이 id → Set(아직 못 보낸 항목 id)
let dirtyMeta = new Set();   // "내가 정한 것"·회고가 바뀐 아이 id
let flushTimer = null;
let notifyOn = false;
let firedMap = {};
let recCache = null;
let holidays = {};          // "YYYY-MM-DD" → 공휴일 이름
let editing = null;         // 수정 중인 일정 {bucket, id} — null 이면 새로 추가하는 중
let formGeo = null;         // 입력 칸에 올려둔 장소 {lat, lng, radius}

/* ---- 아이 ---- */
const kids = () => (sched && sched.kids) || [];
const kidById = id => kids().find(k => k.id === id) || null;
/** 지금 화면에 걸린 아이들 */
const scopeKids = () => (who === "all" ? kids() : kids().filter(k => k.id === who));
/** 편집·기록처럼 한 명이 정해져야 하는 화면인지 */
const oneKid = () => (who !== "all" && kidById(who)) ? who : null;
const kidTag = e => { const k = kidById(e.kid); return k ? `${k.emoji} ${k.name}` : ""; };

/** 그 일정의 오늘 기록 */
function recOf(e) {
  const d = dayMap[e.kid];
  return (d && d.items[e.id]) || null;
}
function dirtyOf(id) { return dirtyMap[id] || (dirtyMap[id] = new Set()); }

/* ---- 자기주도: 아이가 스스로 적는 부분 ----
 * schedule.json(부모 소유)이 아니라 status/<아이>/<날짜>.json 에 넣습니다.
 * 아이 토큰만으로 쓸 수 있고, 부모가 짠 일정은 손대지 않습니다. */
function dayOf(kidId) {
  return dayMap[kidId] || (dayMap[kidId] = { date: dayKey, items: {}, own: {}, reflect: {} });
}
const ownOf = kidId => (dayOf(kidId).own || (dayOf(kidId).own = {}));
const reflectOf = kidId => (dayOf(kidId).reflect || (dayOf(kidId).reflect = {}));
function markMeta(kidId) {
  dirtyMeta.add(kidId);
  syncState("busy", "저장 대기");
  clearTimeout(flushTimer);
  flushTimer = setTimeout(flush, 2500);
}

const role = () => (conn && conn.role) || "viewer";
const isParent = () => role() === "parent";
const canWrite = () => !!(statusRepo && statusRepo.authed);

/* ===================== 유틸 ===================== */
const $ = id => document.getElementById(id);
const pad = n => String(n).padStart(2, "0");
const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const mins = hm => { const [h, m] = String(hm).split(":").map(Number); return h * 60 + m; };
const hhmm = m => `${pad(Math.floor(m / 60) % 24)}:${pad(Math.round(m) % 60)}`;
const uid = () => Math.random().toString(36).slice(2, 9);
const nowDate = () => new Date();
const nowMin = () => { const d = nowDate(); return d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60; };

function human(m) {
  m = Math.max(0, Math.round(m));
  if (m < 60) return `${m}분`;
  const h = Math.floor(m / 60), r = m % 60;
  return r ? `${h}시간 ${r}분` : `${h}시간`;
}
function readLS(k, fb) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch (e) { return fb; } }
function writeLS(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
function toast(msg) {
  const t = $("toast");
  t.textContent = msg; t.classList.add("show");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("show"), 2600);
}
function download(name, text, mime) {
  const url = URL.createObjectURL(new Blob([text], { type: mime + ";charset=utf-8" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function syncState(s, text) {
  const el = $("syncline");
  el.dataset.s = s;
  $("syncText").textContent = text;
}

/* ===================== 제한시간 · 체크 시간창 ===================== */
/** 이 일정의 제한시간(분). 명시값 > 종료-시작 > 60분 */
function limitOf(e) {
  if (e.limitMin != null && e.limitMin !== "") return Number(e.limitMin);
  if (e.end) return Math.max(1, mins(e.end) - mins(e.start));
  return 60;
}
/** 체크 가능한 시간창(분 단위, 자정 기준) */
/* 체크 가능 시간
 *  - 공부·숙제·독서·생활·놀이: 집에서 스스로 하는 일이라 그날 언제든 "미리" 시작할 수 있습니다(자기주도).
 *  - 학교·학원·운동: 시간이 정해진 곳이라 시작 N분 전부터(기본 30분).
 *  - 끝난 뒤 N분(기본 30분)이 지나면 "놓침".
 * 값은 일정 탭 → 기본값에서 부모가 바꾸며 schedule.json 의 check 에 저장됩니다. */
const EARLY_KINDS = ["study", "read", "life", "play"];
/** 학교·학원·운동을 시작 시각이 지나도 안 눌렀을 때, 몇 분 뒤에 "시작했어?"를 물을지 */
const NUDGE_MIN = 10;
const canEarly = e => EARLY_KINDS.includes(e.kind);
const checkCfg = () => Object.assign({ beforeMin: 30, afterMin: 30 }, sched.check || {});
function windowOf(e) {
  const s = mins(e.start);
  const en = e.end ? mins(e.end) : s + limitOf(e);
  const c = checkCfg();
  return { startM: s, endM: en, openM: canEarly(e) ? 0 : s - c.beforeMin, closeM: en + c.afterMin };
}
/** 실제로 시작한 시각(분). 아직 안 했으면 예정 시각. 목록 순서와 카드 시계에 씁니다. */
function startedMin(rec) {
  if (!rec || !rec.startedAt) return null;
  const d = new Date(rec.startedAt);
  return d.getHours() * 60 + d.getMinutes();
}
const effStart = e => { const a = startedMin(recOf(e)); return a != null ? a : mins(e.start); };
/** 예정보다 10분 이상 먼저 시작한 것 */
const wasEarly = (e, rec) => { const a = startedMin(rec); return a != null && mins(e.start) - a >= 10; };
/** 일정이 차지하는 시간대 [시작, 끝). 끝이 없으면 제한시간만큼으로 봅니다. */
function spanOf(e) {
  const s0 = mins(e.start);
  return [s0, e.end ? mins(e.end) : s0 + limitOf(e)];
}
/**
 * 같은 날 안에서 시간이 겹치는 일정을 찾습니다.
 * 겹침 기준은 [시작, 끝) — 앞 일정이 끝나는 시각에 다음이 시작하는 건 겹침이 아닙니다.
 * @returns {Map<string, string[]>} 일정 id → 겹치는 상대 이름들
 */
function overlapMap(list) {
  const m = new Map();
  for (let i = 0; i < list.length; i++) {
    for (let j = i + 1; j < list.length; j++) {
      const [as, ae] = spanOf(list[i]), [bs, be] = spanOf(list[j]);
      if (as < be && bs < ae) {
        if (!m.has(list[i].id)) m.set(list[i].id, []);
        if (!m.has(list[j].id)) m.set(list[j].id, []);
        m.get(list[i].id).push(list[j].title);
        m.get(list[j].id).push(list[i].title);
      }
    }
  }
  return m;
}

/** 저장된 기록 + 현재 시각으로 상태를 판정 */
function stateOf(e, rec, nm) {
  if (rec && (rec.state === "done" || rec.state === "over")) return rec.state;
  if (rec && rec.state === "running") return "running";
  const w = windowOf(e);
  if (nm < w.openM) return "locked";
  if (nm > w.closeM) return "missed";
  return "todo";
}
/* 진행 상황은 이 함수 하나로 계산합니다 — 머리·카드·알림·완료가 같은 값을 쓰게(1분씩 어긋나던 문제).
 *  - 끝나는 시각이 정해진 일(학교·학원·운동): 남은 시간 = 일정 끝 시각까지. 늦게 시작해도 끝은 그대로이고,
 *    끝 시각이 지나도 "초과"로 치지 않습니다(수업이 늦게 끝난 건 아이 탓이 아니니까요).
 *  - 아무 때나 하는 일(공부·숙제·독서·생활): 시작한 때부터 제한시간.
 *  분은 모두 내림으로 맞춥니다. */
function progressOf(e, rec) {
  const at = rec && rec.doneAt ? new Date(rec.doneAt) : nowDate();
  const el = rec && rec.startedAt ? Math.max(0, Math.floor((at - new Date(rec.startedAt)) / 60000)) : null;
  if (!canEarly(e)) {
    const w = windowOf(e);
    const nowM = at.getHours() * 60 + at.getMinutes();
    const left = w.endM - nowM;
    const pct = Math.max(0, Math.min(100, ((nowM - w.startM) / Math.max(1, w.endM - w.startM)) * 100));
    return { fixed: true, el, left, pct, over: false, ended: left <= 0, endAt: hhmm(w.endM) };
  }
  const lim = (rec && rec.limitMin) || limitOf(e);
  return { fixed: false, el, lim, left: el == null ? lim : lim - el,
           pct: el == null ? 0 : Math.min(100, (el / lim) * 100), over: el != null && el > lim, ended: false };
}
/** 진행 문구 한 줄 [왼쪽, 오른쪽] */
function progressText(p) {
  const l = p.el != null ? `${human(p.el)} 경과` : "";
  if (p.fixed) return [l, p.ended ? "끝날 시간이에요 — 완료를 눌러요" : `${human(p.left)} 남음 · ${p.endAt} 끝`];
  return [l, p.over ? `제한 ${p.lim}분 초과 ${human(p.el - p.lim)}` : `${human(p.left)} 남음`];
}

/** 진행 중인 항목의 경과(분) */
function elapsedOf(rec) {
  if (!rec || !rec.startedAt) return null;
  const end = rec.doneAt ? new Date(rec.doneAt) : nowDate();
  return (end - new Date(rec.startedAt)) / 60000;
}

/* ===================== 일정 데이터 ===================== */
function emptySched() {
  return { version: 3, kids: [{ id: "kid1", name: "첫째", emoji: "🐯", color: "#3B82F6" }],
           notifyBeforeMin: 10, weekly: [], once: [] };
}
const KID_EMOJI = ["🐯", "🐰", "🐻", "🦊", "🐼", "🐨"];
const KID_COLOR = ["#3B82F6", "#EC4899", "#10B981", "#A855F7", "#F59E0B", "#06B6D4"];
function normalize(d) {
  const o = Object.assign(emptySched(), d || {});

  // 아이 목록. 예전 형식(student 하나)이면 첫째 한 명으로 옮깁니다.
  o.kids = (Array.isArray(d && d.kids) && d.kids.length ? d.kids : null)
    ? d.kids.map((k, i) => ({
        id: String(k.id || "kid" + (i + 1)),
        name: k.name || `아이 ${i + 1}`,
        emoji: k.emoji || KID_EMOJI[i % KID_EMOJI.length],
        color: k.color || KID_COLOR[i % KID_COLOR.length]
      }))
    : [{ id: "kid1", name: (d && d.student) || "첫째", emoji: "🐯", color: "#3B82F6" }];
  delete o.student;
  const defKid = o.kids[0].id;
  const okKid = id => o.kids.some(k => k.id === id) ? id : defKid;
  const fix = e => ({
    id: e.id || uid(), start: e.start, end: e.end || "",
    limitMin: (e.limitMin === "" || e.limitMin == null) ? null : Number(e.limitMin),
    title: e.title || "", kind: e.kind || "school", place: e.place || "",
    track: e.track === false ? false : true,         // false = 진행 체크 대상이 아님(학교 등)
    onHoliday: e.onHoliday === "keep" ? "keep" : "skip",  // 공휴일에 유지할지 쉴지
    geo: (e.geo && e.geo.lat != null && e.geo.lng != null)
      ? { lat: Number(e.geo.lat), lng: Number(e.geo.lng), radius: Number(e.geo.radius) || 300 }
      : null,
    kid: okKid(e.kid),
    detail: Array.isArray(e.detail) ? e.detail.filter(detailById) : []
  });
  o.weekly = (o.weekly || []).map(e => Object.assign(fix(e), { day: Number(e.day), off: e.off || [] }))
    .filter(e => e.start && e.title && e.day >= 0 && e.day <= 6);
  o.once = (o.once || []).map(e => Object.assign(fix(e), { date: e.date }))
    .filter(e => e.date && e.start && e.title);
  o.notifyBeforeMin = Number(o.notifyBeforeMin ?? 10);
  if (d && d.check && typeof d.check === "object") {
    const b = Number(d.check.beforeMin), a = Number(d.check.afterMin);
    o.check = { beforeMin: isFinite(b) ? Math.max(0, Math.min(180, b)) : 30,
                afterMin: isFinite(a) ? Math.max(0, Math.min(180, a)) : 30 };
  }
  o.rewards = (Array.isArray(d && d.rewards) ? d.rewards : [])
    .filter(r => r && r.kid && /^\d{4}-\d{2}$/.test(r.month) && r.need > 0 && r.gift)
    .map(r => ({ id: r.id || "r_" + uid(), kid: okKid(r.kid), month: r.month,
                 need: Number(r.need), gift: String(r.gift), paidAt: r.paidAt || null }));
  return o;
}
/* ===================== 장소 확인 ===================== */
/*
 * 아이가 시작·완료를 누를 때 "등록된 장소 근처인가"만 기기에서 판정합니다.
 * 좌표는 절대 기록하지 않습니다. 저장되는 값은 here / away / unknown 셋 중 하나뿐입니다.
 * 장소 좌표는 schedule.json 에 소수점 3자리(약 110m 격자)로만 넣습니다.
 */
const LS_GEO = "ks2.geo.v1";
const geoOn = () => !!readLS(LS_GEO, false);

/** 현재 위치 한 번 읽기. 네이티브면 Capacitor, 아니면 브라우저 API. */
async function readPosition(timeout = 8000) {
  const Cap = window.Capacitor;
  if (Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.Plugins && Cap.Plugins.Geolocation) {
    const p = await Cap.Plugins.Geolocation.getCurrentPosition({ enableHighAccuracy: false, timeout });
    return { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy };
  }
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error("이 기기는 위치를 지원하지 않습니다"));
    navigator.geolocation.getCurrentPosition(
      p => res({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }),
      e => rej(e),
      { enableHighAccuracy: false, timeout, maximumAge: 30000 });
  });
}

/** 두 지점 사이 거리(m) — 하버사인 */
function distM(a, b) {
  const R = 6371000, rad = d => d * Math.PI / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 +
            Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

/**
 * 등록된 장소 근처인지 판정합니다.
 * @returns "here" | "away" | "unknown" | null(검사 안 함)
 */
async function checkSpot(e) {
  if (!e.geo || !geoOn()) return null;
  try {
    const pos = await readPosition();
    const allow = (e.geo.radius || 300) + Math.min(pos.acc || 0, 200);  // GPS 오차만큼 넉넉히
    return distM(pos, e.geo) <= allow ? "here" : "away";
    // pos 는 여기서 버려집니다. 어디에도 저장하지 않습니다.
  } catch (err) {
    return "unknown";
  }
}
const SPOT_LABEL = { here: "📍 장소 확인", away: "📍 다른 곳", unknown: "📍 확인 못 함" };

/* ===================== 공휴일 ===================== */
/**
 * holidays.json 을 읽습니다. 연도별로 묶여 있으므로 한 장으로 펼칩니다.
 * 음력 기반(설날·추석·부처님오신날)과 대체공휴일은 매년 날짜가 달라지므로
 * 프로그램으로 계산하지 않고 데이터로 관리합니다. 임시공휴일도 여기에 넣으면 바로 반영됩니다.
 */
async function loadHolidays() {
  try {
    const r = await fetch("./holidays.json", { cache: "no-store" });
    if (!r.ok) throw new Error(r.status);
    const raw = await r.json();
    const flat = {};
    for (const [k, v] of Object.entries(raw)) {
      if (k.startsWith("_") || typeof v !== "object") continue;   // _note 같은 설명 줄은 건너뜀
      Object.assign(flat, v);
    }
    holidays = flat;
  } catch (e) { holidays = {}; }
}
/** 그날이 공휴일이면 이름, 아니면 null */
const holidayOn = key => holidays[key] || null;
/** 그 해 데이터가 하나도 없으면 true — 사용자에게 추가하라고 알려야 합니다 */
function holidayYearMissing(year) {
  return !Object.keys(holidays).some(k => k.startsWith(year + "-"));
}

/** 특정 날짜의 일정 목록 (시작시간 순). 공휴일에 쉬는 반복 일정은 빠집니다. */
function eventsOn(date, kidId) {
  const key = ymd(date), dw = date.getDay(), out = [];
  const hol = holidayOn(key);
  const want = kidId ? [kidId] : scopeKids().map(k => k.id);
  for (const e of sched.weekly) {
    if (!want.includes(e.kid)) continue;
    if (e.day !== dw) continue;
    if ((e.off || []).includes(key)) continue;
    if (hol && e.onHoliday !== "keep") continue;   // 공휴일엔 기본적으로 쉽니다
    out.push(e);
  }
  // 하루짜리 일정은 날짜를 콕 집어 넣은 것이므로 공휴일이어도 그대로 둡니다(예약 등).
  for (const e of sched.once) if (e.date === key && want.includes(e.kid)) out.push(e);
  return out.sort((a, b) => mins(a.start) - mins(b.start) || a.title.localeCompare(b.title));
}

/** 공휴일이라 빠진 반복 일정들 */
function skippedOn(date) {
  const key = ymd(date), dw = date.getDay();
  if (!holidayOn(key)) return [];
  const want = scopeKids().map(k => k.id);
  return sched.weekly.filter(e => want.includes(e.kid) && e.day === dw && e.onHoliday !== "keep" && !(e.off || []).includes(key))
    .sort((a, b) => mins(a.start) - mins(b.start));
}

/* ===================== 저장소 연결 ===================== */
async function loadConfig() {
  let base = {};
  try { base = await (await fetch("./config.json", { cache: "no-store" })).json(); } catch (e) { }
  cfg = {
    check: Object.assign({ beforeMin: 10, afterMin: 30 }, base.check || {}),
    statusDir: base.statusDir || "status",
    pagesUrl: base.pagesUrl || null      // 비우면 https://아이디.github.io/저장소/ 로 계산
  };
  const saved = readLS(LS.conn, null);
  conn = Object.assign({
    owner: base.owner || "", repo: base.repo || "", branch: base.branch || "main",
    statusOwner: base.statusOwner || null, statusRepo: base.statusRepo || null,
    statusBranch: base.statusBranch || "main",
    role: "viewer"
  }, saved || {});
  buildRepos();
}
function buildRepos() {
  const token = readLS(LS.token, "") || "";
  schedRepo = new GH.Repo({ owner: conn.owner, repo: conn.repo, branch: conn.branch, token });
  statusRepo = new GH.Repo({
    owner: conn.statusOwner || conn.owner,
    repo: conn.statusRepo || conn.repo,
    branch: conn.statusBranch || conn.branch,
    token
  });
}
// 아이마다 다른 파일에 씁니다. 둘이 동시에 체크해도 커밋이 충돌하지 않습니다.
const statusPath = (kid, key) => `${cfg.statusDir}/${kid}/${key}.json`;

/* ===================== 로드 ===================== */
async function loadSchedule() {
  // 1순위 API(최신 보장) → 2순위 Pages 사본 → 3순위 로컬 캐시
  if (schedRepo.authed) {
    try {
      const r = await schedRepo.readJson("schedule.json");
      if (!r.missing) { sched = normalize(r.data); schedSha = r.sha; writeLS(LS.sched, sched); return "api"; }
    } catch (e) { syncState("err", e.message); }
  }
  try {
    const r = await fetch("./schedule.json", { cache: "no-store" });
    if (r.ok) { sched = normalize(await r.json()); writeLS(LS.sched, sched); return "pages"; }
  } catch (e) { }
  const cached = readLS(LS.sched, null);
  sched = cached ? normalize(cached) : emptySched();
  return cached ? "cache" : "empty";
}

async function loadDay(force) {
  const key = ymd(nowDate());
  dayKey = key;
  let err = null, okCnt = 0;

  for (const k of scopeKids()) {
    let remote = null;
    try {
      const r = statusRepo.authed
        ? await statusRepo.readJson(statusPath(k.id, key))
        : await statusRepo.readJsonPublic(statusPath(k.id, key));
      remote = r.missing ? null : r.data;
      okCnt++;
    } catch (e) { err = e.message; }
    dayMap[k.id] = mergeDay(k.id, remote, key);
    await loadChallenges(k.id);
  }
  syncState(err ? "err" : "ok",
    err ? err : (statusRepo.authed ? "저장소와 연결됨" : "읽기 전용"));
}

function recCacheStale() { return true; }

/** 원격 기록을 받되, 아직 못 보낸 로컬 변경(dirty)은 지키고 합칩니다. */
function mergeDay(kidId, remote, key) {
  const base = { date: key, updatedAt: null, items: {}, own: {}, reflect: {} };
  if (remote && remote.date === key) {
    Object.assign(base.items, remote.items || {});
    Object.assign(base.own, remote.own || {});
    Object.assign(base.reflect, remote.reflect || {});
  }
  if (remote) base.updatedAt = remote.updatedAt || null;
  const local = dayMap[kidId];
  // 날짜가 바뀌는 순간 아직 못 보낸 어제 기록이 새 날로 옮겨 붙지 않게, 같은 날일 때만 합칩니다
  const sameDay = !!(local && local.date === key);
  // 아직 못 보낸 내 기록이 있으면 원격보다 우선합니다.
  if (sameDay && dirtyMeta.has(kidId)) {
    base.own = local.own || {};
    base.reflect = local.reflect || {};
  }
  if (sameDay) for (const id of dirtyOf(kidId)) {
    const v = local ? local.items[id] : undefined;
    if (v === undefined || v === null) delete base.items[id];
    else base.items[id] = v;
  }
  return base;
}

/* ===================== 저장 (디바운스 커밋) ===================== */
function markDirty(kidId, id) {
  dirtyOf(kidId).add(id);
  syncState("busy", "저장 대기");
  clearTimeout(flushTimer);
  flushTimer = setTimeout(flush, 2500);
}
async function flush() {
  clearTimeout(flushTimer);
  const pending = [...new Set(
    Object.keys(dirtyMap).filter(k => dirtyMap[k].size).concat([...dirtyMeta])
  )];
  if (!pending.length) return;
  if (!canWrite()) { syncState("err", "토큰이 없어 저장소에 못 씁니다"); return; }

  syncState("busy", "저장 중");
  let failed = null;
  for (const kidId of pending) {
    const ids = [...(dirtyMap[kidId] || [])];
    const cur = dayMap[kidId] || { date: dayKey, items: {} };
    const snap = new Map(ids.map(id => [id, cur.items[id] ?? null]));
    try {
      const r = await statusRepo.updateJson(statusPath(kidId, dayKey), remote => {
        const base = (remote && remote.date === dayKey && remote.items) ? remote : { date: dayKey, items: {} };
        base.items = base.items || {};
        for (const [id, v] of snap) { if (v === null) delete base.items[id]; else base.items[id] = v; }
        if (dirtyMeta.has(kidId)) {
          base.own = cur.own || {};
          base.reflect = cur.reflect || {};
        }
        base.kid = kidId;
        base.name = (kidById(kidId) || {}).name || "";
        base.updatedAt = new Date().toISOString();
        return base;
      }, `chore(status): ${(kidById(kidId) || {}).name || kidId} ${dayKey} 진행 기록`);
      ids.forEach(id => dirtyMap[kidId] && dirtyMap[kidId].delete(id));
      dirtyMeta.delete(kidId);
      if (r.data) dayMap[kidId] = mergeDay(kidId, r.data, dayKey);
    } catch (e) { failed = e.message; }
  }
  recCache = null;
  if (failed) { syncState("err", failed); toast(failed); }
  else syncState("ok", `저장됨 ${new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })}`);
  render();
}

/* ===================== 동작 ===================== */
function setRec(e, rec) {
  const d = dayMap[e.kid] || (dayMap[e.kid] = { date: dayKey, items: {} });
  if (rec === null) delete d.items[e.id]; else d.items[e.id] = rec;
  markDirty(e.kid, e.id);
  render();
  syncNativeAlarms(false);         // 끝낸 일의 오늘 알람은 빼고, 되돌리면 다시 넣습니다
}
function startTask(e) {
  const nm = nowMin(), w = windowOf(e);
  if (!isParent() && nm < w.openM) { toast(`${hhmm(w.openM)}부터 시작할 수 있어요`); return; }
  setRec(e, {
    state: "running",
    startedAt: nowDate().toISOString(),
    doneAt: null,
    elapsedMin: null,
    limitMin: limitOf(e),
    by: role()
  });
  global_NA()?.armLimit(e, recOf(e), canEarly(e) ? null : {
    at: new Date(`${dayKey}T${hhmm(windowOf(e).endM)}:00`).toISOString(),
    title: `🏁 ${e.title} 끝날 시간`, body: "다 했으면 완료를 눌러 주세요"
  });
  toast(`${e.title} 시작 — 제한 ${limitOf(e)}분`);
  applySpot(e, "atStart");
}
function completeTask(e) {
  const nm = nowMin(), w = windowOf(e);
  const prev = recOf(e);
  if (!isParent() && nm > w.closeM && !prev) {
    toast(`체크 시간이 지났습니다 (${hhmm(w.closeM)}까지)`); return;
  }
  const lim = limitOf(e);
  const doneAt = nowDate().toISOString();
  const el = prev && prev.startedAt ? (new Date(doneAt) - new Date(prev.startedAt)) / 60000 : null;
  const over = canEarly(e) && el != null && el > lim;     // 학교·학원·운동은 늦게 끝나도 초과 아님
  // 이미 적어 둔 세부 기록과 시작 시점 장소 판정을 그대로 가져갑니다.
  setRec(e, {
    ...(prev || {}),
    state: over ? "over" : "done",
    startedAt: prev ? prev.startedAt : null,
    doneAt,
    elapsedMin: el == null ? null : Math.round(el),
    limitMin: lim,
    by: role()
  });
  global_NA()?.disarmLimit(e);
  applySpot(e, "atDone");
  // 시간을 넘겨도 완료는 축하합니다. 끝까지 한 것이 더 중요합니다.
  const cheer = over ? PRAISE_OVER[Math.floor(Math.random() * PRAISE_OVER.length)]
                     : PRAISE[Math.floor(Math.random() * PRAISE.length)];
  toast(`${e.title} 완료 — ${cheer}${el != null ? ` (${human(el)})` : ""}`);
  maybeCelebrate(e.kid);
  chalAutoFrom(e.kid, e.title);
  chalSyncAll(e.kid);
}
/** 장소 판정을 백그라운드로 돌려 기록에 덧붙입니다. 화면을 막지 않습니다. */
function applySpot(e, field) {
  checkSpot(e).then(spot => {
    if (!spot) return;
    const rec = recOf(e);
    if (!rec) return;              // 그새 되돌렸으면 아무것도 하지 않습니다
    rec[field] = spot;
    markDirty(e.kid, e.id);
    render();
    if (spot === "away") toast(`${e.title} — 등록한 장소가 아닙니다`);
  });
}

function undoTask(e) { setRec(e, null); global_NA()?.disarmLimit(e); toast("되돌렸습니다"); chalSyncAll(e.kid); }

/* ===================== 자기주도: 내가 정한 것 ===================== */
function ownAdd(kidId, title, limitMin, kind) {
  const id = "own_" + uid();
  ownOf(kidId)[id] = {
    id, title, kind: kind || "study",
    limitMin: limitMin || null,
    state: "todo", startedAt: null, doneAt: null, elapsedMin: null,
    madeAt: nowDate().toISOString()
  };
  markMeta(kidId); render();
}
function ownSet(kidId, id, patch) {
  const o = ownOf(kidId)[id]; if (!o) return;
  Object.assign(o, patch); markMeta(kidId); render();
}
function ownStart(kidId, id) {
  ownSet(kidId, id, { state: "running", startedAt: nowDate().toISOString() });
}
function ownDone(kidId, id) {
  const o = ownOf(kidId)[id]; if (!o) return;
  const doneAt = nowDate().toISOString();
  const el = o.startedAt ? (new Date(doneAt) - new Date(o.startedAt)) / 60000 : null;
  const over = el != null && o.limitMin && el > o.limitMin;
  ownSet(kidId, id, {
    state: over ? "over" : "done", doneAt,
    elapsedMin: el == null ? null : Math.round(el)
  });
  toast(`${o.title} 완료 — ${PRAISE[Math.floor(Math.random() * PRAISE.length)]}${el != null ? ` (${human(el)})` : ""}`);
  chalAutoFrom(kidId, o.title);
  maybeCelebrate(kidId);
}
function ownDel(kidId, id) {
  delete ownOf(kidId)[id]; markMeta(kidId); render();
}

function renderOwn() {
  const host = $("ownBox");
  if (!host) return;
  const kid = oneKid();
  // "모두" 화면에서는 누구 것인지 모호하므로 숨깁니다.
  host.classList.toggle("hidden", !kid);
  if (!kid) return;
  // 보기만 기기: 칸을 숨기면 "없는 기능"처럼 보여서, 이유와 함께 잠가 둡니다.
  const ro = !canWrite();
  $("ownForm").classList.toggle("hidden", ro);
  $("ownLock").classList.toggle("hidden", !ro);
  if (ro) { $("ownList").innerHTML = ""; $("ownCount").textContent = ""; return; }

  const rank = o => o.state === "running" ? 0 : ["done", "over"].includes(o.state) ? 2 : 1;
  const list = Object.values(ownOf(kid)).sort((a, b) => rank(a) - rank(b) || (a.madeAt || "").localeCompare(b.madeAt || ""));
  const ul = $("ownList");
  ul.innerHTML = "";
  $("ownCount").textContent = list.length ? `${list.filter(o => ["done", "over"].includes(o.state)).length}/${list.length}` : "";

  if (!list.length) {
    ul.innerHTML = `<li class="ownempty">오늘 스스로 하고 싶은 걸 적어 보세요. 부모님 일정과 따로 기록됩니다.</li>`;
    return;
  }
  for (const o of list) {
    const k = kindOf(o.kind);
    const done = ["done", "over"].includes(o.state);
    const el = o.state === "running" && o.startedAt
      ? (nowDate() - new Date(o.startedAt)) / 60000
      : o.elapsedMin;

    const li = document.createElement("li");
    li.className = "ownrow" + (done ? " done" : "");
    li.innerHTML = `<span class="emoji">${k.emoji}</span>
      <span class="meta"><b></b><span class="sub"></span></span>
      <span class="acts"></span>`;
    li.querySelector("b").textContent = o.title;
    li.querySelector(".sub").textContent = [
      o.limitMin ? `제한 ${o.limitMin}분` : null,
      el != null ? `${human(el)} ${done ? "걸림" : "경과"}` : null,
      o.state === "over" ? "시간 초과" : null
    ].filter(Boolean).join(" · ") || "아직 시작 안 함";

    const acts = li.querySelector(".acts");
    const add = (t, cls, fn) => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "btn small " + cls; b.textContent = t;
      b.addEventListener("click", fn); acts.appendChild(b);
    };
    if (o.state === "todo") { add("시작", "go", () => ownStart(kid, o.id)); add("완료", "", () => ownDone(kid, o.id)); }
    else if (o.state === "running") { add("완료", "primary", () => ownDone(kid, o.id)); }
    else add("되돌리기", "", () => ownSet(kid, o.id, { state: "todo", startedAt: null, doneAt: null, elapsedMin: null }));
    add("✕", "danger", () => { if (confirm(`${withEul(o.title)} 지울까요?`)) ownDel(kid, o.id); });
    ul.appendChild(li);
  }
}

/* ===================== 자기주도: 하루 돌아보기 ===================== */
function renderReflect() {
  const host = $("reflectBox");
  if (!host) return;
  const kid = oneKid();
  host.classList.toggle("hidden", !kid || !canWrite());
  if (!kid || !canWrite()) return;

  const R = reflectOf(kid);
  document.querySelectorAll("#starRow button").forEach(b => {
    b.textContent = Number(b.dataset.v) <= (R.rating || 0) ? "★" : "☆";
    b.classList.toggle("on", Number(b.dataset.v) <= (R.rating || 0));
  });
  $("rWord").textContent = ["", "힘들었어", "그럭저럭", "괜찮았어", "잘했어", "최고였어"][R.rating || 0] || "오늘 어땠나요?";
  if (document.activeElement !== $("rGood")) $("rGood").value = R.good || "";
  if (document.activeElement !== $("rNext")) $("rNext").value = R.next || "";
}

/** 저장된 선택이 없거나 맞지 않을 때의 기본 화면: 부모는 "모두", 그 외엔 첫째 */
function defaultWho() {
  if (conn.who && kidById(conn.who)) return conn.who;
  if (conn.role === "child") return (kids()[0] || {}).id || "";   // 설정에서 고를 때까지 임시로
  if (conn.role === "parent" && kids().length > 1) return "all";
  return (kids()[0] || {}).id || "";
}

/* ===================== 🏅 목표 챌린지 (도장판) =====================
 * 종이 플래너의 "목표 달성 챌린지"를 그대로 옮깁니다.
 *   목표 · 나에게 주는 선물 · 꺼진 모닥불 N칸 → 해낸 날마다 불을 붙이고 날짜를 남김 → 다 채우면 선물
 * 연속일 필요가 없습니다. 하루 빠져도 판이 깨지지 않습니다.
 *
 * 저장: status/<아이>/challenges.json — 기록 저장소 쪽이라 아이 토큰으로 쓸 수 있습니다.
 * 하루에 도장 하나. 오늘 찍은 도장만 되돌릴 수 있습니다(실수 방지).
 * 일정과 연결해 두면 그 일정을 완료하는 순간 자동으로 불이 붙습니다.
 */
let chalMap = {};                 // 아이 id → { items: [...] }
let chalDirty = {};               // 아이 id → Set(바뀐 챌린지 id)
let chalDeleted = {};             // 아이 id → Set(지운 챌린지 id)
let chalTimer = null;
const chalPath = kid => `${cfg.statusDir}/${kid}/challenges.json`;
const chalOf = kid => (chalMap[kid] || (chalMap[kid] = { items: [] })).items;

async function loadChallenges(kid) {
  try {
    const r = statusRepo.authed
      ? await statusRepo.readJson(chalPath(kid))
      : await statusRepo.readJsonPublic(chalPath(kid));
    const remote = (r.data && Array.isArray(r.data.items)) ? r.data.items : [];
    // 아직 못 보낸 내 변경은 지킵니다
    const mine = chalDirty[kid] || new Set(), gone = chalDeleted[kid] || new Set();
    const local = new Map(chalOf(kid).map(c => [c.id, c]));
    const merged = remote.filter(c => !gone.has(c.id)).map(c => mine.has(c.id) && local.has(c.id) ? local.get(c.id) : c);
    for (const id of mine) if (local.has(id) && !merged.some(c => c.id === id)) merged.push(local.get(id));
    chalMap[kid] = { items: merged };
  } catch (e) { /* 못 읽어도 화면은 그대로 둡니다 */ }
}

function markChal(kid, id, deleted) {
  (deleted ? (chalDeleted[kid] || (chalDeleted[kid] = new Set()))
           : (chalDirty[kid] || (chalDirty[kid] = new Set()))).add(id);
  syncState("busy", "저장 대기");
  clearTimeout(chalTimer);
  chalTimer = setTimeout(flushChallenges, 2000);
}

async function flushChallenges() {
  clearTimeout(chalTimer);
  if (!canWrite()) return;
  for (const kid of new Set([...Object.keys(chalDirty), ...Object.keys(chalDeleted)])) {
    const mine = chalDirty[kid] || new Set(), gone = chalDeleted[kid] || new Set();
    if (!mine.size && !gone.size) continue;
    const local = new Map(chalOf(kid).map(c => [c.id, c]));
    try {
      await statusRepo.updateJson(chalPath(kid), cur => {
        const items = ((cur && cur.items) || []).filter(c => !gone.has(c.id));
        for (const id of mine) {
          if (!local.has(id)) continue;
          const i = items.findIndex(c => c.id === id);
          if (i >= 0) items[i] = local.get(id); else items.push(local.get(id));
        }
        return { kid, name: (kidById(kid) || {}).name || "", updatedAt: new Date().toISOString(), items };
      }, `chore(challenge): ${(kidById(kid) || {}).name || kid} 챌린지`);
      mine.clear(); gone.clear();
      syncState("ok", "저장됨");
    } catch (e) { syncState("err", e.message); }
  }
}

/** 모닥불 그림. 켜진 것은 불꽃, 꺼진 것은 회색 장작과 번호 */
function fireSVG(lit, n) {
  if (lit) return `<svg viewBox="0 0 60 60" class="fire lit" aria-hidden="true">
    <circle class="glow" cx="30" cy="30" r="28" fill="#FFE3D0"/>
    <g transform="translate(30 45)">
      <rect x="-20" y="-4.5" width="40" height="9" rx="4.5" fill="#8E522A" transform="rotate(-24)"/>
      <rect x="-20" y="-4.5" width="40" height="9" rx="4.5" fill="#B06A35" transform="rotate(24)"/>
    </g>
    <g class="flame">
      <path d="M30 7 C41 20 46 29 40 38 C36 44 24 44 20 38 C14 29 21 19 30 7Z" fill="#FF6B2C"/>
      <path d="M30 19 C36 27 38 32 34.5 37 C32.5 39.5 27.5 39.5 25.5 37 C22 32 24.5 26 30 19Z" fill="#FFB02E"/>
      <path d="M30 27 C33 31 33.5 34 31.8 36.4 C30.8 37.6 29.2 37.6 28.2 36.4 C26.5 34 27 31 30 27Z" fill="#FFE27A"/>
    </g>
  </svg>`;
  return `<svg viewBox="0 0 60 60" class="fire" aria-hidden="true">
    <circle class="ground" cx="30" cy="30" r="28" fill="#E9EDF1"/>
    <g transform="translate(30 34)">
      <rect x="-22" y="-5.5" width="44" height="11" rx="5.5" fill="#56606E" transform="rotate(-34)"/>
      <rect x="-22" y="-5.5" width="44" height="11" rx="5.5" fill="#3F4854" transform="rotate(34)"/>
    </g>
    <circle cx="30" cy="34" r="8.5" fill="#3F4854"/>
    <text x="30" y="38.2" text-anchor="middle" font-size="11.5" font-weight="700" fill="#F3F4F6"
      font-family="Pretendard Variable, Apple SD Gothic Neo, sans-serif">${n}</text>
  </svg>`;
}

/* ---- 도장 모양 ----
 * 챌린지마다 아이가 고릅니다. 꺼진 칸은 모두 같은 회색 실루엣 + 번호,
 * 켜진 칸은 모양마다 다른 색. 이모지로 "내 마음대로"도 됩니다.
 */
const STAMP_THEMES = [
  { id: "star",   name: "별" },
  { id: "heart",  name: "하트" },
  { id: "flower", name: "꽃" },
  { id: "apple",  name: "사과" },
  { id: "clover", name: "클로버" },
  { id: "fire",   name: "모닥불" },
  { id: "emoji",  name: "내 마음대로" }
];
const OFF_FILL = "#C5CDD6", OFF_NUM = "#56606E";

function starPath(cx, cy, R, r) {
  let d = "";
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + i * Math.PI / 5, rad = i % 2 ? r : R;
    d += (i ? "L" : "M") + (cx + Math.cos(a) * rad).toFixed(1) + " " + (cy + Math.sin(a) * rad).toFixed(1);
  }
  return d + "Z";
}
const HEART = "M30 50C12 38 7 26 14 18C20 11 28 13 30 20C32 13 40 11 46 18C53 26 48 38 30 50Z";
function flowerShape(fillP, fillC) {
  let g = "";
  for (let i = 0; i < 5; i++) {
    const a = -Math.PI / 2 + i * 2 * Math.PI / 5;
    g += `<circle cx="${(30 + Math.cos(a) * 11).toFixed(1)}" cy="${(31 + Math.sin(a) * 11).toFixed(1)}" r="9.5" fill="${fillP}"/>`;
  }
  return g + `<circle cx="30" cy="31" r="7" fill="${fillC}"/>`;
}
function cloverShape(fill, stem) {
  let g = `<path d="M30 33 Q33 44 40 50" stroke="${stem}" stroke-width="3" fill="none" stroke-linecap="round"/>`;
  for (const [dx, dy] of [[0, -9], [9, 0], [0, 9], [-9, 0]]) g += `<circle cx="${30 + dx}" cy="${31 + dy}" r="9" fill="${fill}"/>`;
  return g + `<circle cx="30" cy="31" r="4" fill="${fill}"/>`;
}
const APPLE = "M30 20C22 14 11 18 12 31C13 43 21 51 27 50C29 49.6 31 49.6 33 50C39 51 47 43 48 31C49 18 38 14 30 20Z";

function stampSVG(theme, lit, n, emoji) {
  const num = `<text class="n" x="30" y="${theme === "heart" ? 36 : 36.5}" text-anchor="middle" font-size="12" font-weight="700" fill="${OFF_NUM}"
      font-family="Pretendard Variable, Apple SD Gothic Neo, sans-serif">${n}</text>`;
  const wrap = (cls, inner) => `<svg viewBox="0 0 60 60" class="fire ${cls}" aria-hidden="true">${inner}</svg>`;
  const ground = `<circle class="ground" cx="30" cy="30" r="28" fill="#E9EDF1"/>`;
  const glow = c => `<circle class="glow" cx="30" cy="30" r="28" fill="${c}"/>`;

  if (theme === "fire" || !theme) return fireSVG(lit, n);
  if (theme === "emoji") {
    if (!lit) return wrap("", ground + num);
    return wrap("lit", glow("#FFF1D6") + `<text x="30" y="41" text-anchor="middle" font-size="30"
      font-family="Apple Color Emoji, Segoe UI Emoji, Noto Color Emoji, sans-serif">${esc(emoji || "⭐")}</text>`);
  }
  if (!lit) {
    const sil = {
      star:   `<path class="sil" d="${starPath(30, 31, 23, 10)}" fill="${OFF_FILL}"/>`,
      heart:  `<path class="sil" d="${HEART}" fill="${OFF_FILL}"/>`,
      flower: `<g class="sil">${flowerShape(OFF_FILL, OFF_FILL)}</g>`,
      apple:  `<path class="sil" d="${APPLE}" fill="${OFF_FILL}"/>`,
      clover: `<g class="sil">${cloverShape(OFF_FILL, OFF_FILL)}</g>`
    }[theme];
    return wrap("", ground + sil + num);
  }
  const on = {
    star: glow("#FFF3C4") +
      `<path d="${starPath(30, 31, 23, 10)}" fill="#FFC83D" stroke="#F0A30A" stroke-width="1.5" stroke-linejoin="round"/>
       <circle cx="24" cy="27" r="2.2" fill="#fff" opacity=".8"/>
       <path d="M49 11 l1.5 3.5 3.5 1.5 -3.5 1.5 -1.5 3.5 -1.5 -3.5 -3.5 -1.5 3.5 -1.5Z" fill="#FFB800"/>`,
    heart: glow("#FFE0EA") +
      `<path d="${HEART}" fill="#FF5C8A"/>
       <ellipse cx="21" cy="23" rx="4" ry="2.6" fill="#fff" opacity=".55" transform="rotate(-35 21 23)"/>`,
    flower: glow("#FFE7F0") + flowerShape("#FF8FB1", "#FFD34E") + `<circle cx="28" cy="29" r="1.8" fill="#fff" opacity=".7"/>`,
    apple: glow("#FFE1DE") +
      `<path d="M30 20 Q31 13 35 10" stroke="#7A4A26" stroke-width="2.6" fill="none" stroke-linecap="round"/>
       <path d="M33 14 C38 8 46 10 45 14 C41 17 36 17 33 14Z" fill="#3FB950"/>
       <path d="${APPLE}" fill="#EE4235"/>
       <ellipse cx="21" cy="28" rx="3" ry="5" fill="#fff" opacity=".45" transform="rotate(20 21 28)"/>`,
    clover: glow("#DDF7E8") + cloverShape("#34C27A", "#2A9D5F") + `<circle cx="27" cy="22" r="1.8" fill="#fff" opacity=".6"/>`
  }[theme];
  return wrap("lit", on);
}
const THEME_ICON = { star: "⭐", heart: "💗", flower: "🌸", apple: "🍎", clover: "🍀", fire: "🔥" };
const chalIcon = c => c.theme === "emoji" ? (c.emoji || "⭐") : (THEME_ICON[c.theme || "fire"] || "⭐");
const DATE_COLOR = { star: "#B7791F", heart: "#D6336C", flower: "#C2255C", apple: "#C92A2A", clover: "#2B8A3E", fire: "#8E522A", emoji: "#8E522A" };

function chalAdd(kid, goal, gift, size, link, theme, emoji) {
  const c = {
    id: "c_" + uid(), goal, gift: gift || "", size,
    theme: theme || "star", emoji: theme === "emoji" ? (emoji || "⭐") : undefined,
    start: ymd(nowDate()), link: link || null, stamps: [], doneAt: null,
    createdAt: nowDate().toISOString()
  };
  chalOf(kid).push(c);
  markChal(kid, c.id);
  return c;
}

/** 오늘 도장 찍기. 이미 찍었거나 다 찬 판이면 아무것도 안 합니다. */
function chalStamp(kid, id, auto) {
  const c = chalOf(kid).find(x => x.id === id);
  if (!c || c.doneAt) return false;
  const today = ymd(nowDate());
  if (c.stamps.includes(today)) { if (!auto) toast(`오늘은 이미 찍었어요 ${chalIcon(c)}`); return false; }
  const mBefore = stampsInMonth(kid, monthOf(today));
  c.stamps.push(today);
  rewardCrossCheck(kid, mBefore, mBefore + 1, monthOf(today));
  const left = c.size - c.stamps.length;
  if (left <= 0) {
    c.doneAt = nowDate().toISOString();
    markChal(kid, id); render();
    celebrate(`챌린지 완주! ${chalIcon(c)} ${c.size}개`, c.gift ? `🎁 나에게 주는 선물: ${c.gift}` : `"${c.goal}" 해냈어요`, { emoji: "🏅", big: true });
    speak(`${c.goal} 챌린지 완주! ${c.gift ? c.gift + " 선물 받자" : "정말 잘했어"}`);
    return true;
  }
  markChal(kid, id); render();
  const ic = chalIcon(c);
  toast(auto === "all" ? `${ic} 오늘 일정 다 끝! 도장 쾅 — ${left}개 남았어`
      : auto ? `${ic} "${c.goal}" 도장 쾅! — ${left}개 남았어`
             : pick([`${ic} 쾅! ${left}개 남았어`, `${ic} ${c.stamps.length}번째! 조금만 더`, `${ic} 좋아! 앞으로 ${left}개`]));
  return true;
}
function chalUnstamp(kid, id) {
  const c = chalOf(kid).find(x => x.id === id);
  if (!c) return;
  const today = ymd(nowDate());
  if (!c.stamps.includes(today)) return;
  c.stamps = c.stamps.filter(d => d !== today);
  c.doneAt = null;
  markChal(kid, id); render();
  toast("오늘 도장을 지웠어요");
}

/* ---- "오늘 일정을 모두 끝내면 자동" ----
 * 그날 체크 대상 일정(학교처럼 체크 안 함 은 제외)이 전부 완료(시간 초과로 끝낸 것 포함)되면
 * 하루 한 번 도장을 찍습니다. 하나라도 놓치면 그날은 안 찍힙니다(판은 깨지지 않음).
 * 완료를 되돌려 "전부"가 깨지면, 그날 자동으로 찍힌 도장도 회수합니다.
 */
const CHAL_ALL = "__all__";
function todayAllDone(kid) {
  const list = eventsOn(nowDate(), kid).filter(e => e.track !== false);
  const nm = nowMin();
  const done = list.filter(e => ["done", "over"].includes((recOf(e) || {}).state)).length;
  const missed = list.filter(e => stateOf(e, recOf(e), nm) === "missed").length;
  return { total: list.length, done, missed, all: list.length > 0 && done === list.length };
}
function chalSyncAll(kid) {
  const today = ymd(nowDate());
  const t = todayAllDone(kid);
  for (const c of chalOf(kid)) {
    if (c.link !== CHAL_ALL) continue;
    c.autoDays = c.autoDays || [];
    const stamped = c.stamps.includes(today);
    if (t.all && !stamped && !c.doneAt) {
      c.autoDays.push(today);
      chalStamp(kid, c.id, "all");
    } else if (!t.all && stamped && c.autoDays.includes(today)) {
      c.stamps = c.stamps.filter(d => d !== today);
      c.autoDays = c.autoDays.filter(d => d !== today);
      c.doneAt = null;
      markChal(kid, c.id); render();
      toast(`${chalIcon(c)} 오늘 도장이 지워졌어요 — 다시 다 끝내면 찍혀요`);
    }
  }
}

/** 일정·스스로 정한 것을 완료했을 때, 연결된 챌린지에 자동으로 불을 붙입니다. */
function chalAutoFrom(kid, title) {
  for (const c of chalOf(kid)) if (!c.doneAt && c.link && c.link === title) chalStamp(kid, c.id, true);
}

function renderChallenges() {
  const host = $("chalBox");
  if (!host) return;
  const kid = oneKid();
  host.classList.toggle("hidden", !kid);
  if (!kid) return;
  const write = canWrite();
  $("chalNew").classList.toggle("hidden", !write);

  const all = chalOf(kid);
  const live = all.filter(c => !c.doneAt);
  const done = all.filter(c => c.doneAt).sort((a, b) => b.doneAt.localeCompare(a.doneAt));
  const wrap = $("chalList");
  wrap.innerHTML = "";

  if (!live.length) {
    wrap.innerHTML = `<p class="chalempty">${done.length ? "새 챌린지를 시작해 볼까요?" : "목표를 하나 정하고, 해낸 날마다 도장을 하나씩 찍어 보세요. 모양은 마음대로 고를 수 있어요."}</p>`;
  }
  const today = ymd(nowDate());
  for (const c of live) {
    const lit = c.stamps.length, left = c.size - lit;
    const card = document.createElement("div");
    card.className = "chal";
    card.innerHTML = `
      <div class="chalhead">
        <div class="chalrow"><span class="chalk">날짜</span><span class="chalv">${c.start.slice(2).replace(/-/g, "/")} ~</span></div>
        <div class="chalrow"><span class="chalk">목표</span><span class="chalv hand"></span></div>
        <div class="chalrow"><span class="chalk">나에게 주는 선물</span><span class="chalv hand gift"></span></div>
      </div>
      <div class="chalgrid"></div>
      <div class="chalfoot">
        <span>${chalIcon(c)} ${lit}/${c.size}${left > 0 ? ` — ${left}개 남았어!` : ""}</span>
        <span class="chalacts"></span>
      </div>`;
    card.querySelector(".chalrow:nth-child(2) .chalv").textContent = c.goal;
    card.querySelector(".gift").textContent = c.gift || "—";

    const grid = card.querySelector(".chalgrid");
    const stampedToday = c.stamps.includes(today);
    for (let i = 0; i < c.size; i++) {
      const d = c.stamps[i];
      const cell = document.createElement(write ? "button" : "div");
      if (write) cell.type = "button";
      cell.className = "cell" + (d ? " on" : "") + (d === today ? " today" : "");
      cell.innerHTML = stampSVG(c.theme || "fire", !!d, i + 1, c.emoji) +
        `<span class="cdate" style="--dc:${DATE_COLOR[c.theme || "fire"]}">${d ? `${+d.slice(5, 7)}/${+d.slice(8)}` : ""}</span>`;
      if (write) {
        const next = i === lit && !stampedToday && !c.link;
        if (next) cell.classList.add("next");
        cell.setAttribute("aria-label", d ? `${i + 1}번째 도장 ${d}` : `${i + 1}번째 칸`);
        cell.addEventListener("click", () => {
          if (d === today) {
            if (c.link && !isParent()) { toast("자동으로 찍힌 도장이에요"); return; }
            if (confirm("오늘 찍은 도장을 지울까요?")) chalUnstamp(kid, c.id);
            return;
          }
          if (d) return;
          if (c.link === CHAL_ALL && !isParent()) {
            const t = todayAllDone(kid);
            toast(!t.total ? "오늘은 체크할 일정이 없어요"
              : t.missed ? "오늘은 못 한 일정이 있어서 도장이 없어요. 내일 다시!"
              : `오늘 일정 ${t.total - t.done}개를 더 끝내면 자동으로 찍혀요`);
            return;
          }
          if (c.link && !isParent()) { toast(`"${c.link}" 을(를) 끝내면 자동으로 찍혀요`); return; }
          if (c.link && isParent() && !confirm("자동 도장 챌린지예요. 부모 권한으로 직접 찍을까요?")) return;
          chalStamp(kid, c.id);
        });
      }
      grid.appendChild(cell);
    }
    {
      const how = document.createElement("div");
      how.className = "chalhow";
      if (c.link === CHAL_ALL) {
        const t = todayAllDone(kid);
        // 이미 놓친 게 있으면 오늘은 받을 수 없으니 "다 하면 도장!" 대신 담담하게 알립니다
        const msg = stampedToday ? "오늘 도장 완료 ✓"
          : !t.total ? "오늘은 체크할 일정이 없어요"
          : t.missed ? `오늘은 못 한 일정이 ${t.missed}개 있어요 — 내일 다시!`
          : `오늘 ${t.done}/${t.total} — 다 하면 도장!`;
        how.innerHTML = `<span class="chalmode">📅 오늘 일정 모두 끝내면 자동</span><span class="chaltoday${stampedToday ? " ok" : ""}"></span>`;
        how.querySelector(".chaltoday").textContent = msg;
        if (t.total && !stampedToday && !t.missed) {
          const bar = document.createElement("div");
          bar.className = "rwbar"; bar.innerHTML = `<i style="width:${Math.round(t.done / t.total * 100)}%"></i>`;
          how.appendChild(bar);
        }
      } else {
        how.innerHTML = `<span class="chalmode"></span>`;
        how.querySelector(".chalmode").textContent = chalLinkLabel(c);
      }
      card.insertBefore(how, card.querySelector(".chalfoot"));
    }
    if (write) {
      const sw = document.createElement("button");
      sw.type = "button"; sw.className = "btn small"; sw.textContent = "🎨 모양";
      sw.title = "누를 때마다 다른 모양";
      sw.addEventListener("click", () => {
        const ids = STAMP_THEMES.map(t => t.id).filter(x => x !== "emoji" || c.emoji);
        c.theme = ids[(ids.indexOf(c.theme || "fire") + 1) % ids.length];
        markChal(kid, c.id); render();
      });
      card.querySelector(".chalacts").appendChild(sw);
      const mode = document.createElement("select");
      mode.className = "chalsel";
      mode.title = "도장 찍는 방법";
      const titles = [...new Set(sched.weekly.concat(sched.once).filter(e => e.kid === kid && e.track !== false).map(e => e.title))];
      mode.innerHTML = chalLinkOptions(titles);
      mode.value = c.link || "";
      mode.addEventListener("change", () => {
        c.link = mode.value || null;
        markChal(kid, c.id);
        if (c.link === CHAL_ALL) chalSyncAll(kid);    // 오늘 이미 다 끝냈으면 바로 찍힘
        render();
        toast(chalLinkLabel(c) + " 으로 바꿨어요");
      });
      card.querySelector(".chalacts").appendChild(mode);
      const del = document.createElement("button");
      del.type = "button"; del.className = "btn small danger"; del.textContent = "그만두기";
      del.addEventListener("click", () => {
        if (!confirm(`"${c.goal}" 챌린지를 지울까요? 찍은 도장 ${lit}개도 함께 사라집니다.`)) return;
        chalMap[kid].items = chalOf(kid).filter(x => x.id !== c.id);
        markChal(kid, c.id, true); render();
      });
      card.querySelector(".chalacts").appendChild(del);
    }
    wrap.appendChild(card);
  }
  if (done.length) {
    const d = document.createElement("details");
    d.className = "chaldone";
    d.innerHTML = `<summary>🏆 완주한 챌린지 ${done.length}개</summary><ul class="list"></ul>`;
    for (const c of done) {
      const li = document.createElement("li");
      li.innerHTML = `<span class="meta"><b></b><span></span></span>`;
      li.querySelector("b").textContent = `${chalIcon(c)} ${c.goal}`;
      li.querySelector(".meta span").textContent =
        `${c.size}개 · ${c.start.slice(5).replace("-", "/")} ~ ${c.doneAt.slice(5, 10).replace("-", "/")}` + (c.gift ? ` · 🎁 ${c.gift}` : "");
      d.querySelector("ul").appendChild(li);
    }
    wrap.appendChild(d);
  }
}

/** 새 챌린지 폼의 "도장 모양" — 켜진 모습 미리보기로 고릅니다 */
function paintChalThemes() {
  const box = $("chalTheme");
  if (!box) return;
  const cur = (box.querySelector("input:checked") || {}).value || "star";
  box.innerHTML = "";
  for (const t of STAMP_THEMES) {
    const l = document.createElement("label");
    l.className = "thchip";
    l.innerHTML = `<input type="radio" name="chalTheme" value="${t.id}"${t.id === cur ? " checked" : ""}>` +
      (t.id === "emoji" ? `<span class="thpic thtxt">😊</span>` : `<span class="thpic">${stampSVG(t.id, true, 1)}</span>`) +
      `<span class="thname">${t.name}</span>`;
    l.querySelector("input").addEventListener("change", () => {
      $("chalEmojiRow").classList.toggle("hidden", t.id !== "emoji");
      if (t.id === "emoji") $("chalEmoji").focus();
    });
    box.appendChild(l);
  }
  $("chalEmojiRow").classList.toggle("hidden", cur !== "emoji");
}

function chalLinkOptions(titles) {
  return `<option value="${CHAL_ALL}">📅 오늘 일정을 모두 끝내면 자동 (추천)</option>` +
    `<option value="">✋ 직접 도장 찍기</option>` +
    titles.map(t => `<option value="${esc(t)}">"${esc(t)}" 완료하면 자동</option>`).join("");
}
const chalLinkLabel = c => c.link === CHAL_ALL ? "📅 오늘 일정을 모두 끝내면 자동" :
                           c.link ? `"${c.link}" 완료하면 자동` : "✋ 직접 도장";

/** 새 챌린지 폼의 "일정과 연결" 목록 */
function paintChalLinks() {
  const sel = $("chalLink");
  if (!sel) return;
  const kid = oneKid();
  const titles = kid ? [...new Set(sched.weekly.concat(sched.once).filter(e => e.kid === kid && e.track !== false).map(e => e.title))] : [];
  sel.innerHTML = chalLinkOptions(titles);
  sel.value = CHAL_ALL;
}

/* ===================== 🎁 이달의 보상 =====================
 * 부모가 달마다 "도장 몇 개 → 무엇"을 정하고, 채우면 부모가 지급 처리합니다.
 * 집계: 그 달에 찍은 챌린지 도장 합계(모든 챌린지). 단계는 여러 개 둘 수 있습니다.
 *
 * 저장: schedule.json 의 rewards — 부모 쪽 파일입니다.
 * 아이 토큰으로는 쓸 수 없으므로 아이가 보상을 바꾸거나 스스로 "지급"할 수 없습니다.
 * 저장할 때는 건드린 (아이, 달) 묶음만 바꿔 넣어, 다른 기기에서 고친 달은 지키도록 합니다.
 */
const monthOf = d => (typeof d === "string" ? d : ymd(d)).slice(0, 7);
const monthLabel = m => `${+m.slice(5)}월`;
let rewardTouched = new Set();         // "아이|YYYY-MM"
let rewardTimer = null;
let rewardEditing = false;

function rewardsFor(kid, month) {
  return (sched.rewards || []).filter(r => r.kid === kid && r.month === month).sort((a, b) => a.need - b.need);
}
function stampsInMonth(kid, month) {
  return chalOf(kid).reduce((a, c) => a + c.stamps.filter(d => d.startsWith(month)).length, 0);
}
const rewardState = (r, n) => r.paidAt ? "paid" : n >= r.need ? "ready" : "wait";

function touchReward(kid, month) {
  rewardTouched.add(kid + "|" + month);
  writeLS(LS.sched, sched);
  syncState("busy", "보상 저장 대기");
  clearTimeout(rewardTimer);
  rewardTimer = setTimeout(flushRewards, 1200);
}
async function flushRewards() {
  clearTimeout(rewardTimer);
  if (!rewardTouched.size) return;
  if (!schedRepo.authed) { syncState("err", "토큰이 없어 보상을 저장하지 못했습니다"); return; }
  const keys = [...rewardTouched];
  const mine = (sched.rewards || []).filter(r => keys.includes(r.kid + "|" + r.month));
  try {
    await schedRepo.updateJson("schedule.json", cur => {
      const base = cur || JSON.parse(JSON.stringify(sched));
      const keep = (base.rewards || []).filter(r => !keys.includes(r.kid + "|" + r.month));
      base.rewards = keep.concat(mine);
      return base;
    }, "chore(reward): 이달의 보상");
    keys.forEach(k => rewardTouched.delete(k));
    syncState("ok", "보상 저장됨");
  } catch (e) { syncState("err", e.message); toast(e.message); }
}

/** 도장을 찍어 이달 합계가 어떤 단계를 넘으면 축하합니다 */
function rewardCrossCheck(kid, before, after, month) {
  for (const r of rewardsFor(kid, month)) {
    if (!r.paidAt && before < r.need && after >= r.need) {
      setTimeout(() => {
        celebrate(`🎁 ${monthLabel(month)} 보상 달성!`, `${r.need}개 모아서 → ${r.gift}. 부모님께 보여 주세요`, { emoji: "🎁", big: true });
        speak(`${monthLabel(month)} 보상 달성! ${r.gift} 받을 수 있어`);
      }, 3400);                      // 챌린지 축하와 겹치지 않게 조금 뒤에
    }
  }
}

function payReward(r) {
  if (!confirm(`"${r.gift}" 을(를) 지급했나요?`)) return;
  r.paidAt = nowDate().toISOString();
  touchReward(r.kid, r.month); render();
  toast(`🎁 ${r.gift} 지급 완료로 기록했습니다`);
}
function unpayReward(r) {
  if (!confirm("지급 기록을 되돌릴까요?")) return;
  r.paidAt = null;
  touchReward(r.kid, r.month); render();
}

function renderRewards() {
  const host = $("rewardBox");
  if (!host) return;
  const kid = oneKid();
  host.classList.toggle("hidden", !kid);
  if (!kid) return;
  const parent = isParent() && schedRepo.authed;
  const month = monthOf(nowDate());
  const n = stampsInMonth(kid, month);
  const tiers = rewardsFor(kid, month);

  $("rewardTitle").textContent = `🎁 ${monthLabel(month)}의 보상`;
  $("rewardCount").textContent = `이번 달 도장 ${n}개`;
  $("rewardEdit").classList.toggle("hidden", !parent);
  $("rewardEditor").classList.toggle("hidden", !(parent && rewardEditing));

  const box = $("rewardList");
  box.innerHTML = "";
  if (!tiers.length) {
    box.innerHTML = `<p class="chalempty">${parent ? "이번 달 보상을 정해 주세요. 챌린지 도장을 모으면 받는 선물이에요." : "이번 달 보상은 아직 정해지지 않았어요. 부모님께 물어보세요!"}</p>`;
  }
  for (const r of tiers) {
    const st = rewardState(r, n);
    const pct = Math.min(100, Math.round((n / r.need) * 100));
    const row = document.createElement("div");
    row.className = "rwrow " + st;
    row.innerHTML = `
      <div class="rwtop"><b class="rwneed">${r.need}개</b><span class="rwgift"></span><span class="rwst"></span></div>
      <div class="rwbar"><i style="width:${pct}%"></i></div>
      <div class="rwacts"></div>`;
    row.querySelector(".rwgift").textContent = r.gift;
    row.querySelector(".rwst").textContent =
      st === "paid" ? `✓ 받았어요 ${+r.paidAt.slice(5, 7)}/${+r.paidAt.slice(8, 10)}` :
      st === "ready" ? "🎉 받을 수 있어요!" : `${r.need - n}개 남았어`;
    const acts = row.querySelector(".rwacts");
    if (parent && st === "ready") {
      const b = document.createElement("button");
      b.type = "button"; b.className = "btn small go"; b.textContent = "지급하기";
      b.addEventListener("click", () => payReward(r)); acts.appendChild(b);
    }
    if (parent && st === "paid") {
      const b = document.createElement("button");
      b.type = "button"; b.className = "btn small"; b.textContent = "되돌리기";
      b.addEventListener("click", () => unpayReward(r)); acts.appendChild(b);
    }
    box.appendChild(row);
  }

  // 지난달에 채웠는데 아직 못 받은 보상 — 달이 바뀌어도 사라지지 않게
  const owed = (sched.rewards || []).filter(r => r.kid === kid && r.month < month && !r.paidAt &&
                                                 stampsInMonth(kid, r.month) >= r.need);
  if (owed.length) {
    const d = document.createElement("div");
    d.className = "rwowed";
    d.innerHTML = `<b>지난달에 모은 보상</b>`;
    for (const r of owed) {
      const line = document.createElement("div");
      line.className = "rwowedline";
      line.innerHTML = `<span></span>`;
      line.querySelector("span").textContent = `${monthLabel(r.month)} · ${r.need}개 → ${r.gift}`;
      if (parent) {
        const b = document.createElement("button");
        b.type = "button"; b.className = "btn small go"; b.textContent = "지급하기";
        b.addEventListener("click", () => payReward(r)); line.appendChild(b);
      } else line.insertAdjacentHTML("beforeend", `<span class="rwst">🎉 받을 수 있어요!</span>`);
      d.appendChild(line);
    }
    box.appendChild(d);
  }
}

/** 부모용 보상 편집 칸 */
function openRewardEditor() {
  const kid = oneKid(); if (!kid) return;
  rewardEditing = true;
  const month = monthOf(nowDate());
  const rows = rewardsFor(kid, month);
  const box = $("rewardRows");
  box.innerHTML = "";
  (rows.length ? rows : [{ need: 20, gift: "" }]).forEach(r => addRewardRow(r));
  render();
  setTimeout(() => { const f = box.querySelector("input.rwg"); if (f) f.focus(); }, 50);
}
function addRewardRow(r) {
  const box = $("rewardRows");
  const row = document.createElement("div");
  row.className = "rwedit";
  row.dataset.id = r.id || "";
  row.dataset.paid = r.paidAt || "";
  row.innerHTML = `
    <input type="number" class="rwn" min="1" max="200" value="${r.need || 20}" ${r.paidAt ? "disabled" : ""}>
    <span class="rwunit">개 →</span>
    <input type="text" class="rwg" maxlength="30" placeholder="예: 레고, 용돈 5000원" ${r.paidAt ? "disabled" : ""}>
    <button type="button" class="btn small danger rwdel" ${r.paidAt ? "disabled title='이미 지급한 보상'" : ""}>✕</button>`;
  row.querySelector(".rwg").value = r.gift || "";
  row.querySelector(".rwdel").addEventListener("click", () => row.remove());
  box.appendChild(row);
}
function saveRewardEditor() {
  const kid = oneKid(); if (!kid) return;
  const month = monthOf(nowDate());
  const old = new Map(rewardsFor(kid, month).map(r => [r.id, r]));
  const next = [];
  for (const row of document.querySelectorAll("#rewardRows .rwedit")) {
    const prev = old.get(row.dataset.id);
    if (prev && prev.paidAt) { next.push(prev); continue; }         // 지급한 건 그대로
    const need = Math.max(1, Math.min(200, Number(row.querySelector(".rwn").value) || 0));
    const gift = row.querySelector(".rwg").value.trim();
    if (!gift) continue;
    next.push({ id: prev ? prev.id : "r_" + uid(), kid, month, need, gift, paidAt: null });
  }
  sched.rewards = (sched.rewards || []).filter(r => !(r.kid === kid && r.month === month)).concat(next);
  rewardEditing = false;
  touchReward(kid, month); render();
  toast(next.length ? `🎁 ${monthLabel(month)} 보상 ${next.length}단계 저장` : "이번 달 보상을 비웠습니다");
}
function copyLastMonthRewards() {
  const kid = oneKid(); if (!kid) return;
  const now = nowDate();
  const last = monthOf(new Date(now.getFullYear(), now.getMonth() - 1, 15));
  const src = rewardsFor(kid, last);
  if (!src.length) { toast(`${monthLabel(last)}에 정한 보상이 없습니다`); return; }
  $("rewardRows").innerHTML = "";
  src.forEach(r => addRewardRow({ need: r.need, gift: r.gift }));
  toast(`${monthLabel(last)} 보상을 불러왔습니다. 저장을 누르세요`);
}

/* ===================== 자동 업데이트 =====================
 * 1) 화면·기능 코드 — GitHub Pages 에 새로 게시되면 version.json 의 커밋 값이 바뀝니다.
 *    켜 둔 앱이 그걸 보면, 저장 안 된 기록이 없을 때 다음에 화면으로 돌아오는 순간 새로 고칩니다.
 *    (APK 도 원격 모드라 같은 방식으로 따라옵니다)
 * 2) APK 자체 — 알림·위치처럼 네이티브가 바뀌어 새 Release 가 나오면, 앱 안에 "설치하기"를 띄웁니다.
 *    누르면 시스템 브라우저가 APK 를 받습니다. 설치는 안드로이드가 한 번 물어봅니다.
 */
let webVer = null, webVerNew = null;
let reloadPage = () => location.reload();       // 한 곳으로 모아 둡니다
let webVerInfo = null;            // 지금 화면 버전 {sha, time, run}
let apkVerInfo = null;            // {installed, latest}
async function readWebVersion(full) {
  try {
    const r = await fetch("./version.json?t=" + Date.now(), { cache: "no-store" });
    if (!r.ok) return null;
    const j = await r.json();
    if (full) return j;
    return j && j.sha ? String(j.sha) : null;
  } catch (e) { return null; }
}
const hasUnsaved = () =>
  Object.values(dirtyMap).some(x => x.size) || dirtyMeta.size ||
  Object.values(chalDirty).some(x => x.size) || Object.values(chalDeleted).some(x => x.size) ||
  rewardTouched.size || editing || rewardEditing;

async function checkWebUpdate() {
  const j = await readWebVersion(true);
  const v = j && j.sha ? String(j.sha) : null;
  if (!v) return;
  if (!webVer) { webVer = v; webVerInfo = j; paintVersion(); return; }
  if (v !== webVer) {
    webVerNew = v;
    const b = $("updBar");
    if (b) {
      b.classList.remove("hidden");
      $("updText").textContent = "새 버전이 나왔어요";
      $("updBtn").textContent = "지금 적용";
      $("updBtn").onclick = applyWebUpdate;
    }
  }
}
function applyWebUpdate() {
  if (hasUnsaved()) { flush(); flushChallenges(); flushRewards(); toast("저장 중이에요. 잠시 뒤 다시 눌러 주세요"); return; }
  reloadPage();
}
/** 화면으로 돌아왔을 때, 새 버전이 있고 저장할 게 없으면 조용히 적용합니다 */
function maybeAutoReload() {
  if (webVerNew && !hasUnsaved()) reloadPage();
}

/* ---- APK 새 버전 ---- */
const isNative = () => !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
function verNums(v) {
  const m = String(v || "").replace(/^v/, "").match(/^(\d+)(?:\.(\d+))?(?:\.(\d+))?/);
  return m ? [+m[1], +(m[2] || 0), +(m[3] || 0)] : [0, 0, 0];
}
function newerThan(a, b) {
  const x = verNums(a), y = verNums(b);
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i];
  return false;
}
const LS_APKCHK = "ks2.apkcheck.v1";
const LS_APKSNOOZE = "ks2.apksnooze.v1";
function closeUpdBar() {
  const b = $("updBar");
  if (b.classList.contains("apk") && b.dataset.tag)
    writeLS(LS_APKSNOOZE, { tag: b.dataset.tag, until: Date.now() + 3 * 24 * 3600 * 1000 });
  b.classList.add("hidden");
}

/** 설정 탭 맨 아래 "버전" 칸 */
function paintVersion() {
  const el = $("verInfo");
  if (!el) return;
  const lines = [];
  if (webVerInfo) {
    const t = webVerInfo.time ? new Date(webVerInfo.time) : null;
    lines.push(`화면 #${webVerInfo.run || "?"}` +
      (t ? ` · ${t.getMonth() + 1}/${t.getDate()} ${pad(t.getHours())}:${pad(t.getMinutes())} 게시` : "") +
      ` · ${String(webVerInfo.sha).slice(0, 7)}`);
  } else {
    lines.push("화면 — 게시 정보 없음(PC 미리보기 등)");
  }
  if (isNative()) {
    const a = apkVerInfo || {};
    lines.push(`앱(APK) ${a.installed ? "v" + String(a.installed).replace(/^v/, "") : "확인 중"}` +
      (a.latest ? ` · 최신 ${a.latest}` : ""));
  }
  el.innerHTML = lines.map(l => `<div>${esc(l)}</div>`).join("");
}
async function checkApkUpdate(force) {
  if (!isNative()) return;
  const last = readLS(LS_APKCHK, 0);
  if (!force && Date.now() - last < 12 * 3600 * 1000) return;     // 하루 두 번이면 충분합니다
  writeLS(LS_APKCHK, Date.now());
  try {
    const info = await Capacitor.Plugins.App.getInfo();          // 설치된 APK 의 versionName
    apkVerInfo = { installed: info.version, latest: null }; paintVersion();
    const r = await fetch(`https://api.github.com/repos/${conn.owner}/${conn.repo}/releases/latest`,
                          { headers: { Accept: "application/vnd.github+json" } });
    if (!r.ok) return;
    const rel = await r.json();
    apkVerInfo.latest = rel.tag_name; paintVersion();
    const apk = (rel.assets || []).find(a => /\.apk$/i.test(a.name));
    if (!apk || !newerThan(rel.tag_name, info.version)) return;
    // ✕ 로 닫은 버전은 3일 동안 다시 띄우지 않습니다(키즈폰은 설치가 막혀 있어 계속 뜨면 괴롭습니다)
    const snooze = readLS(LS_APKSNOOZE, {});
    if (!force && snooze.tag === rel.tag_name && Date.now() < snooze.until) return;
    const b = $("updBar");
    b.classList.remove("hidden");
    b.classList.add("apk");
    b.dataset.tag = rel.tag_name;
    $("updText").textContent = isChild()
      ? `새 앱 ${rel.tag_name} — 부모님께 설치를 부탁해요`
      : `새 앱 ${rel.tag_name} (지금 ${info.version})`;
    $("updBtn").textContent = "설치하기";
    $("updBtn").onclick = () => {
      toast("다운로드가 끝나면 알림에서 열어 설치하세요");
      location.href = apk.browser_download_url;        // 다른 도메인 → 시스템 브라우저가 받습니다
    };
  } catch (e) { /* 조용히 넘어갑니다 */ }
}

/* ===================== 다른 기기 연결 (QR) =====================
 * 설정(저장소·역할·아이·토큰)을 주소의 # 뒤에 담아 QR 로 보여 줍니다.
 * 아이 폰 카메라로 찍으면 앱이 열리면서 한 번에 설정됩니다.
 *
 * # 뒤(fragment)는 브라우저가 서버로 보내지 않습니다. GitHub Pages 접속 기록에도 남지 않습니다.
 * 읽은 즉시 주소창에서 지워 방문 기록에도 남기지 않습니다.
 * 다만 QR 을 사진으로 찍어 두면 누구나 토큰을 얻으므로, 2분 뒤 화면에서 자동으로 지웁니다.
 */
function b64urlEncode(str) {
  return GH.b64encode(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlDecode(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return GH.b64decode(s);
}
/**
 * QR 이 가리킬 주소. "지금 열려 있는 주소"를 쓰면 안 됩니다.
 * APK 안에서는 https://localhost, PC 미리보기에서는 http://localhost:8080 이라
 * 다른 폰이 찍으면 자기 자신에게 접속하려다 실패합니다. 항상 GitHub Pages 주소로 만듭니다.
 */
function pagesBase() {
  if (cfg && cfg.pagesUrl) return cfg.pagesUrl.replace(/\/?$/, "/");
  const owner = String(conn.owner || "").toLowerCase();
  const repo = String(conn.repo || "");
  if (!owner || !repo) return location.origin + location.pathname;
  // 저장소 이름이 "아이디.github.io" 이면 최상위 주소가 됩니다
  if (repo.toLowerCase() === `${owner}.github.io`) return `https://${owner}.github.io/`;
  return `https://${owner}.github.io/${repo}/`;
}

function makeJoinLink(opts) {
  const p = {
    v: 1, o: conn.owner, r: conn.repo, b: conn.branch,
    so: conn.statusOwner || undefined, sr: conn.statusRepo || undefined,
    sb: conn.statusBranch && conn.statusBranch !== "main" ? conn.statusBranch : undefined,
    role: opts.role, who: opts.who, t: opts.token || undefined
  };
  return `${pagesBase()}#join=${b64urlEncode(JSON.stringify(p))}`;
}
function readJoinHash(text) {
  const src = text != null ? String(text) : (location.hash || "");
  const m = src.match(/#join=([A-Za-z0-9_-]+)/);
  if (!m) return null;
  try {
    const p = JSON.parse(b64urlDecode(m[1]));
    if (p.v !== 1 || !p.o || !p.r) return null;
    return p;
  } catch (e) { return null; }
}
/** 주소에 연결 정보가 있으면 적용합니다. 적용했으면 true */
function applyJoinFromHash(pasted) {
  const p = readJoinHash(pasted);
  if (!p) return false;
  // 읽자마자 주소창·방문 기록에서 지웁니다
  if (pasted == null) { try { history.replaceState(null, "", location.pathname + location.search); } catch (e) { } }

  const roleName = { parent: "부모", child: "아이", viewer: "보기만" }[p.role] || "보기만";
  if (!confirm(`이 기기를 "${roleName}" 기기로 연결할까요?\n저장소: ${p.o}/${p.r}` +
               (p.t ? "\n토큰도 함께 저장됩니다." : ""))) return false;

  conn = Object.assign({}, conn, {
    owner: p.o, repo: p.r, branch: p.b || "main",
    statusOwner: p.so || null, statusRepo: p.sr || null, statusBranch: p.sb || "main",
    role: ["parent", "child", "viewer"].includes(p.role) ? p.role : "viewer",
    who: p.who || conn.who
  });
  writeLS(LS.conn, conn);
  if (p.t) writeLS(LS.token, p.t);
  return true;
}

let joinTimer = null;
function showJoinQR() {
  const role = $("joinRole").value;
  const kidId = $("joinKid").value;
  const pasted = $("joinToken").value.trim();
  const token = pasted || readLS(LS.token, "") || "";
  if (role !== "viewer" && !token) { toast("넘겨줄 토큰이 없습니다. 이 기기에 먼저 넣거나 칸에 붙여넣으세요."); return; }
  if (pasted && !/^(github_pat_|ghp_)[A-Za-z0-9_]+$/.test(pasted)) { toast("토큰 모양이 아닙니다. github_pat_ 로 시작해야 합니다."); return; }

  const link = makeJoinLink({ role, who: role === "parent" ? "all" : kidId, token: role === "viewer" ? "" : token });
  const q = qrcode(0, "M");
  q.addData(link); q.make();
  $("joinQR").innerHTML = q.createSvgTag({ cellSize: 5, margin: 4, scalable: true });
  $("joinQR").dataset.link = link;
  $("joinBox").classList.remove("hidden");

  const k = role === "parent" ? null : kidById(kidId);
  $("joinWho").textContent =
    `${{ parent: "부모", child: "아이", viewer: "보기만" }[role]} 기기` + (k ? ` · ${k.emoji} ${k.name}` : role === "parent" ? " · 아이 전체" : "") +
    (role === "viewer" ? " · 토큰 없음" : pasted ? " · 붙여넣은 토큰" : " · 이 기기 토큰");

  // 2분 뒤 지웁니다. 화면 사진으로 토큰이 새는 것을 줄이려는 것입니다.
  let left = 120;
  clearInterval(joinTimer);
  $("joinLeft").textContent = "2:00 뒤 사라집니다";
  joinTimer = setInterval(() => {
    left--;
    $("joinLeft").textContent = `${Math.floor(left / 60)}:${pad(left % 60)} 뒤 사라집니다`;
    if (left <= 0) hideJoinQR();
  }, 1000);
}
function hideJoinQR() {
  clearInterval(joinTimer);
  const box = $("joinBox");
  if (!box) return;
  box.classList.add("hidden");
  $("joinQR").innerHTML = "";
  delete $("joinQR").dataset.link;
}
function paintJoinSettings() {
  const sel = $("joinKid");
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = kids().map(k => `<option value="${k.id}">${k.emoji} ${esc(k.name)}</option>`).join("");
  sel.value = kids().some(k => k.id === cur) ? cur : (kids()[0] || {}).id || "";
  $("joinPanel").classList.toggle("hidden", !isParent());
}

/* ===================== 한 번에 고치기 (글로 쓰는 일정표) =====================
 * 한 줄이 규칙 하나입니다.
 *   [요일 또는 날짜] [시작]-[끝] [제목] [옵션...]
 *   평일 19:00-19:30 영어 (아이보람) #기록:책,듣기,낭독
 *   월수 16:00-17:00 태권도 @상가 2층 제한60
 *   10/15 14:00-15:00 치과
 * 요일: 월화수목금토일 조합, 월~금 범위, 평일, 주말, 매일
 * 옵션: @장소  제한N  #기록:항목,…  #종류:학원  #체크없음  #공휴일도
 * 종류는 제목에서 짐작합니다(태권도→운동, 학원→학원 …). 짐작이 틀리면 #종류: 로 지정.
 *
 * 적용할 때 기존 일정과 (요일/날짜 + 제목)이 같으면 그 id 를 그대로 씁니다.
 * id 가 바뀌면 지난 체크 기록과 연결이 끊기기 때문입니다. 장소 좌표(geo)도 이어받습니다.
 */
const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0];                 // 월요일부터
const DAY_CH = { "월": 1, "화": 2, "수": 3, "목": 4, "금": 5, "토": 6, "일": 0 };
const KIND_SHORT = { "학교": "school", "학원": "academy", "공부": "study", "숙제": "study",
  "운동": "sport", "생활": "life", "놀이": "play", "독서": "read" };
const KIND_NAME = { school: "학교", academy: "학원", study: "공부", sport: "운동", life: "생활", play: "놀이", read: "독서" };
const DETAIL_SHORT = { "페이지": "pages", "쪽": "pages", "채점": "graded", "오답": "redo",
  "책": "book", "읽은책": "book", "듣기": "listen", "낭독": "speak", "단어": "words", "메모": "memo" };
const DETAIL_NAME = { pages: "페이지", graded: "채점", redo: "오답", book: "책", listen: "듣기", speak: "낭독", words: "단어", memo: "메모" };

/** 제목으로 종류를 짐작합니다. 앞에 있는 것이 우선입니다("수학 학원" → 학원). */
const KIND_HINTS = [
  ["school",  ["학교", "등교"]],
  ["academy", ["학원", "피아노", "미술", "바이올린", "과외", "공부방", "코딩", "첼로", "플루트"]],
  ["read",    ["독서", "책 읽", "책읽"]],
  ["sport",   ["태권도", "수영", "축구", "농구", "줄넘기", "운동", "발레", "체조", "합기도", "야구", "배드민턴", "스케이트"]],
  ["study",   ["숙제", "영어", "수학", "국어", "과학", "사회", "한자", "공부", "문제집", "학습지", "연산", "받아쓰기"]],
  ["life",    ["기상", "일어나", "잘 준비", "취침", "정리", "양치", "씻", "준비", "식사", "밥"]],
  ["play",    ["놀이", "게임", "놀기", "쉬는", "tv", "유튜브"]]
];
function guessKind(title) {
  const t = String(title).toLowerCase();
  for (const [k, words] of KIND_HINTS) if (words.some(w => t.includes(w))) return k;
  return "study";
}

/** "16:00" "9:30" "16시" "4시30분" → "HH:MM" */
function normTime(s) {
  let m = String(s).match(/^(\d{1,2}):(\d{2})$/);
  if (!m) m = String(s).match(/^(\d{1,2})시(?:(\d{1,2})분?)?$/);
  if (!m) return null;
  const h = Number(m[1]), mi = Number(m[2] || 0);
  if (h > 23 || mi > 59) return null;
  return `${pad(h)}:${pad(mi)}`;
}

/** 요일 표현 → 요일 번호 배열. 못 읽으면 null */
function parseDays(tok) {
  if (tok === "매일") return [0, 1, 2, 3, 4, 5, 6];
  if (tok === "평일") return [1, 2, 3, 4, 5];
  if (tok === "주말") return [6, 0];
  const r = tok.match(/^([월화수목금토일])[~\-]([월화수목금토일])$/);
  if (r) {
    const a = DAY_ORDER.indexOf(DAY_CH[r[1]]), b = DAY_ORDER.indexOf(DAY_CH[r[2]]);
    if (a > b) return null;
    return DAY_ORDER.slice(a, b + 1);
  }
  if (/^[월화수목금토일]+$/.test(tok)) {
    const set = [...new Set([...tok].map(c => DAY_CH[c]))];
    return DAY_ORDER.filter(d => set.includes(d));
  }
  return null;
}

/** 날짜 표현 → "YYYY-MM-DD". "2026-10-15", "10/15", "10.15" */
function parseDate(tok) {
  let m = tok.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) return `${m[1]}-${pad(+m[2])}-${pad(+m[3])}`;
  m = tok.match(/^(\d{1,2})[\/.](\d{1,2})$/);
  if (m) {
    const y = nowDate().getFullYear(), mo = +m[1], d = +m[2];
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
    return `${y}-${pad(mo)}-${pad(d)}`;
  }
  return null;
}

/** 글 전체 → 규칙 목록과 줄별 오류 */
function parseScheduleText(text) {
  const rules = [], errors = [];
  String(text).split(/\r?\n/).forEach((raw, i) => {
    const line = raw.trim();
    const no = i + 1;
    if (!line || line.startsWith("//")) return;

    const parts = line.split(/\s+/);
    const when = parts.shift();
    const days = parseDays(when);
    const date = days ? null : parseDate(when);
    if (!days && !date) { errors.push({ no, msg: `"${when}" 을(를) 요일이나 날짜로 읽지 못했습니다` }); return; }

    const tm = (parts.shift() || "").split(/[~\-]/);
    const start = normTime(tm[0]);
    const end = tm[1] ? normTime(tm[1]) : "";
    if (!start) { errors.push({ no, msg: `시작 시간이 없습니다 (예: 16:00-17:00)` }); return; }
    if (tm[1] && !end) { errors.push({ no, msg: `끝 시간 "${tm[1]}" 을(를) 읽지 못했습니다` }); return; }
    if (end && mins(end) <= mins(start)) { errors.push({ no, msg: `끝 시간이 시작보다 빠릅니다` }); return; }

    // 나머지: 제목과 옵션을 가릅니다. @장소는 뒤따르는 말까지 옵션이 나올 때까지 이어 붙입니다.
    const title = [], place = [];
    let kind = null, limitMin = null, track = true, onHoliday = "skip", detail = [], mode = "title";
    for (const w of parts) {
      if (w.startsWith("@")) { mode = "place"; if (w.length > 1) place.push(w.slice(1)); continue; }
      let m;
      if ((m = w.match(/^제한(\d{1,3})분?$/))) { limitMin = +m[1]; mode = "opt"; continue; }
      if ((m = w.match(/^#종류:(.+)$/))) {
        const k = KIND_SHORT[m[1]];
        if (!k) { errors.push({ no, msg: `종류 "${m[1]}" 은(는) 없습니다 (학교·학원·공부·운동·생활·놀이·독서)` }); return; }
        kind = k; mode = "opt"; continue;
      }
      if ((m = w.match(/^#기록:(.+)$/))) {
        for (const x of m[1].split(",").map(s => s.trim()).filter(Boolean)) {
          const d = DETAIL_SHORT[x];
          if (!d) { errors.push({ no, msg: `기록 항목 "${x}" 은(는) 없습니다 (페이지·채점·오답·책·듣기·낭독·단어·메모)` }); return; }
          if (!detail.includes(d)) detail.push(d);
        }
        mode = "opt"; continue;
      }
      if (w === "#체크없음") { track = false; mode = "opt"; continue; }
      if (w === "#공휴일도") { onHoliday = "keep"; mode = "opt"; continue; }
      if (w.startsWith("#")) { errors.push({ no, msg: `"${w}" 은(는) 모르는 옵션입니다` }); return; }
      (mode === "place" ? place : title).push(w);
    }
    const t = title.join(" ").trim();
    if (!t) { errors.push({ no, msg: `제목이 없습니다` }); return; }
    rules.push({
      no, days, date, start, end, title: t, place: place.join(" "),
      kind: kind || guessKind(t), limitMin, track, onHoliday, detail
    });
  });
  return { rules, errors };
}

/** 요일 배열 → 가장 짧은 표현 */
function daysToText(days) {
  const s = DAY_ORDER.filter(d => days.includes(d));
  const key = s.join(",");
  if (key === "1,2,3,4,5,6,0") return "매일";
  if (key === "1,2,3,4,5") return "평일";
  if (key === "6,0") return "주말";
  const idx = s.map(d => DAY_ORDER.indexOf(d));
  const run = idx.length >= 3 && idx.every((v, i) => i === 0 || v === idx[i - 1] + 1);
  if (run) return `${DOW[s[0]]}~${DOW[s[s.length - 1]]}`;
  return s.map(d => DOW[d]).join("");
}

/** 지금 일정을 글로. 같은 내용이 여러 요일에 있으면 한 줄로 묶습니다. */
function schedToText(kidId) {
  const opt = e => {
    const o = [];
    if (e.place) o.push("@" + e.place);
    if (e.limitMin != null) o.push(`제한${e.limitMin}`);
    if (e.kind !== guessKind(e.title)) o.push(`#종류:${KIND_NAME[e.kind] || "공부"}`);
    if ((e.detail || []).length) o.push("#기록:" + e.detail.map(d => DETAIL_NAME[d]).join(","));
    if (e.track === false) o.push("#체크없음");
    if (e.onHoliday === "keep") o.push("#공휴일도");
    return o.join(" ");
  };
  const groups = new Map();
  for (const e of sched.weekly.filter(x => x.kid === kidId)) {
    const k = [e.start, e.end, e.title, opt(e)].join("|");
    if (!groups.has(k)) groups.set(k, { e, days: [] });
    groups.get(k).days.push(e.day);
  }
  const lines = [...groups.values()]
    .sort((a, b) => mins(a.e.start) - mins(b.e.start) ||
                    DAY_ORDER.indexOf(Math.min(...a.days.map(d => DAY_ORDER.indexOf(d)))) -
                    DAY_ORDER.indexOf(Math.min(...b.days.map(d => DAY_ORDER.indexOf(d)))))
    .map(g => [daysToText(g.days), `${g.e.start}${g.e.end ? "-" + g.e.end : ""}`, g.e.title, opt(g.e)]
      .filter(Boolean).join(" "));
  const once = sched.once.filter(x => x.kid === kidId && x.date >= ymd(nowDate()))
    .sort((a, b) => a.date.localeCompare(b.date) || mins(a.start) - mins(b.start))
    .map(e => [e.date, `${e.start}${e.end ? "-" + e.end : ""}`, e.title, opt(e)].filter(Boolean).join(" "));
  return lines.concat(once.length ? ["", "// 하루만 있는 일정", ...once] : []).join("\n");
}

const FIELDS = ["start", "end", "title", "place", "kind", "limitMin", "track", "onHoliday", "detail"];
const same = (a, b) => FIELDS.every(f => JSON.stringify(a[f] ?? null) === JSON.stringify(b[f] ?? null));

/**
 * 규칙을 실제 일정으로 펼치고, 지금 일정과 비교합니다.
 * 이 아이의 반복 일정과 "오늘 이후" 하루짜리 일정만 바꿉니다. 지난 날짜 일정은 그대로 둡니다.
 */
function planBulk(kidId, rules) {
  const oldW = sched.weekly.filter(e => e.kid === kidId);
  const today = ymd(nowDate());
  const oldO = sched.once.filter(e => e.kid === kidId && e.date >= today);
  const used = new Set();
  const nextW = [], nextO = [];
  const diff = { add: [], change: [], same: 0, remove: [] };

  const adopt = (pool, match, fresh) => {
    const hit = pool.find(x => !used.has(x.id) && match(x) && x.start === fresh.start)
             || pool.find(x => !used.has(x.id) && match(x));
    if (hit) {
      used.add(hit.id);
      const merged = { ...fresh, id: hit.id, geo: hit.geo || null, off: hit.off || [] };
      if (same(hit, merged)) diff.same++; else diff.change.push({ from: hit, to: merged });
      return merged;
    }
    const n = { ...fresh, id: uid(), geo: null, off: [] };
    diff.add.push(n);
    return n;
  };

  for (const r of rules) {
    const base = { kid: kidId, start: r.start, end: r.end, title: r.title, place: r.place, kind: r.kind,
                   limitMin: r.limitMin, track: r.track, onHoliday: r.onHoliday, detail: r.detail };
    if (r.days) for (const d of r.days)
      nextW.push(adopt(oldW, x => x.day === d && x.title === r.title, { ...base, day: d }));
    else
      nextO.push(adopt(oldO, x => x.date === r.date && x.title === r.title, { ...base, date: r.date }));
  }
  for (const x of oldW.concat(oldO)) if (!used.has(x.id)) diff.remove.push(x);
  return { nextW, nextO, diff };
}

function applyBulk(kidId, plan) {
  const today = ymd(nowDate());
  sched.weekly = sched.weekly.filter(e => e.kid !== kidId).concat(plan.nextW);
  sched.once = sched.once.filter(e => e.kid !== kidId || e.date < today).concat(plan.nextO);
  writeLS(LS.sched, sched);
}

let bulkPlan = null;
function bulkPreview() {
  const kid = oneKid(); if (!kid) return;
  const { rules, errors } = parseScheduleText($("bulkText").value);
  const out = $("bulkOut");
  bulkPlan = null;
  $("bulkApply").disabled = true;

  if (errors.length) {
    out.innerHTML = `<p class="bulkerr">고칠 줄이 ${errors.length}개 있습니다.</p><ul class="bulklist">` +
      errors.map(e => `<li><b>${e.no}번째 줄</b> ${esc(e.msg)}</li>`).join("") + `</ul>`;
    return;
  }
  const plan = planBulk(kid, rules);
  const D = plan.diff;
  const label = e => `${e.day != null ? DOW[e.day] : e.date.slice(5)} ${e.start} ${esc(e.title)}`;
  let h = `<p class="bulksum">추가 <b>${D.add.length}</b> · 변경 <b>${D.change.length}</b> · 삭제 <b>${D.remove.length}</b> · 그대로 ${D.same}</p>`;
  const sec = (title, arr, fmt) => arr.length
    ? `<details open><summary>${title} ${arr.length}</summary><ul class="bulklist">${arr.slice(0, 40).map(fmt).join("")}</ul></details>` : "";
  h += sec("➕ 추가", D.add, e => `<li>${label(e)} <span class="kindtag">${KIND_NAME[e.kind]}</span></li>`);
  h += sec("✏️ 변경", D.change, c => `<li>${label(c.to)}${c.from.start !== c.to.start ? ` <span class="was">(${c.from.start}→${c.to.start})</span>` : ""}</li>`);
  h += sec("🗑 삭제", D.remove, e => `<li class="rm">${label(e)}</li>`);
  if (!D.add.length && !D.change.length && !D.remove.length) h += `<p class="hint">바뀌는 것이 없습니다.</p>`;
  out.innerHTML = h;
  bulkPlan = plan;
  $("bulkApply").disabled = !(D.add.length || D.change.length || D.remove.length);
}

/* ===================== 음성 알림 =====================
 * 일정 제목을 그대로 읽어 줍니다. 소리는 화면 알림보다 훨씬 빨리 질리므로
 * 네 가지 제동을 걸어 둡니다.
 *   1) 하루 최대 횟수 (기본 8회)
 *   2) 조용한 시간대 (기본 21:30~07:00) 에는 말하지 않음
 *   3) 같은 일정의 같은 상황은 하루 한 번만
 *   4) 문구를 여러 개 돌려 씀 — 같은 말 반복이 제일 지치게 합니다
 * 브라우저 정책상 사용자가 한 번 눌러 켜야 소리가 납니다. 앱이 닫히면 울리지 않습니다.
 */
const LS_VOICE = "ks2.voice.v1";
const LS_VCNT = "ks2.voicecount.v1";
const voiceCfg = () => Object.assign(
  { on: false, uri: "", rate: 0.95, maxPerDay: 8, quietFrom: "21:30", quietTo: "07:00" },
  readLS(LS_VOICE, {}));
/* 음성 엔진은 두 가지입니다.
 *  - 브라우저(크롬·사파리·엣지): Web Speech API (speechSynthesis)
 *  - APK: 안드로이드 WebView 에는 Web Speech API 가 없습니다(크롬 개발팀 문서에 명시).
 *         그래서 안드로이드 자체 TextToSpeech 를 Capacitor 플러그인(@capacitor-community/text-to-speech)으로 씁니다.
 */
const nativeTTS = () => {
  const C = typeof window !== "undefined" ? window.Capacitor : null;
  return (C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.TextToSpeech) || null;
};
const webTTS = () => typeof window !== "undefined" && "speechSynthesis" in window;
const hasTTS = () => !!nativeTTS() || webTTS();
let ttsKoOk = null;          // 안드로이드: 한국어 음성 데이터가 설치돼 있는지(null=아직 모름)

let voiceList = [];
function loadVoices() {
  const N = nativeTTS();
  if (N) {
    // 안드로이드 목소리 목록. speak 의 voice 옵션은 이 목록의 "번호"입니다.
    N.getSupportedVoices().then(r => {
      voiceList = ((r && r.voices) || []).map((x, i) => Object.assign({}, x, { _idx: i }));
      paintVoiceSettings();
    }).catch(() => { });
    N.isLanguageSupported({ lang: "ko-KR" }).then(r => { ttsKoOk = !!(r && r.supported); paintVoiceSettings(); })
      .catch(() => { });
    return;
  }
  if (!webTTS()) return;
  voiceList = window.speechSynthesis.getVoices() || [];
  // 목록이 늦게 채워지는 브라우저가 있습니다.
  if (!loadVoices._bound) {
    loadVoices._bound = true;
    window.speechSynthesis.addEventListener?.("voiceschanged", () => {
      voiceList = window.speechSynthesis.getVoices() || [];
      paintVoiceSettings();
    });
  }
}
const koVoices = () => voiceList.filter(v => (v.lang || "").toLowerCase().startsWith("ko"));

/** 조용한 시간대인지. 자정을 넘는 구간도 다룹니다. */
function inQuietHours(cfgv) {
  const nm = nowMin(), a = mins(cfgv.quietFrom), b = mins(cfgv.quietTo);
  return a <= b ? (nm >= a && nm < b) : (nm >= a || nm < b);
}
function voiceCountToday() {
  const c = readLS(LS_VCNT, {});
  return c.date === dayKey ? (c.n || 0) : 0;
}
function bumpVoiceCount() { writeLS(LS_VCNT, { date: dayKey, n: voiceCountToday() + 1 }); }

/**
 * 말하기. 막히는 경우(꺼짐·조용한 시간·횟수 초과)에는 조용히 아무것도 하지 않습니다.
 * @param {string} text  읽을 말
 * @param {boolean} force 설정 미리듣기처럼 제동을 건너뛸 때
 */
function speak(text, force) {
  if (!hasTTS() || !text) return false;
  const v = voiceCfg();
  if (!force) {
    if (!v.on) return false;
    if (inQuietHours(v)) return false;
    if (voiceCountToday() >= v.maxPerDay) return false;
  }
  const N = nativeTTS();
  if (N) {
    const pv = voiceList.find(x => x.voiceURI === v.uri) || koVoices()[0];
    const opt = { text, lang: "ko-KR", rate: Number(v.rate) || 0.95, pitch: 1.05, volume: 1.0,
                  category: "ambient", queueStrategy: 0 };     // 0 = 앞엣것을 끊고 바로 말함
    if (pv && pv._idx != null) opt.voice = pv._idx;
    N.stop().catch(() => { }).finally(() => N.speak(opt).catch(() => { }));
    if (!force) bumpVoiceCount();
    return true;
  }
  if (!webTTS()) return false;
  try {
    const u = new SpeechSynthesisUtterance(text);
    const pick = voiceList.find(x => x.voiceURI === v.uri) || koVoices()[0];
    if (pick) { u.voice = pick; u.lang = pick.lang; } else { u.lang = "ko-KR"; }
    u.rate = Number(v.rate) || 0.95;
    u.pitch = 1.05;
    window.speechSynthesis.cancel();      // 밀리지 않게 앞엣것은 끊습니다
    window.speechSynthesis.speak(u);
    if (!force) bumpVoiceCount();
    return true;
  } catch (e) { return false; }
}

/* 같은 상황을 하루에 두 번 말하지 않습니다 */
const saidToday = new Set();
function sayOnce(key, text) {
  if (saidToday.has(key)) return;
  if (speak(text)) saidToday.add(key);
}

/** 일정 제목을 넣은 말들. 같은 말이 반복되지 않게 돌려 씁니다. */
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const sayPre = (title, m) => pick([
  `${m}분 뒤에 ${title} 할 시간이야`,
  `곧 ${title} 시작이야. ${m}분 남았어`,
  `${title} 준비할 시간이야. ${m}분 뒤야`
]);
const sayStart = title => pick([
  `${title} 시작할 시간이야`,
  `자, ${title} 하러 가자`,
  `지금부터 ${title}야`
]);
const sayOver = title => pick([
  `${title} 시간이 조금 지났어. 마무리해 볼까`,
  `${title} 정리할 시간이야`
]);

/* ===================== 성취 표시 =====================
 * 설계 원칙 세 가지:
 *  1) 연속 기록이 끊겨도 나무라지 않습니다. 끊기면 배지가 조용히 사라질 뿐입니다.
 *  2) 제한시간을 넘겨도 "완료"는 축하합니다. 끝까지 한 것이 더 중요합니다.
 *  3) 형제끼리 비교하는 화면은 만들지 않습니다.
 */
const PRAISE = ["잘했어! 🎉", "좋아, 하나 끝! 👏", "멋지다! ✨", "착착 해내는 중! 💪", "오늘도 해냈네! 🌟"];
const PRAISE_OVER = ["끝까지 해낸 게 더 멋져! 👏", "포기 안 했네, 잘했어! 💪", "시간은 넘었지만 완주! 🎯"];

/** 오늘 진행 상황 */
function todayProgress(kidId) {
  const nm = nowMin();
  const all = eventsOn(nowDate(), kidId).filter(e => e.track !== false);

  /* 체크 창이 닫혀 이제 손쓸 수 없는 것(missed)은 분모에서 뺍니다.
     안 그러면 아침에 하나 놓친 날은 저녁에 아무리 해도 100%가 되지 않고,
     아이에게 "이미 망한 날"이 되어 버립니다. 놓친 수는 따로 셉니다. */
  const alive = [], recs = [];
  let missed = 0;
  for (const e of all) {
    const r = (dayMap[e.kid] && dayMap[e.kid].items[e.id]) || null;
    if (stateOf(e, r, nm) === "missed") { missed++; continue; }
    alive.push(e); recs.push(r);
  }
  const list = alive;
  const done = recs.filter(r => r && ["done", "over"].includes(r.state)).length;
  const own = Object.values((dayMap[kidId] && dayMap[kidId].own) || {});
  return {
    total: list.length, done, missed, planned: all.length,
    pct: list.length ? Math.round((done / list.length) * 100) : 0,
    allDone: list.length > 0 && done === list.length,
    inTime: recs.filter(r => r && r.state === "done").length,
    overCnt: recs.filter(r => r && r.state === "over").length,
    ownTotal: own.length,
    ownDone: own.filter(o => ["done", "over"].includes(o.state)).length
  };
}

/** 오늘 화면에 띄울 배지. 없으면 빈 배열. */
function todayBadges(kidId) {
  const p = todayProgress(kidId);
  const out = [];
  if (p.allDone) out.push({ e: "🎉", t: "오늘 계획 다 했어요" });
  else if (p.total && p.pct >= HOT_PCT) out.push({ e: "🔥", t: `${HOT_PCT}% 돌파 · ${p.total - p.done}개 남음` });
  if (p.allDone && p.overCnt === 0 && p.total >= 2) out.push({ e: "⏱", t: "전부 시간 안에" });
  const early = eventsOn(nowDate(), kidId).filter(e => e.track !== false && wasEarly(e, recOf(e))).length;
  if (early) out.push({ e: "⏩", t: `미리 해낸 것 ${early}개` });
  if (p.ownTotal && p.ownDone === p.ownTotal) out.push({ e: "🌱", t: "스스로 정한 것도 완료" });
  else if (p.ownDone) out.push({ e: "🌱", t: `스스로 ${p.ownDone}개 해냄` });
  const R = reflectOf(kidId);
  if (R && (R.rating || R.good)) out.push({ e: "📝", t: "오늘 돌아보기 완료" });
  return out;
}

function renderProgress() {
  const host = $("progWrap");
  if (!host) return;
  const kid = oneKid();
  host.classList.toggle("hidden", !kid);
  if (!kid) return;

  const p = todayProgress(kid);
  // 오늘 체크할 수 있는 게 하나도 없으면 빈 링을 띄워 두지 않습니다.
  $("ringWrap").classList.toggle("hidden", p.total === 0);
  const C = 2 * Math.PI * 26;                       // 반지름 26 원둘레
  $("progArc").setAttribute("stroke-dasharray", `${(C * p.pct) / 100} ${C}`);
  $("progText").textContent = p.total ? `${p.done}/${p.total}` : "—";
  $("progMiss").textContent = p.missed ? `못 한 것 ${p.missed}` : "";
  $("progMiss").classList.toggle("hidden", !p.missed);
  host.dataset.full = p.allDone ? "1" : "0";
  host.dataset.hot = (!p.allDone && p.total && p.pct >= HOT_PCT) ? "1" : "0";

  const bw = $("badgeRow");
  bw.innerHTML = "";
  for (const b of todayBadges(kid)) {
    const el = document.createElement("span");
    el.className = "achv";
    el.textContent = `${b.e} ${b.t}`;
    bw.appendChild(el);
  }
}

/** 오늘 계획을 다 채운 순간 한 번만 축하합니다. */
const LS_CELEB = "ks2.celeb.v1";
/* 오늘의 이정표: 80% 돌파, 100% 완주. 각각 하루에 한 번만 축하합니다.
 * 기준은 머리의 진행 링과 같습니다(놓친 일정은 분모에서 뺌) — 아이가 보는 숫자와 어긋나지 않게.
 * 100% 로 한 번에 넘어가면 80% 축하는 건너뜁니다. 되돌렸다 다시 넘어도 또 뜨지 않습니다. */
const HOT_PCT = 80;
function celebFired() {
  const v = readLS(LS_CELEB, null);
  return (v && typeof v === "object" && v.day === dayKey) ? v : { day: dayKey, fired: [] };
}
function markFired(kidId, what) {
  const v = celebFired();
  if (!v.fired.includes(`${kidId}|${what}`)) v.fired.push(`${kidId}|${what}`);
  writeLS(LS_CELEB, v);
}
const wasFired = (kidId, what) => celebFired().fired.includes(`${kidId}|${what}`);

function maybeCelebrate(kidId) {
  const p = todayProgress(kidId);
  const name = (kidById(kidId) || {}).name || "";
  if (p.allDone) {
    if (wasFired(kidId, 100)) return;
    markFired(kidId, 100); markFired(kidId, HOT_PCT);
    speak(pick([`${name} 오늘 계획 다 했어. 정말 잘했어`, `오늘 할 일 전부 끝냈어. 대단해`, `다 해냈네. 오늘 정말 잘했어`]));
    celebrate(`${name} 오늘 계획 완료!`, `${p.total}개 전부 해냈어요 — 스스로 해낸 하루예요`, { emoji: "🏆", big: true });
    return;
  }
  if (p.total && p.pct >= HOT_PCT && !wasFired(kidId, HOT_PCT)) {
    markFired(kidId, HOT_PCT);
    const left = p.total - p.done;
    speak(pick([`${HOT_PCT}퍼센트 돌파! 거의 다 왔어. ${left}개만 더 하면 돼`, `와, 벌써 ${HOT_PCT}퍼센트! 조금만 더 힘내`]));
    celebrate(`${HOT_PCT}% 돌파!`, `거의 다 왔어요 — ${left}개만 더 하면 오늘 완주!`, { emoji: "🔥", big: true, hot: true });
  }
}

function celebrate(title, sub, opt) {
  const o = Object.assign({ emoji: "🎉", big: false, hot: false }, opt || {});
  const el = $("celeb");
  if (!el) return;
  $("celebTitle").textContent = title;
  $("celebSub").textContent = sub || "";
  el.querySelector(".celebemoji").textContent = o.emoji;
  el.classList.toggle("big", !!o.big);
  el.classList.toggle("hot", !!o.hot);
  // 움직임을 줄이도록 설정한 기기에서는 색종이를 뿌리지 않습니다.
  const calm = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const box = $("celebBits");
  box.innerHTML = "";
  if (!calm) {
    const cols = o.hot ? ["#FF6B2C", "#FFB02E", "#FFD34E", "#FF8A3D", "#F5B301", "#FF5C8A"]
                       : ["#3B82F6", "#A855F7", "#F59E0B", "#10B981", "#EC4899", "#06B6D4", "#FFD34E"];
    const N = o.big ? 70 : 28;
    for (let i = 0; i < N; i++) {
      const b = document.createElement("i");
      const fromSide = o.big && i % 3 === 0;            // 큰 축하는 양옆에서도 터뜨립니다
      b.className = fromSide ? (i % 2 ? "burst-l" : "burst-r") : "";
      b.style.left = fromSide ? (i % 2 ? "-2%" : "102%") : Math.random() * 100 + "%";
      if (fromSide) b.style.top = (40 + Math.random() * 30) + "%";
      b.style.background = cols[i % cols.length];
      if (i % 5 === 0) b.style.borderRadius = "50%";     // 동그라미도 섞어서
      b.style.animationDelay = (Math.random() * (o.big ? 0.8 : 0.5)).toFixed(2) + "s";
      b.style.animationDuration = (1.6 + Math.random() * 1.1).toFixed(2) + "s";
      box.appendChild(b);
    }
    if (o.big) for (let i = 0; i < 10; i++) {           // 반짝이
      const sp = document.createElement("b");
      sp.className = "spark"; sp.textContent = "✦";
      sp.style.left = (8 + Math.random() * 84) + "%";
      sp.style.top = (10 + Math.random() * 70) + "%";
      sp.style.animationDelay = (Math.random() * 1.2).toFixed(2) + "s";
      box.appendChild(sp);
    }
  }
  el.classList.remove("show"); void el.offsetWidth;    // 연달아 떠도 애니메이션이 다시 시작되게
  el.classList.add("show");
  clearTimeout(celebrate._t);
  celebrate._t = setTimeout(() => el.classList.remove("show"), o.big ? 4200 : 3200);
}

/* ===================== 렌더 ===================== */
function renderHeader() {
  const now = nowDate();
  $("todayLabel").textContent = `${now.getMonth() + 1}월 ${now.getDate()}일 ${DOW[now.getDay()]}요일`;
  const hero = $("hero"), what = $("heroWhat"), when = $("heroWhen");
  const nm = nowMin();
  const list = eventsOn(now);
  const hol = holidayOn(ymd(now));
  $("todayLabel").textContent += hol ? `  ·  ${hol}` : "";

  const running = list.find(e => (recOf(e) || {}).state === "running");
  if (running) {
    const pr = progressOf(running, recOf(running)), [l, r] = progressText(pr);
    hero.classList.remove("idle");
    what.textContent = `${kindOf(running.kind).emoji} ${running.title}`;
    when.textContent = `${l} — ${r}`;
    return;
  }
  const live = list.find(e => { const w = windowOf(e); return w.startM <= nm && nm < w.endM; });
  const next = list.find(e => mins(e.start) > nm);
  if (live) {
    hero.classList.remove("idle");
    what.textContent = `${kindOf(live.kind).emoji} ${live.title}`;
    when.textContent = live.end ? `${live.end}에 끝나요` : "지금 할 시간";
  } else if (next) {
    hero.classList.remove("idle");
    what.textContent = `${kindOf(next.kind).emoji} ${next.title}`;
    when.textContent = `${human(mins(next.start) - nm)} 뒤 · ${next.start}`;
  } else {
    hero.classList.add("idle");
    if (hol && !list.length) {
      what.textContent = `🎌 ${hol} — 쉬는 날`;
      when.textContent = "오늘은 일정 없이 쉬어요";
    } else {
      /* 아무것도 체크하지 않았는데 "다 했다"고 축하하면 안 됩니다.
         그렇다고 나무라지도 않습니다 — 사실만 담담하게 적습니다. */
      const p = oneKid() ? todayProgress(oneKid()) : null;
      if (!list.length) {
        what.textContent = "오늘은 일정이 없어요";
        when.textContent = "";
      } else if (p && p.allDone) {
        what.textContent = "오늘 계획 다 했어요! 🎉";
        when.textContent = `${p.done}개 모두 완료 — 푹 쉬자`;
      } else if (p && p.done > 0) {
        what.textContent = "오늘 일정 끝! 🎉";
        when.textContent = `${p.done}개 완료 — 푹 쉬자`;
      } else {
        what.textContent = "오늘 일정 시간이 지났어요";
        when.textContent = p && p.missed ? `못 한 것 ${p.missed}개 — 내일 다시 해보자` : "";
      }
    }
  }
}

function renderToday() {
  const wrap = $("timeline");
  const now = nowDate(), nm = nowMin();
  const list = eventsOn(now);
  const hol = holidayOn(ymd(now));
  const skipped = skippedOn(now);
  wrap.innerHTML = "";

  if (hol) {
    const b = document.createElement("div");
    b.className = "holibar";
    b.innerHTML = `<b>🎌 ${hol}</b>` + (skipped.length
      ? `<span>${withEun(skipped.map(e => e.title).join(", "))} 공휴일이라 오늘 쉽니다</span>`
      : `<span>공휴일입니다</span>`);
    wrap.appendChild(b);
  }
  if (!list.length) {
    wrap.insertAdjacentHTML("beforeend",
      `<div class="empty"><strong>${hol ? "푹 쉬는 날이에요" : "오늘은 비어 있어요"}</strong>${hol ? "" : "일정 탭에서 추가할 수 있습니다."}</div>`);
    return;
  }
  // 겹침은 같은 아이 안에서만 따집니다. 두 아이 일정이 같은 시간인 건 정상입니다.
  const ov = new Map();
  for (const k of scopeKids())
    for (const [id, names] of overlapMap(list.filter(e => e.kid === k.id))) ov.set(id, names);

  /* 지금·다음 할 일을 위로, 끝난 것은 아래 "지난 일정"으로 접습니다.
     시간이 지나면(1분마다 다시 그림) 끝난 일정이 알아서 아래로 내려갑니다. */
  const up = [], past = [];
  for (const e of list) (isPastToday(e, nm) ? past : up).push(e);
  // 미리 시작한 일은 실제 시작 시각 기준으로 — 19:00 숙제를 16:05에 시작하면 지금 하는 일로 위에 옵니다
  const byEff = (a, b) => effStart(a) - effStart(b) || mins(a.start) - mins(b.start);
  up.sort(byEff); past.sort(byEff);

  if (!up.length) {
    wrap.insertAdjacentHTML("beforeend",
      `<div class="empty small"><strong>오늘 남은 일정이 없어요 🎉</strong>지난 일정은 아래에서 볼 수 있어요.</div>`);
  } else {
    let ruled = false;
    for (const e of up) {
      if (!ruled && effStart(e) > nm) { wrap.appendChild(nowRule(now)); ruled = true; }
      wrap.appendChild(eventRow(e, nm, ov.get(e.id)));
    }
    if (!ruled) wrap.appendChild(nowRule(now));
  }

  if (past.length) {
    const done = past.filter(e => ["done", "over"].includes((recOf(e) || {}).state)).length;
    const tracked = past.filter(e => e.track !== false).length;
    const li = document.createElement("li");
    li.className = "pastwrap";
    li.innerHTML = `<details${pastOpen ? " open" : ""}><summary>지난 일정 ${past.length}개` +
      (tracked ? ` <span>· 완료 ${done}/${tracked}</span>` : "") + `</summary><ul class="tl pastlist"></ul></details>`;
    const ul = li.querySelector("ul");
    for (const e of past) ul.appendChild(eventRow(e, nm, ov.get(e.id)));
    li.querySelector("details").addEventListener("toggle", ev => { pastOpen = ev.target.open; });
    wrap.appendChild(li);
  }
}

let pastOpen = false;                 // "지난 일정" 을 펼쳐 두었는지 — 1분마다 다시 그려도 유지
/** 오늘 목록에서 아래로 내려도 되는 일정인가: 끝냈거나, 놓쳤거나, 체크 대상이 아닌데 시간이 지난 것 */
function isPastToday(e, nm) {
  if (e.track === false) return windowOf(e).endM <= nm;
  const st = stateOf(e, recOf(e), nm);
  return st === "done" || st === "over" || st === "missed";
}
/** 목록 안의 칸에 글을 쓰는 중이면 다시 그리지 않습니다(쓰던 글자가 날아가지 않게) */
function typingInList() {
  const a = document.activeElement;
  return !!(a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) &&
            a.closest("#timeline, #ownList, #chalList, #reflectBox, #rewardBox"));
}
function nowRule(now) {
  const d = document.createElement("div");
  d.className = "nowline";
  d.innerHTML = `<div class="clock">${pad(now.getHours())}:${pad(now.getMinutes())}</div><div class="rule"></div>`;
  return d;
}
/** 진행 체크 대상이 아닌 일정 — 시간만 보여줍니다 */
function plainRow(e, nm, clash) {
  const k = kindOf(e.kind);
  const w = windowOf(e);
  const li = document.createElement("li");
  li.innerHTML = `
    <div class="clock">${e.start}${e.end ? `<small>${e.end}</small>` : ""}</div>
    <div class="ev" style="--c:${k.color}" data-st="plain" data-live="${w.startM <= nm && nm < w.endM ? 1 : 0}">
      <div class="ev-top">
        <span class="emoji">${k.emoji}</span>
        <span class="body"><span class="title"></span><span class="sub"></span></span>
      </div>
    </div>`;
  li.querySelector(".title").textContent = e.title;
  li.querySelector(".sub").textContent =
    [who === "all" ? kidTag(e) : "", k.name, e.place].filter(Boolean).join(" · ");
  if (clash && clash.length) li.querySelector(".ev").appendChild(clashLine(clash));
  return li;
}

/**
 * 세부 기록 입력 상자. 값이 바뀌면 기록에 바로 반영합니다.
 * 화면을 다시 그리면 입력 중 포커스가 날아가므로 여기서는 render() 를 부르지 않습니다.
 */
function detailBox(e, rec) {
  const wrap = document.createElement("div");
  wrap.className = "detail";
  rec.detail = rec.detail || {};
  const D = rec.detail;

  const save = () => { markDirty(e.kid, e.id); };

  for (const id of e.detail) {
    const f = detailById(id);
    if (!f) continue;
    const row = document.createElement("div");
    row.className = "drow";

    if (f.type === "bool") {
      const lab = document.createElement("label");
      lab.className = "dbool";
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.checked = !!D[id];
      cb.addEventListener("change", () => { D[id] = cb.checked; save(); });
      lab.appendChild(cb);
      lab.appendChild(document.createTextNode(f.label));
      row.appendChild(lab);

    } else if (f.type === "range") {
      row.innerHTML = `<span class="dlabel">${f.label}</span>`;
      const a = document.createElement("input"), b = document.createElement("input");
      for (const [el, idx, ph] of [[a, 0, "부터"], [b, 1, "까지"]]) {
        el.type = "number"; el.min = "0"; el.max = "9999"; el.placeholder = ph;
        el.className = "dnum";
        el.value = (D[id] && D[id][idx] != null) ? D[id][idx] : "";
        el.addEventListener("change", () => {
          const cur = Array.isArray(D[id]) ? [...D[id]] : [null, null];
          cur[idx] = el.value === "" ? null : Number(el.value);
          D[id] = (cur[0] == null && cur[1] == null) ? null : cur;
          save();
        });
      }
      row.appendChild(a);
      row.insertAdjacentHTML("beforeend", `<span class="dtil">~</span>`);
      row.appendChild(b);
      row.insertAdjacentHTML("beforeend", `<span class="dunit">쪽</span>`);

    } else if (f.type === "num") {
      row.innerHTML = `<span class="dlabel">${f.label}</span>`;
      const el = document.createElement("input");
      el.type = "number"; el.min = "0"; el.max = "9999"; el.className = "dnum";
      el.value = D[id] != null ? D[id] : "";
      el.addEventListener("change", () => { D[id] = el.value === "" ? null : Number(el.value); save(); });
      row.appendChild(el);
      row.insertAdjacentHTML("beforeend", `<span class="dunit">${f.unit || ""}</span>`);

    } else {
      row.innerHTML = `<span class="dlabel">${f.label}</span>`;
      const t = document.createElement("input");
      t.type = "text"; t.placeholder = f.placeholder || ""; t.className = "dtext";
      t.value = D[id] || "";
      t.addEventListener("change", () => { D[id] = t.value.trim() || null; save(); });
      row.appendChild(t);
    }
    wrap.appendChild(row);
  }
  return wrap;
}

/** 기록된 세부 내용을 한 줄로 */
function detailSummary(e, rec) {
  const D = (rec && rec.detail) || {};
  const out = [];
  for (const id of (e.detail || [])) {
    const f = detailById(id); if (!f) continue;
    const v = D[id];
    if (f.type === "bool") { if (v) out.push(`${f.label} ✓`); }
    else if (f.type === "range") { if (Array.isArray(v) && (v[0] != null || v[1] != null)) out.push(`${v[0] ?? ""}~${v[1] ?? ""}쪽`); }
    else if (f.type === "num") { if (v != null) out.push(`${f.label} ${v}${f.unit || ""}`); }
    else if (v) out.push(`${f.label}: ${v}`);
  }
  return out.join(" · ");
}

/** "겹침" 안내 한 줄 */
function clashLine(names) {
  const p = document.createElement("p");
  p.className = "clash";
  p.textContent = `⚠ ${withGwa([...new Set(names)].join(", "))} 시간이 겹칩니다`;
  return p;
}

/** 마지막 글자에 받침이 있는지 */
function hasBatchim(text) {
  const code = String(text).trim().slice(-1).charCodeAt(0);
  return code >= 0xAC00 && code <= 0xD7A3 && (code - 0xAC00) % 28 !== 0;
}
const withGwa = t => `${t}${hasBatchim(t) ? "과" : "와"}`;
const withEun = t => `${t}${hasBatchim(t) ? "은" : "는"}`;
const withEul = t => `${t}${hasBatchim(t) ? "을" : "를"}`;

function clockHtml(e, rec) {
  const a = startedMin(rec);
  if (a != null && Math.abs(a - mins(e.start)) >= 5)
    return `${hhmm(a)}<small class="planned">예정 ${e.start}</small>`;
  return `${e.start}${e.end ? `<small>${e.end}</small>` : ""}`;
}
function eventRow(e, nm, clash) {
  const k = kindOf(e.kind);
  if (e.track === false) return plainRow(e, nm, clash);
  const rec = recOf(e);
  const st = stateOf(e, rec, nm);
  const lim = (rec && rec.limitMin) || limitOf(e);
  const w = windowOf(e);
  const el = st === "running" ? elapsedOf(rec) : (rec && rec.elapsedMin != null ? rec.elapsedMin : null);

  const li = document.createElement("li");
  li.innerHTML = `
    <div class="clock">${clockHtml(e, rec)}</div>
    <div class="ev" style="--c:${k.color}" data-st="${st}" data-live="${w.startM <= nm && nm < w.endM ? 1 : 0}">
      <div class="ev-top">
        <span class="emoji">${k.emoji}</span>
        <span class="body"><span class="title"></span><span class="sub"></span></span>
        <span class="badges"><span class="badge ${st}">${STATE_LABEL[st]}</span></span>
      </div>
      <div class="slot"></div>
      <div class="acts"></div>
    </div>`;
  li.querySelector(".title").textContent = e.title;
  li.querySelector(".sub").textContent =
    [who === "all" ? kidTag(e) : "", k.name, e.place, `제한 ${lim}분`].filter(Boolean).join(" · ");

  // 기록해 둔 세부 내용 한 줄 (완료된 뒤에도 보이게)
  const dsum = detailSummary(e, rec);
  if (dsum && ["done", "over"].includes(st)) {
    const p = document.createElement("div");
    p.className = "dsum";
    p.textContent = "📝 " + dsum;
    li.querySelector(".body").appendChild(p);
  }

  // 장소 확인 결과 — 좌표가 아니라 판정 결과만 표시합니다
  const spot = rec && (rec.atDone || rec.atStart);
  if (spot) {
    const b = document.createElement("span");
    b.className = "badge spot-" + spot;
    b.textContent = SPOT_LABEL[spot];
    li.querySelector(".badges").prepend(b);
  }

  // 진행바 — 머리와 같은 계산(progressOf)
  if (el != null) {
    const pr = progressOf(e, rec), [l, r] = progressText(pr);
    li.querySelector(".slot").innerHTML =
      `<div class="bar" data-over="${pr.over ? 1 : 0}" data-ended="${pr.ended ? 1 : 0}"><i style="width:${pr.pct}%"></i></div>
       <div class="limitline"><span>${l}</span><span>${r}</span></div>`;
  } else if (st === "locked") {
    li.querySelector(".slot").innerHTML =
      `<div class="limitline"><span>${hhmm(w.openM)}부터 체크할 수 있어요</span><span></span></div>`;
  } else if (st === "todo" && !canEarly(e) && e.track !== false && nm >= w.startM) {
    li.querySelector(".slot").innerHTML =
      `<div class="limitline nudge"><span>⏰ ${e.start} 시작 — 아직 안 눌렀어요</span><span>${hhmm(w.endM)} 끝</span></div>`;
  } else if (st === "todo" && canEarly(e) && nm < w.startM) {
    li.querySelector(".slot").innerHTML =
      `<div class="limitline"><span>⏩ 미리 해도 돼요 · ${hhmm(w.closeM)}까지</span><span></span></div>`;
  } else if (st === "todo" || st === "missed") {
    li.querySelector(".slot").innerHTML =
      `<div class="limitline"><span>체크 가능 ${hhmm(w.openM)} – ${hhmm(w.closeM)}</span><span></span></div>`;
  }

  if (clash && clash.length) li.querySelector(".slot").appendChild(clashLine(clash));

  // 세부 기록 — 시작했거나 끝낸 일정에만 띄웁니다
  if (canWrite() && (e.detail || []).length && rec && ["running", "done", "over"].includes(st)) {
    li.querySelector(".slot").appendChild(detailBox(e, rec));
  }

  // 버튼
  const acts = li.querySelector(".acts");
  const add = (text, cls, fn, dis) => {
    const b = document.createElement("button");
    b.className = "btn small " + cls; b.textContent = text; b.type = "button";
    if (dis) b.disabled = true; else b.addEventListener("click", fn);
    acts.appendChild(b);
  };
  if (!canWrite()) {
    acts.remove();                       // 읽기 전용 안내는 위 알림 박스에 한 번만 띄웁니다
  } else if (st === "locked") {
    acts.remove();                         // "○○부터 체크할 수 있어요" 가 이미 있어 버튼은 뺍니다
  } else if (st === "todo") {
    add("시작", "go", () => startTask(e));
    add("바로 완료", "", () => completeTask(e));
  } else if (st === "running") {
    add("완료", "primary", () => completeTask(e));
    add("취소", "", () => undoTask(e));
  } else if (st === "done" || st === "over") {
    add("되돌리기", "", () => undoTask(e));
  } else if (st === "missed") {
    if (isParent()) add("완료로 표시", "", () => completeTask(e));
    else acts.remove();                    // "놓침" 배지로 충분합니다
  }
  return li;
}

function renderWeek() {
  const grid = $("weekGrid");
  const today = nowDate();
  const mon = new Date(today);
  mon.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  grid.innerHTML = "";
  for (let i = 0; i < 7; i++) {
    const d = new Date(mon); d.setDate(mon.getDate() + i);
    const list = eventsOn(d);
    const isToday = ymd(d) === ymd(today);
    const hol = holidayOn(ymd(d));
    const box = document.createElement("div");
    box.className = "day" + (isToday ? " is-today" : "") + (hol ? " is-holiday" : "");
    let doneCnt = 0;
    const tracked = list.filter(e => e.track !== false);
    if (isToday) doneCnt = tracked.filter(e => ["done", "over"].includes((recOf(e) || {}).state)).length;
    box.innerHTML = `<h3>${DOW[d.getDay()]}<span>${d.getMonth() + 1}.${d.getDate()}${isToday && tracked.length ? ` · ${doneCnt}/${tracked.length}` : ""}</span></h3>`;
    if (hol) box.insertAdjacentHTML("beforeend", `<p class="holiname">🎌 ${hol}</p>`);
    if (!list.length) box.insertAdjacentHTML("beforeend", `<p class="none">${hol ? "쉬는 날" : "없음"}</p>`);
    else {
      const ul = document.createElement("ul");
      for (const e of list) {
        const k = kindOf(e.kind);
        const li = document.createElement("li");
        li.style.setProperty("--c", k.color);
        li.innerHTML = `<b></b><i>${who === "all" ? kidTag(e) + " · " : ""}${e.start}${e.end ? `–${e.end}` : ""}${e.track === false ? "" : " · 제한 " + limitOf(e) + "분"}</i>`;
        li.querySelector("b").textContent = e.title;
        ul.appendChild(li);
      }
      box.appendChild(ul);
    }
    grid.appendChild(box);
  }
}

/* ---- 기록: 주간·월간 리포트 ---- */
/*
 * 상태 파일을 날짜마다 하나씩 읽습니다. 월간이면 최대 31번이라
 * 순차로 돌면 느려서, 6개씩 묶어 병렬로 가져오고 읽은 것은 캐시해 둡니다.
 */
let repMode = "week";      // week | month
let repOffset = 0;         // 0 = 이번, -1 = 지난
const statusCache = new Map();   // "kid|날짜" → data | null

/** 리포트가 덮는 날짜 범위 */
function repRange() {
  const now = nowDate();
  if (repMode === "week") {
    const mon = new Date(now);
    mon.setDate(now.getDate() - ((now.getDay() + 6) % 7) + repOffset * 7);
    const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
    return { from: mon, to: sun, label: `${mon.getMonth() + 1}.${mon.getDate()} ~ ${sun.getMonth() + 1}.${sun.getDate()}` };
  }
  const first = new Date(now.getFullYear(), now.getMonth() + repOffset, 1);
  const last = new Date(first.getFullYear(), first.getMonth() + 1, 0);
  return { from: first, to: last, label: `${first.getFullYear()}년 ${first.getMonth() + 1}월` };
}
function datesIn(from, to) {
  const out = [], d = new Date(from);
  while (d <= to) { out.push(ymd(d)); d.setDate(d.getDate() + 1); }
  return out;
}

/** 여러 날짜의 상태 파일을 6개씩 병렬로 가져옵니다. */
async function loadStatusRange(kidId, dates, force) {
  const need = dates.filter(k => force || !statusCache.has(kidId + "|" + k));
  for (let i = 0; i < need.length; i += 6) {
    const batch = need.slice(i, i + 6);
    await Promise.all(batch.map(async key => {
      try {
        const r = statusRepo.authed
          ? await statusRepo.readJson(statusPath(kidId, key))
          : await statusRepo.readJsonPublic(statusPath(kidId, key));
        statusCache.set(kidId + "|" + key, r.missing ? null : r.data);
      } catch (e) { statusCache.set(kidId + "|" + key, null); }
    }));
  }
  return dates.map(key => ({ key, data: statusCache.get(kidId + "|" + key) || null }));
}

async function renderRecords(force) {
  const box = $("recBody");
  if (!oneKid()) {
    box.innerHTML = `<div class="empty"><strong>아이를 한 명 골라 주세요</strong>리포트는 한 명씩 봅니다.</div>`;
    $("repLabel").textContent = "";
    return;
  }
  const { from, to, label } = repRange();
  $("repLabel").textContent = label;
  document.querySelectorAll("#repMode button").forEach(b =>
    b.setAttribute("aria-selected", String(b.dataset.mode === repMode)));

  const dates = datesIn(from, to);
  box.innerHTML = `<p class="hint">${label} 기록을 불러오는 중… (${dates.length}일)</p>`;
  const rows = await loadStatusRange(who, dates, force);
  paintReport(buildReport(rows), label);
}

/** 사용자가 적은 글자를 HTML 에 넣기 전에 막아 둡니다 */
function esc(t) {
  return String(t).replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** 날짜별 원자료를 리포트용 숫자로 정리합니다. */
function buildReport(rows) {
  const R = {
    days: [], total: 0, done: 0, over: 0, missed: 0,
    per: {},          // 일정별
    books: [],        // 읽은 책
    early: 0,         // 예정보다 먼저 시작해 끝낸 것
    own: { total: 0, done: 0, list: [] },   // 스스로 정한 것
    reflects: [],                            // 하루 돌아보기
    sums: { pages: 0, graded: 0, gradedOf: 0, redo: 0, listen: 0, speak: 0, words: 0, memo: [] },
    elapsed: 0, elapsedN: 0
  };

  for (const { key, data } of rows) {
    const d = new Date(key + "T12:00:00");
    const planned = eventsOn(d, who).filter(e => e.track !== false);
    const items = (data && data.items) || {};
    let dDone = 0, dOver = 0;

    for (const e of planned) {
      R.total++;
      const r = items[e.id];
      // 같은 이름의 일정은 요일마다 id 가 달라도 한 줄로 묶습니다.
      const gk = e.kind + "|" + e.title;
      const p = R.per[gk] || (R.per[gk] = { title: e.title, kind: e.kind, plan: 0, done: 0, over: 0, sum: 0, n: 0, limit: limitOf(e) });
      p.limit = Math.max(p.limit, limitOf(e));
      p.plan++;
      if (r && (r.state === "done" || r.state === "over")) {
        R.done++; dDone++; p.done++;
        if (wasEarly(e, r)) R.early++;
        if (r.state === "over") { R.over++; dOver++; p.over++; }
        if (r.elapsedMin != null) { p.sum += r.elapsedMin; p.n++; R.elapsed += r.elapsedMin; R.elapsedN++; }

        const D = r.detail || {};
        if (D.book) R.books.push({ key, title: D.book, pages: D.pages || null });
        if (Array.isArray(D.pages) && D.pages[0] != null && D.pages[1] != null)
          R.sums.pages += Math.max(0, D.pages[1] - D.pages[0] + 1);
        if (D.graded != null) { R.sums.gradedOf++; if (D.graded) R.sums.graded++; }
        if (D.redo) R.sums.redo++;
        if (D.listen) R.sums.listen++;
        if (D.speak) R.sums.speak++;
        if (typeof D.words === "number") R.sums.words += D.words;
        if (D.memo) R.sums.memo.push({ key, what: e.title, text: D.memo });
      } else if (r && r.state === "missed") { R.missed++; }
    }
    // 스스로 정한 것
    for (const o of Object.values((data && data.own) || {})) {
      R.own.total++;
      const ok = ["done", "over"].includes(o.state);
      if (ok) R.own.done++;
      R.own.list.push({ key, title: o.title, kind: o.kind, done: ok, elapsedMin: o.elapsedMin, limitMin: o.limitMin });
    }
    const rf = (data && data.reflect) || {};
    if (rf.rating || rf.good || rf.next) R.reflects.push({ key, ...rf });

    R.days.push({ key, dow: DOW[d.getDay()], holiday: holidayOn(key), plan: planned.length, done: dDone, over: dOver });
  }
  return R;
}

function bar(pct, cls) {
  return `<span class="mini"><i class="${cls || ""}" style="width:${Math.min(100, pct)}%"></i></span>`;
}

function paintReport(R, label) {
  const rate = R.total ? Math.round((R.done / R.total) * 100) : 0;
  const avg = R.elapsedN ? Math.round(R.elapsed / R.elapsedN) : null;

  // 잘한 점을 먼저 보여 줍니다. 못한 점을 세는 화면이 되지 않게.
  const hi = [];
  const fullDays = R.days.filter(d => d.plan && d.done === d.plan).length;
  if (fullDays) hi.push(`🎉 계획을 전부 채운 날 ${fullDays}일`);
  if (R.early) hi.push(`⏩ 미리 해낸 것 ${R.early}개`);
  if (R.own.done) hi.push(`🌱 스스로 정한 것 ${R.own.done}개 해냄`);
  if (R.books.length) hi.push(`📚 책 ${R.books.length}권 읽음`);
  if (R.sums.pages) hi.push(`✏️ ${R.sums.pages}쪽 풀어냄`);
  if (R.sums.speak) hi.push(`🗣 낭독 ${R.sums.speak}번`);
  if (R.reflects.length) hi.push(`📝 돌아보기 ${R.reflects.length}일 기록`);
  {
    const inRange = d => R.days.some(x => x.key === d);
    const fires = chalOf(who).reduce((a, c) => a + c.stamps.filter(inRange).length, 0);
    const finished = chalOf(who).filter(c => c.doneAt && inRange(c.doneAt.slice(0, 10))).length;
    if (fires) hi.push(`🏅 챌린지 도장 ${fires}개`);
    if (finished) hi.push(`🏆 챌린지 ${finished}개 완주`);
  }
  const inTime = R.done - R.over;
  if (inTime > 0 && R.over === 0 && R.done >= 3) hi.push(`⏱ 전부 제한시간 안에`);

  let h = "";
  if (hi.length) {
    h += `<div class="panel hipanel"><h2>이번 ${repMode === "week" ? "주" : "달" } 잘한 것</h2>
      <div class="hirow">${hi.map(x => `<span class="achv big">${x}</span>`).join("")}</div></div>`;
  }

  h += `<div class="stats">
      <div class="stat"><b>${rate}%</b><span>완료율</span></div>
      <div class="stat"><b>${R.done}/${R.total}</b><span>완료 / 계획</span></div>
      <div class="stat"><b>${R.over}</b><span>제한시간 초과</span></div>
    </div>`;

  // 일별 추이
  h += `<div class="panel"><h2>${repMode === "week" ? "요일별" : "날짜별"}</h2><table class="rec"><thead><tr>
      <th>날짜</th><th></th><th class="num">완료</th><th class="num">계획</th><th></th></tr></thead><tbody>`;
  for (const d of R.days) {
    const pct = d.plan ? (d.done / d.plan) * 100 : 0;
    h += `<tr><td>${d.key.slice(5)}</td><td>${d.dow}${d.holiday ? ` <span class="holitag">🎌</span>` : ""}</td>
      <td class="num">${d.done}</td><td class="num">${d.plan || "—"}</td>
      <td style="width:38%">${d.plan ? bar(pct, d.over ? "warn" : "") : ""}</td></tr>`;
  }
  h += `</tbody></table></div>`;

  // 일정별
  const keys = Object.keys(R.per);
  h += `<div class="panel"><h2>일정별</h2>`;
  if (!keys.length) h += `<p class="hint">이 기간에 계획된 일정이 없습니다.</p>`;
  else {
    h += `<table class="rec"><thead><tr><th>일정</th><th class="num">완료/계획</th>
      <th class="num">평균</th><th class="num">제한</th><th class="num">초과</th></tr></thead><tbody>`;
    for (const id of keys) {
      const p = R.per[id], a = p.n ? Math.round(p.sum / p.n) : null;
      h += `<tr><td>${kindOf(p.kind).emoji} ${esc(p.title)}</td>
        <td class="num">${p.done}/${p.plan}</td>
        <td class="num${a != null && a > p.limit ? " over" : ""}">${a != null ? a + "분" : "—"}</td>
        <td class="num">${p.limit}분</td>
        <td class="num${p.over ? " over" : ""}">${p.over || "—"}</td></tr>`;
    }
    h += `</tbody></table>`;
    if (avg != null) h += `<p class="hint" style="margin:12px 0 0">"시작"을 눌러 잰 일정의 평균 소요는 ${avg}분입니다.</p>`;
  }
  h += `</div>`;

  // 월간 리포트: 그 달의 보상
  if (repMode === "month" && R.days.length) {
    const m = R.days[0].key.slice(0, 7);
    const tiers = rewardsFor(who, m);
    if (tiers.length) {
      const got = stampsInMonth(who, m);
      h += `<div class="panel"><h2>🎁 ${monthLabel(m)}의 보상 <span class="cntbadge">도장 ${got}개</span></h2>
        <table class="rec"><thead><tr><th class="num">목표</th><th>보상</th><th>상태</th></tr></thead><tbody>`;
      for (const r of tiers) {
        const st = rewardState(r, got);
        h += `<tr><td class="num">${r.need}개</td><td>${esc(r.gift)}</td><td>${
          st === "paid" ? `✓ 지급 ${r.paidAt.slice(5, 10).replace("-", "/")}` : st === "ready" ? "🎉 달성 · 지급 전" : `${r.need - got}개 남음`}</td></tr>`;
      }
      h += `</tbody></table></div>`;
    }
  }

  // 스스로 정한 것 — 자기주도 정도를 보는 핵심 지표
  h += `<div class="panel"><h2>🌱 스스로 정한 것 <span class="cntbadge">${R.own.done}/${R.own.total}</span></h2>`;
  if (!R.own.total) h += `<p class="hint">이 기간에 아이가 직접 적은 항목이 없습니다.</p>`;
  else {
    const days = new Set(R.own.list.map(o => o.key)).size;
    h += `<p class="hint">${days}일 동안 ${R.own.total}개를 스스로 정했고 ${R.own.done}개를 해냈습니다.</p>`;
    h += `<table class="rec"><thead><tr><th>날짜</th><th>내용</th><th class="num">걸린 시간</th><th></th></tr></thead><tbody>`;
    for (const o of R.own.list)
      h += `<tr><td>${o.key.slice(5)}</td><td>${kindOf(o.kind).emoji} ${esc(o.title)}</td>
        <td class="num">${o.elapsedMin != null ? o.elapsedMin + "분" : "—"}</td>
        <td>${o.done ? "✅" : "—"}</td></tr>`;
    h += `</tbody></table>`;
  }
  h += `</div>`;

  // 하루 돌아보기
  if (R.reflects.length) {
    const avg = R.reflects.filter(r => r.rating).reduce((a, r) => a + r.rating, 0) /
                (R.reflects.filter(r => r.rating).length || 1);
    h += `<div class="panel"><h2>하루 돌아보기 <span class="cntbadge">평균 ${avg.toFixed(1)}점</span></h2>
      <table class="rec"><thead><tr><th>날짜</th><th class="num">점수</th><th>잘한 것</th><th>내일 할 것</th></tr></thead><tbody>`;
    for (const r of R.reflects)
      h += `<tr><td>${r.key.slice(5)}</td><td class="num">${r.rating ? "★".repeat(r.rating) : "—"}</td>
        <td>${esc(r.good || "—")}</td><td>${esc(r.next || "—")}</td></tr>`;
    h += `</tbody></table></div>`;
  }

  // 읽은 책
  h += `<div class="panel"><h2>읽은 책 <span class="cntbadge">${R.books.length}권</span></h2>`;
  if (!R.books.length) h += `<p class="hint">기록이 없습니다. 독서 일정에 "읽은 책"을 켜면 제목이 쌓입니다.</p>`;
  else {
    h += `<table class="rec"><thead><tr><th>날짜</th><th>책</th><th class="num">쪽</th></tr></thead><tbody>`;
    for (const b of R.books) {
      const pg = b.pages ? `${b.pages[0] ?? ""}~${b.pages[1] ?? ""}` : "—";
      h += `<tr><td>${b.key.slice(5)}</td><td>${esc(b.title)}</td><td class="num">${pg}</td></tr>`;
    }
    h += `</tbody></table>`;
  }
  h += `</div>`;

  // 숙제 누계
  const S = R.sums;
  const lines = [];
  if (S.pages) lines.push(["푼 분량", `${S.pages}쪽`]);
  if (S.gradedOf) lines.push(["채점", `${S.graded}/${S.gradedOf}회`]);
  if (S.redo) lines.push(["오답 다시 풀기", `${S.redo}회`]);
  if (S.listen) lines.push(["듣기", `${S.listen}회`]);
  if (S.speak) lines.push(["낭독", `${S.speak}회`]);
  if (S.words) lines.push(["단어", `${S.words}개`]);
  if (lines.length) {
    h += `<div class="panel"><h2>숙제 누계</h2><table class="rec"><tbody>`;
    for (const [k, v] of lines) h += `<tr><td>${k}</td><td class="num">${v}</td></tr>`;
    h += `</tbody></table></div>`;
  }
  if (S.memo.length) {
    h += `<div class="panel"><h2>메모</h2><table class="rec"><tbody>`;
    for (const m of S.memo) h += `<tr><td>${m.key.slice(5)}</td><td>${esc(m.what)}</td><td>${esc(m.text)}</td></tr>`;
    h += `</tbody></table></div>`;
  }

  $("recBody").innerHTML = h;
  lastReport = { R, label };
}

let lastReport = null;

/** 리포트를 그대로 붙여 넣을 수 있는 글로 만듭니다 (카톡·메일용) */
function reportText() {
  if (!lastReport) return "";
  const { R, label } = lastReport;
  const me = kidById(who) || {};
  const rate = R.total ? Math.round((R.done / R.total) * 100) : 0;
  const L = [`■ ${me.name} ${repMode === "week" ? "주간" : "월간"} 공부 리포트 (${label})`, ""];
  L.push(`완료율 ${rate}%  (${R.done}/${R.total})`);
  if (R.over) L.push(`제한시간 초과 ${R.over}회`);
  if (R.elapsedN) L.push(`평균 소요 ${Math.round(R.elapsed / R.elapsedN)}분`);
  L.push("");
  L.push("[일정별]");
  for (const id of Object.keys(R.per)) {
    const p = R.per[id], a = p.n ? Math.round(p.sum / p.n) : null;
    L.push(` - ${p.title}  ${p.done}/${p.plan}` +
      (a != null ? `  평균 ${a}분 / 제한 ${p.limit}분` : "") +
      (p.over ? `  초과 ${p.over}회` : ""));
  }
  if (repMode === "month" && R.days.length) {
    const m = R.days[0].key.slice(0, 7), tiers = rewardsFor(who, m);
    if (tiers.length) {
      const got = stampsInMonth(who, m);
      L.push("", `[${monthLabel(m)}의 보상 — 도장 ${got}개]`);
      for (const r of tiers) {
        const st = rewardState(r, got);
        L.push(` - ${r.need}개 → ${r.gift}  ${st === "paid" ? "✓ 지급" : st === "ready" ? "🎉 달성(지급 전)" : `${r.need - got}개 남음`}`);
      }
    }
  }
  if (R.own.total) {
    L.push("", `[스스로 정한 것 ${R.own.done}/${R.own.total}]`);
    for (const o of R.own.list)
      L.push(` - ${o.key.slice(5)} ${o.title}${o.done ? " ✅" : ""}${o.elapsedMin != null ? ` (${o.elapsedMin}분)` : ""}`);
  }
  if (R.reflects.length) {
    L.push("", "[하루 돌아보기]");
    for (const r of R.reflects)
      L.push(` - ${r.key.slice(5)} ${r.rating ? "★".repeat(r.rating) : ""}` +
             (r.good ? ` 잘한 것: ${r.good}` : "") + (r.next ? ` / 내일: ${r.next}` : ""));
  }
  if (R.books.length) {
    L.push("", `[읽은 책 ${R.books.length}권]`);
    for (const b of R.books) L.push(` - ${b.key.slice(5)} ${b.title}` + (b.pages ? ` (${b.pages[0] ?? ""}~${b.pages[1] ?? ""}쪽)` : ""));
  }
  const S = R.sums, sum = [];
  if (S.pages) sum.push(`푼 분량 ${S.pages}쪽`);
  if (S.gradedOf) sum.push(`채점 ${S.graded}/${S.gradedOf}회`);
  if (S.redo) sum.push(`오답 다시 풀기 ${S.redo}회`);
  if (S.listen) sum.push(`듣기 ${S.listen}회`);
  if (S.speak) sum.push(`낭독 ${S.speak}회`);
  if (S.words) sum.push(`단어 ${S.words}개`);
  if (sum.length) { L.push("", "[누계]"); sum.forEach(x => L.push(` - ${x}`)); }
  if (S.memo.length) { L.push("", "[메모]"); S.memo.forEach(m => L.push(` - ${m.key.slice(5)} ${m.what}: ${m.text}`)); }
  return L.join("\n");
}

/** 오늘 탭의 🌱 내가 정한 것 입력 칸으로 이동 */
function goOwnAdd() {
  const b = document.querySelector('nav.tabs button[data-tab="today"]');
  if (b) b.click();
  setTimeout(() => {
    const box = $("ownBox");
    if (box && box.scrollIntoView) box.scrollIntoView({ behavior: "smooth", block: "center" });
    const f = $("ownTitle"); if (f) f.focus();
  }, 60);
}

/* ---- 일정 편집 ---- */
function renderEdit() {
  const gate = $("editGate");
  gate.classList.toggle("hidden", isParent() && oneKid());
  $("editBody").classList.toggle("hidden", !(isParent() && oneKid()));
  if (!isParent()) {
    if (isChild() && canWrite()) {
      // 아이에게 역할 바꾸는 법을 알려 주지 않습니다. 대신 스스로 추가하는 곳으로 안내합니다.
      gate.innerHTML = `<b>📅 일정표는 부모님이 정해요.</b><br>
        오늘 하고 싶은 공부나 할 일은 <b>🌱 내가 정한 것</b>에 스스로 추가할 수 있어요.
        <div class="btns" style="margin-top:10px"><button class="btn primary" type="button" id="goOwn">🌱 스스로 추가하러 가기</button></div>`;
      $("goOwn").onclick = goOwnAdd;
    } else {
      gate.innerHTML = `이 기기는 <b>보기만</b> 하는 기기예요. 부모님 기기에서 연결 링크를 받아 연결하면 체크하고 스스로 추가할 수 있어요.`;
    }
    return;
  }
  if (!oneKid()) {
    gate.innerHTML = `위에서 아이를 한 명 고르면 그 아이의 일정을 편집할 수 있습니다. <b>모두</b> 상태에서는 편집할 수 없습니다.`;
    return;
  }
  const me = kidById(who);
  $("kidLabel").textContent = `${me.emoji} ${me.name}`;
  const bt = $("bulkText");
  if (bt && (bt.dataset.kid !== who || !bt.value.trim())) {
    bt.value = schedToText(who); bt.dataset.kid = who;
    $("bulkOut").innerHTML = ""; $("bulkApply").disabled = true; bulkPlan = null;
  }

  const wl = $("weeklyList"), ol = $("onceList");
  const todayK = ymd(nowDate());
  const todayDow = nowDate().getDay();

  // 요일별로 묶어서 그립니다. 비어 있는 요일도 보여야 빠진 날을 알 수 있습니다.
  wl.innerHTML = "";
  for (const d of [1, 2, 3, 4, 5, 6, 0]) {
    const items = sched.weekly.filter(e => e.kid === who && e.day === d).sort((a, b) => mins(a.start) - mins(b.start));
    const ov = overlapMap(items);
    const sec = document.createElement("section");
    sec.className = "dgrp" + (d === todayDow ? " is-today" : "") + (ov.size ? " has-clash" : "");
    sec.innerHTML = `<h3><span class="dname">${DOW[d]}요일</span>
        <span class="cnt">${items.length ? items.length + "건" : ""}${ov.size ? ` <b class="clashtag">겹침 ${ov.size}건</b>` : ""}</span>
        <button class="btn small addhere" type="button">+ 추가</button></h3>`;
    sec.querySelector(".addhere").addEventListener("click", () => prefillDay(d));

    if (!items.length) {
      sec.insertAdjacentHTML("beforeend", `<p class="none">없음</p>`);
    } else {
      const ul = document.createElement("ul");
      ul.className = "list";
      for (const e of items) {
        ul.appendChild(editRow(e,
          `${e.start}${e.end ? `–${e.end}` : ""} · ${e.track === false ? "체크 안 함" : "제한 " + limitOf(e) + "분"}${e.onHoliday === "keep" ? " · 공휴일에도 진행" : ""}${e.geo ? " · 📍장소확인" : ""}${(e.detail || []).length ? " · 📝" + e.detail.map(x => (detailById(x) || {}).label).join("/") : ""}`,
          "weekly", ov.get(e.id)));
      }
      sec.appendChild(ul);
    }
    wl.appendChild(sec);
  }

  const once = sched.once.filter(e => e.kid === who && e.date >= todayK).sort((a, b) => a.date.localeCompare(b.date) || mins(a.start) - mins(b.start));
  ol.innerHTML = once.length ? "" : `<li style="color:var(--ink-soft)">예정된 일정이 없습니다.</li>`;
  // 하루짜리 일정은 같은 날짜에 있는 것들끼리, 그리고 그날 요일의 반복 일정과도 비교합니다.
  for (const e of once) {
    const sameDay = sched.once.filter(x => x.kid === e.kid && x.date === e.date)
      .concat(sched.weekly.filter(w => w.kid === e.kid && w.day === new Date(e.date + "T12:00:00").getDay()
                                    && !(w.off || []).includes(e.date)));
    const clash = overlapMap(sameDay).get(e.id);
    ol.appendChild(editRow(e, `${e.date} ${e.start}${e.end ? `–${e.end}` : ""} · ${e.track === false ? "체크 안 함" : "제한 " + limitOf(e) + "분"}`, "once", clash));
  }

  $("fName").value = me.name;
  $("fBefore").value = sched.notifyBeforeMin;
  $("fChkBefore").value = checkCfg().beforeMin;
  $("fChkAfter").value = checkCfg().afterMin;
  $("fWinBefore").value = cfg.check.beforeMin;
  $("fWinAfter").value = cfg.check.afterMin;
}
/** 입력 칸의 장소 표시를 갱신합니다. */
function paintFormGeo() {
  const el = $("geoState");
  if (!el) return;
  if (formGeo) {
    el.textContent = `등록됨 ${formGeo.lat.toFixed(3)}, ${formGeo.lng.toFixed(3)} · 반경 ${formGeo.radius}m`;
    el.className = "geoset";
    $("fRadius").value = formGeo.radius;
  } else {
    el.textContent = "등록 안 됨 — 장소 확인을 쓰지 않습니다";
    el.className = "";
  }
}

/** 목록에서 고른 일정을 입력 칸에 그대로 올려 수정 모드로 들어갑니다. */
function startEdit(e, bucket) {
  editing = { bucket, id: e.id };
  $("fTitle").value = e.title;
  $("fKind").value = e.kind;
  $("fStart").value = e.start;
  $("fEnd").value = e.end || "";
  $("fLimit").value = e.limitMin == null ? "" : e.limitMin;
  $("fPlace").value = e.place || "";
  $("fDate").value = bucket === "once" ? e.date : "";
  document.querySelectorAll("#fDows input").forEach(i => { i.checked = bucket === "weekly" && Number(i.value) === e.day; });
  $("fTrack").checked = e.track !== false;
  $("fHoli").checked = e.onHoliday === "keep";
  formGeo = e.geo ? { ...e.geo } : null;
  paintFormGeo();
  document.querySelectorAll("#fDetail input").forEach(i => { i.checked = (e.detail || []).includes(i.value); });

  $("formTitle").textContent = "일정 수정";
  $("fSubmit").textContent = "수정 저장";
  $("fCancel").classList.remove("hidden");
  const b = $("editBanner");
  b.classList.remove("hidden");
  b.textContent = `✏️ ${withEul(e.title)} 고치는 중입니다 — ${bucket === "once" ? e.date : DOW[e.day] + "요일"} ${e.start}. 새로 추가하려면 '수정 취소'를 누르세요.`;
  try { $("addPanel").scrollIntoView({ behavior: "smooth", block: "start" }); }
  catch (err) { window.scrollTo({ top: 0 }); }
  setTimeout(() => $("fTitle").focus(), 300);
}
function cancelEdit(silent) {
  editing = null;
  $("addForm").reset();
  $("fTrack").checked = true; $("fHoli").checked = false;
  formGeo = null; paintFormGeo();
  document.querySelectorAll("#fDetail input").forEach(i => { i.checked = false; });
  $("formTitle").textContent = "일정 추가";
  $("fSubmit").textContent = "일정 추가";
  $("fCancel").classList.add("hidden");
  $("editBanner").classList.add("hidden");
  renderEdit();
  if (!silent) toast("수정을 취소했습니다");
}

/** 요일 헤더의 "+ 추가" — 그 요일만 체크하고 입력 칸으로 올려 줍니다. */
function prefillDay(d) {
  if (editing) cancelEdit(true);
  document.querySelectorAll("#fDows input").forEach(i => { i.checked = Number(i.value) === d; });
  $("fDate").value = "";
  try { $("addPanel").scrollIntoView({ behavior: "smooth", block: "start" }); }
  catch (e) { window.scrollTo({ top: 0 }); }
  setTimeout(() => $("fTitle").focus(), 300);
  toast(`${DOW[d]}요일에 추가합니다`);
}

function editRow(e, meta, bucket, clash) {
  const k = kindOf(e.kind);
  const li = document.createElement("li");
  li.innerHTML = `<span class="dot" style="--c:${k.color}"></span>
    <span class="meta"><b></b><span></span></span>
    <button class="btn small btn-edit" type="button">수정</button>
    <button class="btn small danger btn-del" type="button">삭제</button>`;
  li.querySelector("b").textContent = `${k.emoji} ${e.title}`;
  li.querySelector(".meta span").textContent = meta + (e.place ? ` · ${e.place}` : "");
  if (clash && clash.length) li.querySelector(".meta").appendChild(clashLine(clash));

  // 제목 영역을 누르면 바로 수정 모드로 들어갑니다.
  const meta_ = li.querySelector(".meta");
  meta_.classList.add("tapedit");
  meta_.setAttribute("role", "button");
  meta_.setAttribute("tabindex", "0");
  meta_.title = "눌러서 수정";
  const go = () => startEdit(e, bucket);
  meta_.addEventListener("click", go);
  meta_.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); } });

  if (editing && editing.id === e.id) li.classList.add("editing");

  li.querySelector(".btn-edit").addEventListener("click", go);
  li.querySelector(".btn-del").addEventListener("click", () => {
    if (!confirm(`${withEul(e.title)} 지울까요?`)) return;
    sched[bucket] = sched[bucket].filter(x => x.id !== e.id);
    if (editing && editing.id === e.id) cancelEdit(true);
    writeLS(LS.sched, sched); renderEdit(); renderWeek(); renderToday();
    toast("삭제했습니다. 저장소에 반영하려면 아래 저장 버튼을 누르세요.");
  });
  return li;
}

/* ---- 설정 ---- */
function paintGeoSettings() {
  const b = $("geoToggle");
  if (!b) return;
  const on = geoOn();
  b.textContent = on ? "장소 확인 끄기" : "장소 확인 켜기";
  b.className = "btn" + (on ? " go" : "");
  const withGeo = sched.weekly.concat(sched.once).filter(e => e.geo).length;
  $("geoInfo").textContent = on
    ? `켜짐 — 장소가 등록된 일정 ${withGeo}개. 체크할 때 근처인지만 판정하고 좌표는 저장하지 않습니다.`
    : `꺼짐 — 장소가 등록된 일정은 ${withGeo}개 있지만 이 기기에서는 판정하지 않습니다.`;
}

function paintVoiceSettings() {
  const b = $("voiceToggle");
  if (!b) return;
  const v = voiceCfg();
  // 값 칸은 음성이 되든 안 되든 먼저 채웁니다(예전엔 빠져나가서 칸이 비어 보였습니다)
  $("voiceRate").value = v.rate;
  $("voiceMax").value = v.maxPerDay;
  $("quietFrom").value = v.quietFrom;
  $("quietTo").value = v.quietTo;
  const fix = $("voiceFix");
  fix.classList.add("hidden");

  if (!hasTTS()) {
    b.disabled = true;
    if (isNative()) {
      // 예전 APK: 음성 플러그인이 없는 버전
      b.textContent = "새 앱 버전이 필요해요";
      $("voiceInfo").textContent = "이 앱 버전에는 음성 엔진이 없습니다. 아래 '버전 → 지금 확인'에서 새 앱을 설치하면 켤 수 있어요.";
    } else {
      b.textContent = "이 브라우저는 음성을 지원하지 않습니다";
      $("voiceInfo").textContent = "크롬·사파리·엣지에서 열면 쓸 수 있어요.";
    }
    return;
  }
  if (nativeTTS() && ttsKoOk === false) {
    fix.classList.remove("hidden");
    fix.textContent = "한국어 음성 설치하기";
    fix.onclick = () => nativeTTS().openInstall().catch(() => toast("휴대폰 설정 → 텍스트 음성 변환에서 한국어를 설치해 주세요"));
  }
  b.disabled = false;
  b.textContent = v.on ? "음성 끄기" : "음성 켜기";
  b.className = "btn" + (v.on ? " go" : "");

  const sel = $("voicePick");
  if (sel && sel.dataset.n !== String(voiceList.length)) {
    sel.dataset.n = String(voiceList.length);
    sel.innerHTML = "";
    const ko = koVoices();
    if (!ko.length) {
      sel.innerHTML = `<option value="">한국어 목소리 없음 — 기본 목소리 사용</option>`;
    } else {
      for (const x of ko) {
        const o = document.createElement("option");
        o.value = x.voiceURI; o.textContent = x.name;
        sel.appendChild(o);
      }
      sel.value = v.uri || ko[0].voiceURI;
    }
  }
  const used = voiceCountToday();
  $("voiceInfo").textContent = (nativeTTS() && ttsKoOk === false)
    ? "이 휴대폰에 한국어 음성 데이터가 없어요. 아래 버튼으로 설치하세요."
    : v.on
    ? `오늘 ${used}/${v.maxPerDay}번 말했습니다.` +
      (inQuietHours(v) ? " 지금은 조용한 시간이라 말하지 않습니다." : "") +
      " 앱이 열려 있을 때만 소리가 납니다."
    : "꺼져 있습니다. 켜려면 한 번 눌러 주세요(브라우저가 그때 소리를 허용합니다).";
}

function paintKidPick() {
  const sel = $("sKid");
  if (!sel) return;
  const cur = sel.dataset.touched ? sel.value : (who !== "all" ? who : "");
  sel.innerHTML = `<option value="">고르세요</option>` +
    kids().map(k => `<option value="${k.id}">${k.emoji} ${esc(k.name)}</option>`).join("");
  sel.value = kids().some(k => k.id === cur) ? cur : "";
  $("sKidRow").classList.toggle("hidden", $("sRole").value !== "child");
}

function renderSettings() {
  $("sOwner").value = conn.owner;
  $("sRepo").value = conn.repo;
  $("sBranch").value = conn.branch;
  $("sStatusRepo").value = conn.statusRepo || "";
  $("sRole").value = conn.role;
  $("sToken").value = readLS(LS.token, "") ? "••••••••••••••••" : "";
  const yr = String(nowDate().getFullYear());
  const hi = $("holiInfo");
  if (holidayYearMissing(yr)) {
    hi.className = "hint warnline";
    hi.textContent = `${yr}년 공휴일이 등록되지 않았습니다. 저장소의 holidays.json 에 추가해 주세요. 그전까지는 공휴일에도 평소대로 일정이 뜹니다.`;
  } else {
    const cnt = Object.keys(holidays).filter(k => k.startsWith(yr + "-")).length;
    const next = Object.keys(holidays).filter(k => k >= ymd(nowDate())).sort()[0];
    hi.className = "hint";
    hi.textContent = `${yr}년 공휴일 ${cnt}일 등록됨` + (next ? ` · 다음 공휴일 ${next} ${holidays[next]}` : "");
  }

  const r = schedRepo.rate;
  $("rateInfo").textContent = r.remaining == null
    ? "아직 GitHub에 요청하지 않았습니다."
    : `남은 요청 ${r.remaining}회${r.reset ? ` · ${new Date(r.reset).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })}에 회복` : ""}`;
  paintNotify();
  paintGeoSettings();
  paintVoiceSettings();
  paintJoinSettings();
  paintVersion();
  paintKidPick();
}

/** 헤더의 아이 선택 버튼 */
const isChild = () => role() === "child";

function renderKidBar() {
  const bar = $("kidBar");
  if (!bar) return;
  bar.innerHTML = "";
  // 아이 기기는 자기 일정만 봅니다. 형제 이름 버튼을 아예 두지 않고, 자기 이름만 표시합니다.
  if (isChild()) {
    const me = kidById(who);
    bar.classList.toggle("hidden", !me);
    if (me) bar.innerHTML = `<span class="kidchip on mine">${me.emoji} ${esc(me.name)}</span>`;
    return;
  }
  const opts = kids().map(k => ({ id: k.id, label: `${k.emoji} ${k.name}` }));
  if (kids().length > 1 && isParent()) opts.push({ id: "all", label: "👨‍👩‍👧‍👦 모두" });
  bar.classList.toggle("hidden", opts.length < 2);

  for (const o of opts) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "kidchip" + (who === o.id ? " on" : "");
    b.textContent = o.label;
    b.addEventListener("click", async () => {
      if (who === o.id) return;
      who = o.id;
      conn.who = who; writeLS(LS.conn, conn);
      if (editing) cancelEdit(true);
      recCache = null;
      await loadDay(true);
      render();
      syncNativeAlarms(true);
    });
    bar.appendChild(b);
  }
}

function render() {
  renderKidBar();
  renderHeader(); renderProgress(); renderToday(); renderOwn(); renderReflect(); renderChallenges(); renderRewards();
  renderWeek(); renderEdit(); renderSettings();
}

/* APK(Capacitor)에서만 동작. 웹에서는 NativeAlarms 가 없거나 available=false 라 건너뜁니다.
   일정이 바뀔 때마다 안드로이드 알람을 통째로 다시 겁니다. */
let alarmSig = "";
/* 앱을 닫아도 울리는 APK 알람.
 * 예전엔 "매주 월 18:50" 반복으로 걸어서 오늘만 빼는 게 불가능했습니다
 * (16시에 숙제를 끝내도 19시 알림이 옴, 공휴일에도 울림).
 * 이제 앞으로 14일치를 날짜별로 한 번씩 예약하고, 오늘 이미 시작·완료한 일, 공휴일, 쉬는 날은 뺍니다.
 * 앱을 열 때·체크할 때·날짜가 바뀔 때 다시 맞춥니다. */
const ALARM_DAYS = 14;
function buildOccurrences() {
  const before = Number(sched.notifyBeforeMin || 0);
  const now = nowDate(), out = [];
  for (let i = 0; i < ALARM_DAYS; i++) {
    const d = new Date(now); d.setDate(now.getDate() + i);
    const key = ymd(d);
    for (const e of eventsOn(d)) {
      if (i === 0) {
        const r = recOf(e);
        if (r && ["running", "done", "over"].includes(r.state)) continue;   // 이미 한 일은 알리지 않음
      }
      // "시작했어?"는 예고 시각이 지나도 넣어야 하므로 예고보다 먼저 처리합니다
      if (e.track !== false && !canEarly(e)) {
        const nudge = new Date(`${key}T${e.start}:00`);
        nudge.setMinutes(nudge.getMinutes() + NUDGE_MIN);
        if (nudge > now) out.push({ key: `${e.id}@${key}#nudge`, at: nudge.toISOString(), eventId: e.id,
          title: `⏰ ${e.title} 시작했어?`, body: `${e.start} 시작이었어요. 시작 버튼을 눌러 주세요` });
      }
      const at = new Date(`${key}T${e.start}:00`);
      at.setMinutes(at.getMinutes() - before);
      if (at <= now) continue;
      out.push({
        key: `${e.id}@${key}`, at: at.toISOString(), eventId: e.id, title: e.title,
        body: (before > 0 ? `${before}분 뒤 시작` : "지금 시작") +
              (e.track === false ? "" : ` · 제한 ${limitOf(e)}분`) +
              (canEarly(e) && e.track !== false ? " · 미리 해도 돼요" : "")
      });
    }
  }
  return out;
}
function syncNativeAlarms(force) {
  if (!(global_NA() && global_NA().available)) return;
  const list = buildOccurrences();
  const sig = JSON.stringify([who, dayKey, list.map(o => o.key + o.at)]);
  if (sig === alarmSig && !force) return;
  alarmSig = sig;
  const NA = global_NA();
  const job = NA.syncOccurrences ? NA.syncOccurrences(list) : NA.syncSchedule({ notifyBeforeMin: sched.notifyBeforeMin, weekly: [], once: [] }, cfg);
  job.then(r => { if (r && !r.ok) toast("알람 등록 실패: " + r.error); });
}
function global_NA() { return typeof NativeAlarms !== "undefined" ? NativeAlarms : null; }

/* ===================== 알림 ===================== */
async function notify(title, body) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const opts = { body, icon: "./icon-192.png", badge: "./icon-192.png", tag: title + body };
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg && reg.showNotification) return reg.showNotification(title, opts);
  } catch (e) { }
  try { new Notification(title, opts); } catch (e) { }
}
function paintNotify() {
  const bar = $("notifyBar"), txt = $("notifyText"), btn = $("notifyBtn");
  // 연결이 빠진 기기면 그게 가장 중요한 안내라 맨 먼저 봅니다(예전엔 알림 미지원 안내에 가려졌음)
  if (!canWrite()) {
    bar.classList.remove("on"); bar.classList.add("warn");
    txt.textContent = "이 기기는 보기만 하는 기기예요. 부모님 기기에서 받은 연결 링크를 설정 맨 위에 붙여넣으면 체크할 수 있어요.";
    btn.classList.add("hidden");
    return;
  }
  // APK: 브라우저 알림 대신 안드로이드 알람을 씁니다(앱을 닫아도 울림)
  if (isNative() && global_NA() && global_NA().available) {
    bar.classList.add("on"); bar.classList.remove("warn");
    txt.textContent = `앱을 닫아도 알림이 와요 — 시작 ${sched.notifyBeforeMin}분 전, 끝날 시간·제한시간.`;
    btn.classList.remove("hidden"); btn.textContent = "알림 확인";
    return;
  }
  if (!("Notification" in window)) {
    txt.textContent = "이 브라우저는 알림을 지원하지 않습니다. 캘린더 파일을 쓰세요.";
    btn.classList.add("hidden"); return;
  }
  btn.classList.remove("hidden");
  if (Notification.permission === "granted" && notifyOn) {
    bar.classList.add("on"); bar.classList.remove("warn");
    txt.textContent = `알림 켜짐 — 일정 ${sched.notifyBeforeMin}분 전과 제한시간 초과 때 알립니다. 앱이 열려 있을 때만 울립니다.`;
    btn.textContent = "끄기";
  } else if (Notification.permission === "denied") {
    bar.classList.remove("on"); bar.classList.add("warn");
    txt.textContent = "알림이 차단돼 있습니다. 브라우저 사이트 설정에서 허용으로 바꿔 주세요.";
    btn.classList.add("hidden");
  } else {
    bar.classList.remove("on", "warn");
    txt.textContent = "일정 시간에 알림을 받으려면 켜 주세요.";
    btn.textContent = "알림 켜기";
  }
}

/* ===================== 틱 ===================== */
let lastDayKey = "";
let lastMinuteKey = -1;
function tick() {
  const now = nowDate(), key = ymd(now);
  if (key !== lastDayKey) {
    lastDayKey = key; firedMap = {}; recCache = null; saidToday.clear();
    // 어제 것을 어제 날짜(dayKey 는 아직 어제)로 먼저 보내고, 끝난 뒤 오늘을 불러옵니다
    Promise.resolve(flush()).catch(() => { }).finally(() => loadDay(true).then(() => { render(); syncNativeAlarms(true); }));
    return;
  }
  renderHeader();
  // 진행 중 항목이 있으면 진행바를 위해 오늘 목록도 다시 그림
  // 1분에 한 번: 끝난 일정은 아래로, 하는 중인 것의 경과 시간은 갱신.
  // (예전엔 하는 중이면 5초마다 통째로 다시 그려서, 책 제목을 치던 글자가 날아갔습니다)
  const minuteKey = Math.floor(nowMin());
  if (minuteKey !== lastMinuteKey && !typingInList()) {
    lastMinuteKey = minuteKey;
    renderToday(); renderOwn(); renderProgress();
  }

  // 화면 알림과 음성은 따로 켤 수 있습니다.
  // 알림 권한을 거부했어도 음성만으로 쓸 수 있어야 합니다.
  const wantNotify = notifyOn && ("Notification" in window) && Notification.permission === "granted";
  const wantVoice = hasTTS() && voiceCfg().on;
  if (!wantNotify && !wantVoice) return;

  const nm = nowMin(), before = sched.notifyBeforeMin;
  for (const e of eventsOn(now)) {
    const tracked = e.track !== false;
    const rec = recOf(e);
    const st = stateOf(e, rec, nm);
    const k = kindOf(e.kind);
    if (!tracked && (st === "todo" || st === "locked" || st === "missed")) {
      const diff0 = mins(e.start) - nm;
      if (before > 0 && diff0 <= before && diff0 > 0 && !firedMap[e.id + "|pre"]) {
        firedMap[e.id + "|pre"] = 1;
        if (wantVoice) sayOnce(e.id + "|pre", sayPre(e.title, Math.max(1, Math.round(diff0))));
        if (wantNotify) notify(`${k.emoji} ${human(diff0)} 뒤 ${e.title}`, `${e.start} 시작${e.place ? " · " + e.place : ""}`);
      }
      continue;
    }
    if (st === "todo" || st === "locked") {
      const diff = mins(e.start) - nm;
      if (before > 0 && diff <= before && diff > 0 && !firedMap[e.id + "|pre"]) {
        firedMap[e.id + "|pre"] = 1;
        if (wantVoice) sayOnce(e.id + "|pre", sayPre(e.title, Math.max(1, Math.round(diff))));
        if (wantNotify) notify(`${who === "all" ? kidTag(e) + " · " : ""}${k.emoji} ${human(diff)} 뒤 ${e.title}`, tracked ? `${e.start} 시작 · 제한 ${limitOf(e)}분` : `${e.start} 시작${e.place ? " · " + e.place : ""}`);
      }
      if (diff <= 0 && diff > -1.5 && !firedMap[e.id + "|now"]) {
        firedMap[e.id + "|now"] = 1;
        if (wantVoice) sayOnce(e.id + "|now", sayStart(e.title));
        if (wantNotify) notify(`${who === "all" ? kidTag(e) + " · " : ""}${k.emoji} ${e.title} 시작!`, tracked ? `제한 ${limitOf(e)}분 · 시작 버튼을 눌러 주세요` : (e.place || "지금 시작할 시간이에요"));
      }
    }
    if (st === "todo" && tracked && !canEarly(e)) {
      const w = windowOf(e);
      if (nm >= w.startM + NUDGE_MIN && nm < w.endM && !firedMap[e.id + "|nudge"]) {
        firedMap[e.id + "|nudge"] = 1;
        if (wantVoice) sayOnce(e.id + "|nudge", `${e.title} 시작했어? 시작 버튼을 눌러 줘`);
        if (wantNotify) notify(`⏰ ${e.title} 시작했어?`, `${e.start} 시작이었어요. 시작 버튼을 눌러 주세요`);
      }
    }
    if (st === "running" && !canEarly(e)) {
      const pr = progressOf(e, rec);
      if (pr.ended && !firedMap[e.id + "|end"]) {
        firedMap[e.id + "|end"] = 1;
        if (wantVoice) sayOnce(e.id + "|end", `${e.title} 끝날 시간이야. 다 했으면 완료를 눌러 줘`);
        if (wantNotify) notify(`🏁 ${e.title} 끝날 시간`, "다 했으면 완료를 눌러 주세요");
      }
    } else if (st === "running") {
      const el = elapsedOf(rec), lim = rec.limitMin || limitOf(e);
      if (el > lim && !firedMap[e.id + "|over"]) {
        firedMap[e.id + "|over"] = 1;
        if (wantVoice) sayOnce(e.id + "|over", sayOver(e.title));
        if (wantNotify) notify(`⏰ ${who === "all" ? kidTag(e) + " " : ""}${e.title} 제한시간 초과`, `${lim}분이 지났어요. 지금 ${human(el)} 경과`);
      }
    }
  }
}

/* ===================== ICS ===================== */
function icsEsc(s) { return String(s).replace(/([,;\\])/g, "\\$1").replace(/\n/g, "\\n"); }
function fold(line) {
  if (new Blob([line]).size <= 73) return line;
  const out = []; let buf = "";
  for (const ch of line) {
    if (new Blob([buf + ch]).size > 72) { out.push(buf); buf = " " + ch; } else buf += ch;
  }
  out.push(buf); return out.join("\r\n");
}
const dtL = (d, t) => d.replace(/-/g, "") + "T" + t.replace(":", "") + "00";
function buildIcs() {
  const stamp = new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const BYDAY = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
  const before = sched.notifyBeforeMin;
  const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//kid-schedule//KR//", "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH", "X-WR-CALNAME:" + icsEsc((who === "all" ? "" : (kidById(who) || {}).name + " ") + "스케줄"),
    "X-WR-TIMEZONE:Asia/Seoul", "BEGIN:VTIMEZONE", "TZID:Asia/Seoul", "BEGIN:STANDARD",
    "DTSTART:19700101T000000", "TZOFFSETFROM:+0900", "TZOFFSETTO:+0900", "TZNAME:KST",
    "END:STANDARD", "END:VTIMEZONE"];
  const put = (e, dateStr, rrule) => {
    const k = kindOf(e.kind), lim = limitOf(e);
    const endT = e.end || hhmm(mins(e.start) + lim);
    L.push("BEGIN:VEVENT", `UID:${e.id}-${dateStr}@kid-schedule`, `DTSTAMP:${stamp}`,
      `DTSTART;TZID=Asia/Seoul:${dtL(dateStr, e.start)}`, `DTEND;TZID=Asia/Seoul:${dtL(dateStr, endT)}`,
      `SUMMARY:${icsEsc((who === "all" ? kidTag(e) + " " : "") + k.emoji + " " + e.title)}`,
      `DESCRIPTION:${icsEsc("제한시간 " + lim + "분")}`);
    if (e.place) L.push(`LOCATION:${icsEsc(e.place)}`);
    L.push(`CATEGORIES:${icsEsc(k.name)}`);
    if (rrule) L.push(rrule);
    // 제외일 = 수동 off + (공휴일에 쉬는 일정이면) 그 요일에 걸리는 공휴일
    const ex = new Set(e.off || []);
    if (rrule && e.onHoliday !== "keep") {
      const dow = e.day;
      for (const k of Object.keys(holidays)) {
        if (k >= dateStr && new Date(k + "T12:00:00").getDay() === dow) ex.add(k);
      }
    }
    if (ex.size) L.push("EXDATE;TZID=Asia/Seoul:" + [...ex].sort().map(d => dtL(d, e.start)).join(","));
    if (before > 0) L.push("BEGIN:VALARM", "ACTION:DISPLAY", `TRIGGER:-PT${before}M`,
      "DESCRIPTION:" + icsEsc(`${before}분 뒤 ${e.title}`), "END:VALARM");
    L.push("END:VEVENT");
  };
  const today = nowDate(), mon = new Date(today);
  mon.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const want = scopeKids().map(k => k.id);
  for (const e of sched.weekly) {
    if (!want.includes(e.kid)) continue;
    const first = new Date(mon); first.setDate(mon.getDate() + ((e.day + 6) % 7));
    put(e, ymd(first), `RRULE:FREQ=WEEKLY;BYDAY=${BYDAY[e.day]}`);
  }
  for (const e of sched.once) if (want.includes(e.kid)) put(e, e.date, null);
  L.push("END:VCALENDAR");
  return L.map(fold).join("\r\n") + "\r\n";
}

/* ===================== 이벤트 배선 ===================== */
function wire() {
  document.querySelectorAll("nav.tabs button").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll("nav.tabs button").forEach(x => x.setAttribute("aria-selected", String(x === b)));
      ["today", "week", "rec", "edit", "set"].forEach(t => $("tab-" + t).classList.toggle("hidden", t !== b.dataset.tab));
      window.scrollTo({ top: 0 });
      if (b.dataset.tab === "rec") renderRecords(false);
    });
  });

  // 일정 추가 폼
  const sel = $("fKind");
  for (const k of KINDS) { const o = document.createElement("option"); o.value = k.id; o.textContent = `${k.emoji} ${k.name}`; sel.appendChild(o); }
  // "내가 정한 것" 종류 선택
  const ok = $("ownKind");
  for (const k of KINDS) {
    const o = document.createElement("option");
    o.value = k.id; o.textContent = `${k.emoji} ${k.name}`;
    ok.appendChild(o);
  }
  ok.value = "study";

  $("ownForm").addEventListener("submit", ev => {
    ev.preventDefault();
    const kid = oneKid(); if (!kid) return;
    const title = $("ownTitle").value.trim();
    if (!title) return;
    const lim = $("ownLimit").value === "" ? null : Math.max(1, Math.min(600, Number($("ownLimit").value)));
    ownAdd(kid, title, lim, $("ownKind").value);
    $("ownTitle").value = ""; $("ownLimit").value = "";
    $("ownTitle").focus();
    toast("추가했어요. 시작을 눌러 보세요.");
  });

  document.querySelectorAll("#starRow button").forEach(b => {
    b.addEventListener("click", () => {
      const kid = oneKid(); if (!kid) return;
      const R = reflectOf(kid);
      const v = Number(b.dataset.v);
      R.rating = (R.rating === v) ? 0 : v;   // 같은 별을 다시 누르면 취소
      markMeta(kid); renderReflect();
    });
  });
  for (const [id, key] of [["rGood", "good"], ["rNext", "next"]]) {
    $(id).addEventListener("change", e => {
      const kid = oneKid(); if (!kid) return;
      reflectOf(kid)[key] = e.target.value.trim() || null;
      markMeta(kid);
    });
  }

  const det = $("fDetail");
  for (const f of DETAIL_FIELDS) {
    const l = document.createElement("label");
    l.className = "dchip";
    l.innerHTML = `<input type="checkbox" value="${f.id}">${f.label}`;
    det.appendChild(l);
  }

  const dows = $("fDows");
  [1, 2, 3, 4, 5, 6, 0].forEach(d => {
    const l = document.createElement("label");
    l.innerHTML = `<input type="checkbox" value="${d}">${DOW[d]}`;
    dows.appendChild(l);
  });

  $("addForm").addEventListener("submit", ev => {
    ev.preventDefault();
    const title = $("fTitle").value.trim(), kind = $("fKind").value;
    const start = $("fStart").value, end = $("fEnd").value, place = $("fPlace").value.trim();
    const limitRaw = $("fLimit").value, date = $("fDate").value;
    const days = [...document.querySelectorAll("#fDows input:checked")].map(i => Number(i.value));
    if (!title || !start) { toast("이름과 시작 시간을 넣어 주세요"); return; }
    if (end && mins(end) <= mins(start)) { toast("끝 시간이 시작보다 빠릅니다"); return; }
    if (!days.length && !date) { toast("요일이나 날짜 중 하나는 골라 주세요"); return; }
    const limitMin = limitRaw === "" ? null : Math.max(1, Number(limitRaw));
    const track = $("fTrack").checked;
    const onHoliday = $("fHoli").checked ? "keep" : "skip";
    const detail = [...document.querySelectorAll("#fDetail input:checked")].map(i => i.value);

    if (editing) {
      // 수정 — 고른 일정 하나만 바꿉니다. 여러 요일을 한 번에 옮길 수는 없습니다.
      if (days.length > 1) { toast("수정할 때는 요일을 하나만 고르세요"); return; }
      if (days.length && date) { toast("요일과 날짜 중 하나만 고르세요"); return; }
      const cur = sched[editing.bucket].find(x => x.id === editing.id);
      if (!cur) { toast("수정할 일정을 찾지 못했습니다"); cancelEdit(true); return; }

      const moved = date && editing.bucket === "weekly" ? "once"
                  : days.length && editing.bucket === "once" ? "weekly" : null;
      const next = { ...cur, start, end, limitMin, title, kind, place, track, onHoliday, geo: formGeo, detail };
      if (days.length) { next.day = days[0]; delete next.date; }
      if (date) { next.date = date; delete next.day; delete next.off; }

      if (moved) {                       // 반복 ↔ 하루짜리 사이를 옮긴 경우
        sched[editing.bucket] = sched[editing.bucket].filter(x => x.id !== editing.id);
        sched[moved].push(next);
      } else {
        Object.assign(cur, next);
      }
      writeLS(LS.sched, sched);
      cancelEdit(true);
      renderWeek(); renderToday();
      toast(`${withEul(title)} 고쳤습니다. 아래 저장 버튼으로 저장소에 반영하세요.`);
      return;
    }

    if (!oneKid()) { toast("아이를 한 명 고른 뒤 추가하세요"); return; }
    if (days.length) for (const d of days) sched.weekly.push({ id: uid(), kid: who, day: d, start, end, limitMin, title, kind, place, track, onHoliday, geo: formGeo, detail, off: [] });
    if (date) sched.once.push({ id: uid(), kid: who, date, start, end, limitMin, title, kind, place, track, geo: formGeo, detail });
    writeLS(LS.sched, sched);
    ev.target.reset(); $("fStart").value = start; $("fTrack").checked = true; $("fHoli").checked = false;
    formGeo = null; paintFormGeo();
    document.querySelectorAll("#fDetail input").forEach(i => { i.checked = false; });
    renderEdit(); renderWeek(); renderToday();

    // 방금 넣은 일정이 기존 것과 겹치는지 바로 알려 줍니다(막지는 않습니다).
    const hits = new Set();
    for (const d of days) {
      const items = sched.weekly.filter(x => x.kid === who && x.day === d);
      const m = overlapMap(items);
      for (const x of items) if (x.title === title && m.has(x.id)) m.get(x.id).forEach(t => hits.add(`${DOW[d]} ${t}`));
    }
    if (date) {
      const dow = new Date(date + "T12:00:00").getDay();
      const items = sched.once.filter(x => x.kid === who && x.date === date)
        .concat(sched.weekly.filter(w => w.kid === who && w.day === dow && !(w.off || []).includes(date)));
      const m = overlapMap(items);
      for (const x of items) if (x.title === title && m.has(x.id)) m.get(x.id).forEach(t => hits.add(t));
    }
    toast(hits.size
      ? `추가했습니다 — ${withGwa([...hits].join(", "))} 시간이 겹칩니다`
      : "추가했습니다. 아래 저장 버튼으로 저장소에 반영하세요.");
  });

  // 종류를 바꾸면 그 종류의 기본 기록 항목을 자동으로 켭니다(수정 중일 때는 건드리지 않음).
  $("fKind").addEventListener("change", ev => {
    if (editing) return;
    const def = DEFAULT_DETAIL[ev.target.value];
    if (!def) return;
    document.querySelectorAll("#fDetail input").forEach(i => { i.checked = def.includes(i.value); });
  });
  $("fCancel").addEventListener("click", () => cancelEdit());

  // ---- 장소 등록 ----
  $("geoSet").addEventListener("click", async () => {
    toast("위치를 읽는 중…");
    try {
      const pos = await readPosition();
      // 소수점 3자리 = 약 110m 격자. 정확한 주소가 드러나지 않게 반올림해 저장합니다.
      formGeo = {
        lat: Math.round(pos.lat * 1000) / 1000,
        lng: Math.round(pos.lng * 1000) / 1000,
        radius: Math.max(50, Math.min(2000, Number($("fRadius").value) || 300))
      };
      paintFormGeo();
      toast(`장소를 지정했습니다 (측정 오차 약 ${Math.round(pos.acc || 0)}m)`);
    } catch (e) {
      toast("위치를 읽지 못했습니다. 브라우저 위치 권한을 확인하세요.");
    }
  });
  $("geoClear").addEventListener("click", () => { formGeo = null; paintFormGeo(); toast("장소를 지웠습니다"); });
  $("fRadius").addEventListener("change", e => {
    const v = Math.max(50, Math.min(2000, Number(e.target.value) || 300));
    e.target.value = v;
    if (formGeo) { formGeo.radius = v; paintFormGeo(); }
  });

  // ---- 이달의 보상 ----
  $("rewardEdit").addEventListener("click", openRewardEditor);
  $("rewardAdd").addEventListener("click", () => addRewardRow({ need: 20, gift: "" }));
  $("rewardCopy").addEventListener("click", copyLastMonthRewards);
  $("rewardSave").addEventListener("click", saveRewardEditor);
  $("rewardCancel").addEventListener("click", () => { rewardEditing = false; render(); });

  // ---- 목표 챌린지 ----
  $("chalNew").addEventListener("click", () => {
    const f = $("chalForm");
    f.classList.toggle("hidden");
    if (!f.classList.contains("hidden")) { paintChalLinks(); paintChalThemes(); $("chalGoal").focus(); }
  });
  $("chalForm").addEventListener("submit", ev => {
    ev.preventDefault();
    const kid = oneKid(); if (!kid) return;
    const goal = $("chalGoal").value.trim();
    if (!goal) return;
    const theme = (document.querySelector('#chalTheme input:checked') || {}).value || "star";
    const emoji = [...($("chalEmoji").value.trim())].slice(0, 2).join("");   // 이모지 하나(합자 대비 2글자까지)
    if (theme === "emoji" && !emoji) { toast("쓸 이모지를 하나 넣어 주세요"); return; }
    const c = chalAdd(kid, goal, $("chalGift").value.trim(), Number($("chalSize").value) || 20,
                      $("chalLink").value || null, theme, emoji);
    ev.target.reset(); $("chalSize").value = "20";
    paintChalThemes();
    $("chalForm").classList.add("hidden");
    render();
    toast(`${chalIcon(c)} "${c.goal}" 챌린지 시작! ${c.size}개 모으면 ${c.gift ? "🎁 " + c.gift : "완주"}`);
  });
  $("chalCancel").addEventListener("click", () => { $("chalForm").classList.add("hidden"); });

  // ---- 연결 링크 붙여넣기 (APK 등 카메라로 앱이 안 열리는 기기) ----
  $("joinPaste").addEventListener("click", async () => {
    let text = $("joinPasteText").value.trim();
    if (!text) { try { text = await navigator.clipboard.readText(); } catch (e) { } }
    if (!readJoinHash(text)) { toast("연결 링크가 아닙니다. #join= 이 들어 있어야 합니다."); return; }
    if (!applyJoinFromHash(text)) return;
    $("joinPasteText").value = "";
    buildRepos();
    await loadSchedule();
    // 부팅 때와 똑같이 맞춥니다 (부모는 "모두", 아이는 링크에 담긴 아이)
    who = defaultWho();
    await loadDay(true); recCache = null;
    render(); syncNativeAlarms(true);
    toast("이 기기를 연결했습니다");
  });

  // ---- 다른 기기 연결 ----
  $("joinMake").addEventListener("click", showJoinQR);
  $("joinHide").addEventListener("click", hideJoinQR);
  $("joinCopy").addEventListener("click", async () => {
    const link = $("joinQR").dataset.link;
    if (!link) return;
    try { await navigator.clipboard.writeText(link); toast("링크를 복사했습니다. 보낸 뒤 대화에서 지워 주세요."); }
    catch (e) { toast("복사가 막혀 있습니다. QR 을 쓰세요."); }
  });
  $("joinRole").addEventListener("change", e => {
    $("joinKidRow").classList.toggle("hidden", e.target.value === "parent");
    hideJoinQR();
  });
  $("joinKid").addEventListener("change", hideJoinQR);
  document.querySelector('nav.tabs').addEventListener("click", hideJoinQR);   // 탭을 떠나면 지웁니다

  $("updClose").addEventListener("click", closeUpdBar);

  // ---- 버전 지금 확인 ----
  $("verCheck").addEventListener("click", async () => {
    await checkWebUpdate(); await checkApkUpdate(true); paintVersion();
    toast(webVerNew ? "새 화면 버전이 있어요. 아래 알림에서 적용하세요" : "지금이 최신이에요");
  });

  // ---- 체크 가능 시간 ----
  for (const [id, key] of [["fChkBefore", "beforeMin"], ["fChkAfter", "afterMin"]]) {
    $(id).addEventListener("change", e => {
      const c = checkCfg();
      c[key] = Math.max(0, Math.min(180, Number(e.target.value) || 0));
      e.target.value = c[key];
      sched.check = c; writeLS(LS.sched, sched);
      render(); syncNativeAlarms(true);
      toast("바꿨어요. '저장소에 저장'을 누르면 모든 기기에 적용됩니다");
    });
  }

  // ---- 한 번에 고치기 ----
  $("bulkLoad").addEventListener("click", () => {
    const kid = oneKid(); if (!kid) return;
    $("bulkText").value = schedToText(kid);
    $("bulkText").dataset.kid = kid;
    $("bulkOut").innerHTML = ""; $("bulkApply").disabled = true; bulkPlan = null;
    toast("지금 일정을 불러왔습니다");
  });
  $("bulkPreview").addEventListener("click", bulkPreview);
  $("bulkText").addEventListener("input", () => { $("bulkApply").disabled = true; bulkPlan = null; });
  $("bulkApply").addEventListener("click", () => {
    const kid = oneKid();
    if (!kid || !bulkPlan) return;
    const D = bulkPlan.diff;
    if (D.remove.length && !confirm(`${D.remove.length}개 일정이 지워집니다. 계속할까요?`)) return;
    applyBulk(kid, bulkPlan);
    bulkPlan = null;
    $("bulkApply").disabled = true;
    $("bulkText").value = schedToText(kid);          // 정리된 모양으로 다시 보여 줍니다
    $("bulkOut").innerHTML = `<p class="bulksum">적용했습니다 — 추가 ${D.add.length} · 변경 ${D.change.length} · 삭제 ${D.remove.length}</p>`;
    render(); syncNativeAlarms(true);
    if (schedRepo.authed) $("saveSched").click();    // 토큰이 있으면 바로 저장소에 커밋
    else toast("적용했습니다. 토큰을 넣으면 저장소에도 저장됩니다.");
  });

  // ---- 설정: 음성 ----
  $("voiceToggle").addEventListener("click", () => {
    const v = voiceCfg();
    v.on = !v.on;
    writeLS(LS_VOICE, v);
    // 켜는 순간이 사용자의 조작이므로, 여기서 한 번 말해 브라우저의 소리 허용을 받아 둡니다.
    if (v.on) speak("음성 알림을 켰어요. 일정 시간이 되면 알려 줄게요", true);
    paintVoiceSettings();
    toast(v.on ? "음성 알림을 켰습니다" : "음성 알림을 껐습니다");
  });
  $("voiceTest").addEventListener("click", () => {
    const sample = (eventsOn(nowDate(), oneKid())[0] || {}).title || "숙제";
    if (!speak(sayStart(sample), true)) toast("소리를 낼 수 없습니다. 기기 음량과 무음 모드를 확인하세요.");
  });
  $("voicePick").addEventListener("change", e => {
    const v = voiceCfg(); v.uri = e.target.value; writeLS(LS_VOICE, v);
    speak("이 목소리로 말할게요", true);
  });
  $("voiceRate").addEventListener("change", e => {
    const v = voiceCfg();
    v.rate = Math.max(0.6, Math.min(1.4, Number(e.target.value) || 0.95));
    e.target.value = v.rate; writeLS(LS_VOICE, v);
    speak("이 빠르기로 말할게요", true);
  });
  $("voiceMax").addEventListener("change", e => {
    const v = voiceCfg();
    v.maxPerDay = Math.max(1, Math.min(30, Number(e.target.value) || 8));
    e.target.value = v.maxPerDay; writeLS(LS_VOICE, v); paintVoiceSettings();
  });
  for (const [id, key] of [["quietFrom", "quietFrom"], ["quietTo", "quietTo"]]) {
    $(id).addEventListener("change", e => {
      const v = voiceCfg(); v[key] = e.target.value || v[key];
      writeLS(LS_VOICE, v); paintVoiceSettings();
    });
  }

  // ---- 설정: 장소 확인 켜기/끄기 ----
  $("geoToggle").addEventListener("click", async () => {
    if (geoOn()) { writeLS(LS_GEO, false); paintGeoSettings(); toast("장소 확인을 껐습니다"); return; }
    try {
      await readPosition();                  // 권한 요청을 겸합니다
      writeLS(LS_GEO, true); paintGeoSettings(); toast("장소 확인을 켰습니다");
    } catch (e) {
      toast("위치 권한이 없어 켤 수 없습니다");
    }
  });
  $("geoTest").addEventListener("click", async () => {
    const today = eventsOn(nowDate()).filter(e => e.geo);
    if (!today.length) { toast("오늘 일정 중 장소가 등록된 것이 없습니다"); return; }
    toast("위치를 읽는 중…");
    try {
      const pos = await readPosition();
      const lines = today.map(e => `${e.title} ${Math.round(distM(pos, e.geo))}m`);
      $("geoInfo").textContent = `지금 위치 기준 — ${lines.join(" · ")} (측정 오차 약 ${Math.round(pos.acc || 0)}m)`;
    } catch (e) { $("geoInfo").textContent = "위치를 읽지 못했습니다."; }
  });
  $("fName").addEventListener("change", e => {
    const k = kidById(who); if (!k) return;
    k.name = e.target.value.trim() || k.name;
    writeLS(LS.sched, sched); render();
  });
  $("kidAdd").addEventListener("click", () => {
    if (kids().length >= 6) { toast("아이는 6명까지입니다"); return; }
    const i = kids().length;
    const k = { id: "kid" + (i + 1) + uid().slice(0, 3), name: `아이 ${i + 1}`,
                emoji: KID_EMOJI[i % KID_EMOJI.length], color: KID_COLOR[i % KID_COLOR.length] };
    sched.kids.push(k); who = k.id; conn.who = who; writeLS(LS.conn, conn);
    writeLS(LS.sched, sched); render();
    toast(`${k.emoji} ${k.name} 을(를) 추가했습니다. 이름을 바꾸고 일정을 넣으세요.`);
  });
  $("kidDel").addEventListener("click", () => {
    const k = kidById(who); if (!k) return;
    if (kids().length < 2) { toast("마지막 아이는 지울 수 없습니다"); return; }
    const cnt = sched.weekly.concat(sched.once).filter(e => e.kid === k.id).length;
    if (!confirm(`${k.name} 과(와) 그 일정 ${cnt}개를 지울까요? 이미 쌓인 기록 파일은 남습니다.`)) return;
    sched.weekly = sched.weekly.filter(e => e.kid !== k.id);
    sched.once = sched.once.filter(e => e.kid !== k.id);
    sched.kids = sched.kids.filter(x => x.id !== k.id);
    who = sched.kids[0].id; conn.who = who; writeLS(LS.conn, conn);
    writeLS(LS.sched, sched); render();
    toast("지웠습니다. 저장소에 반영하려면 저장 버튼을 누르세요.");
  });
  $("fBefore").addEventListener("change", e => {
    sched.notifyBeforeMin = Math.max(0, Math.min(120, Number(e.target.value) || 0));
    syncNativeAlarms(true);
    e.target.value = sched.notifyBeforeMin; writeLS(LS.sched, sched); paintNotify();
  });
  $("fWinBefore").addEventListener("change", e => { cfg.check.beforeMin = Math.max(0, Number(e.target.value) || 0); render(); });
  $("fWinAfter").addEventListener("change", e => { cfg.check.afterMin = Math.max(0, Number(e.target.value) || 0); render(); });

  // 일정 저장소에 반영
  $("saveSched").addEventListener("click", async () => {
    if (!schedRepo.authed) { toast("토큰이 없어 저장할 수 없습니다"); return; }
    syncState("busy", "일정 저장 중");
    try {
      const r = await schedRepo.updateJson("schedule.json", () => sched, "chore(schedule): 일정 갱신");
      schedSha = r.sha;
      syncNativeAlarms();
      syncState("ok", "일정 저장됨");
      toast("저장소에 커밋했습니다");
    } catch (e) { syncState("err", e.message); toast(e.message); }
  });
  $("reloadSched").addEventListener("click", async () => {
    if (!confirm("저장소의 schedule.json 을 다시 불러옵니다. 저장하지 않은 편집은 사라집니다.")) return;
    localStorage.removeItem(LS.sched);
    await loadSchedule(); render(); syncNativeAlarms(); toast("다시 불러왔습니다");
  });

  // 설정 저장
  $("saveConn").addEventListener("click", async () => {
    conn.owner = $("sOwner").value.trim();
    conn.repo = $("sRepo").value.trim();
    conn.branch = $("sBranch").value.trim() || "main";
    const sr = $("sStatusRepo").value.trim();
    conn.statusRepo = sr || null;
    conn.statusOwner = sr ? (sr.includes("/") ? sr.split("/")[0] : conn.owner) : null;
    if (sr && sr.includes("/")) conn.statusRepo = sr.split("/")[1];
    conn.role = $("sRole").value;
    writeLS(LS.conn, conn);
    const tv = $("sToken").value;
    if (tv && !/^•+$/.test(tv)) writeLS(LS.token, tv.trim());
    if (conn.role === "child") {
      const pickKid = $("sKid").value;
      if (!kidById(pickKid)) { toast("이 기기의 아이를 골라 주세요"); return; }
      who = pickKid;
    } else if (who === "all" && !isParent()) who = (kids()[0] || {}).id || "";
    conn.who = who; writeLS(LS.conn, conn);
    buildRepos();
    syncState("busy", "확인 중");
    try {
      if (schedRepo.authed) {
        const info = await schedRepo.check();
        if (!info.canPush) { syncState("err", "이 토큰에는 쓰기 권한이 없습니다"); toast("Contents를 Read and write로 주세요"); }
        else syncState("ok", `${info.fullName} 연결됨`);
      } else syncState("ok", "읽기 전용");
      await loadSchedule(); await loadDay(true); recCache = null; render();
      toast("설정을 저장했습니다");
    } catch (e) { syncState("err", e.message); toast(e.message); }
  });
  $("sRole").addEventListener("change", () => { $("sKidRow").classList.toggle("hidden", $("sRole").value !== "child"); });
  $("sKid").addEventListener("change", e => { e.target.dataset.touched = "1"; });
  $("clearToken").addEventListener("click", () => {
    if (!confirm("이 기기에 저장된 토큰을 지웁니다.")) return;
    localStorage.removeItem(LS.token); buildRepos(); render(); toast("토큰을 지웠습니다");
  });
  $("syncNow").addEventListener("click", async () => { await flush(); await loadDay(true); recCache = null; render(); toast("동기화했습니다"); });
  $("recReload").addEventListener("click", () => renderRecords(true));
  document.querySelectorAll("#repMode button").forEach(b =>
    b.addEventListener("click", () => { repMode = b.dataset.mode; repOffset = 0; renderRecords(false); }));
  $("repPrev").addEventListener("click", () => { repOffset--; renderRecords(false); });
  $("repNext").addEventListener("click", () => { if (repOffset < 0) { repOffset++; renderRecords(false); } });
  $("repCopy").addEventListener("click", async () => {
    const t = reportText();
    if (!t) { toast("먼저 리포트를 불러오세요"); return; }
    try { await navigator.clipboard.writeText(t); toast("복사했습니다. 붙여넣기 하세요."); }
    catch (e) { toast("복사가 막혀 있습니다. 파일로 저장을 쓰세요."); }
  });
  $("repSave").addEventListener("click", () => {
    const t = reportText();
    if (!t) { toast("먼저 리포트를 불러오세요"); return; }
    const me = kidById(who) || {};
    download(`${me.name}_${repMode === "week" ? "주간" : "월간"}리포트.txt`, t, "text/plain");
  });

  $("notifyBtn").addEventListener("click", async () => {
    if (isNative() && global_NA() && global_NA().available) {
      const ok = await global_NA().init();
      syncNativeAlarms(true);
      toast(ok ? "알림 권한이 켜져 있어요. 일정 알람을 다시 맞췄어요" : (global_NA().lastError || "알림 권한을 켜 주세요"));
      return;
    }
    if (notifyOn) { notifyOn = false; writeLS(LS.notify, false); paintNotify(); return; }
    const p = await Notification.requestPermission();
    if (p === "granted") { notifyOn = true; writeLS(LS.notify, true); notify("알림을 켰습니다", "일정 시간과 제한시간 초과를 알려줄게요."); }
    paintNotify();
  });

  $("expIcs").addEventListener("click", () => {
    if (!sched.weekly.length && !sched.once.length) { toast("내보낼 일정이 없습니다"); return; }
    download("schedule.ics", buildIcs(), "text/calendar");
    toast("내려받은 파일을 열면 캘린더에 등록됩니다");
  });
  $("expJson").addEventListener("click", () => download("schedule.json", JSON.stringify(sched, null, 2), "application/json"));

  document.addEventListener("visibilitychange", async () => {
    if (document.hidden) { flush(); flushChallenges(); flushRewards(); return; }
    await checkWebUpdate();
    maybeAutoReload();
    await loadDay(true); render(); tick();
  });
  window.addEventListener("beforeunload", () => {
    if (Object.values(dirtyMap).some(x => x.size) || dirtyMeta.size) flush();
    flushChallenges();
    flushRewards();
  });
}

/* ===================== 시작 ===================== */
async function boot() {
  wire();
  loadVoices();
  await loadConfig();
  if (applyJoinFromHash()) { buildRepos(); setTimeout(() => toast("이 기기를 연결했습니다"), 600); }
  await loadHolidays();
  await loadSchedule();
  who = defaultWho();
  lastDayKey = ymd(nowDate());
  await loadDay(true);
  notifyOn = !!readLS(LS.notify, false) && ("Notification" in window) && Notification.permission === "granted";
  render();
  syncNativeAlarms();
  tick();
  setInterval(tick, 5000);
  setInterval(() => {
    if (!document.hidden && statusRepo.authed
        && !Object.values(dirtyMap).some(x => x.size) && !dirtyMeta.size) {
      (isParent() ? Promise.resolve() : loadSchedule()).then(() => loadDay(true)).then(render);
    }
  }, 60000);
  try { navigator.serviceWorker?.register("./sw.js", { scope: "./" }).catch(() => { }); } catch (e) { }
  checkWebUpdate();                                   // 지금 버전을 기준으로 적어 둡니다
  setInterval(checkWebUpdate, 30 * 60 * 1000);        // 30분마다 새 게시 확인
  setTimeout(() => checkApkUpdate(false), 4000);
  if (isNative()) {
    try { Capacitor.Plugins.App.getInfo().then(i => { apkVerInfo = Object.assign({ latest: null }, apkVerInfo, { installed: i.version }); paintVersion(); }); } catch (e) { }
  }
}
if (typeof document !== "undefined") boot();

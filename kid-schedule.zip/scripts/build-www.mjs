/* scripts/build-www.mjs
 *
 * 저장소 루트에 있는 앱 파일을 www/ 로 복사합니다.
 * 루트를 그대로 두는 이유: GitHub Pages가 루트에서 배포되고 있어서,
 * 소스를 www/ 로 옮기면 Pages 주소가 깨집니다. 한 소스로 웹과 APK를 같이 냅니다.
 *
 * APK 안에서는 GitHub Pages를 거치지 않고 로컬 파일을 읽으므로
 * schedule.json / config.json 도 함께 넣습니다(최초 기본값). 이후엔 API로 받아옵니다.
 */
import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const OUT = path.join(ROOT, "www");

const FILES = [
  "index.html", "styles.css", "github.js", "app.js", "native.js",
  "manifest.webmanifest", "config.json", "schedule.json", "holidays.json", "vendor/qrcode.js", "offline.html",
  "icon-192.png", "icon-512.png", "icon-512-maskable.png"
];
// 서비스 워커는 APK에 넣지 않습니다. 웹뷰에서 캐시가 겹치면 갱신이 꼬입니다.
const WEB_ONLY = ["sw.js"];

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

let n = 0;
for (const f of FILES) {
  const src = path.join(ROOT, f);
  if (!fs.existsSync(src)) {
    console.error(`  없음: ${f}`);
    process.exitCode = 1;
    continue;
  }
  fs.mkdirSync(path.dirname(path.join(OUT, f)), { recursive: true });
  fs.copyFileSync(src, path.join(OUT, f));
  n++;
}

// index.html 은 이미 native.js 를 app.js 앞에서 불러옵니다.
// APK 안에서는 서비스 워커를 쓰지 않으므로 등록 코드가 있어도 무해합니다(웹뷰에서 실패하고 넘어감).

/* ---- 원격 모드 ----
 * APK 가 화면 코드를 GitHub Pages 에서 받아 오게 합니다. 그러면 화면·기능을 고쳐도
 * zip 만 올리면 폰에 자동 반영되고, APK 재설치는 네이티브(알림·위치·아이콘)가 바뀔 때만 필요합니다.
 * 플러그인은 server.url 출처에만 주입되므로(Capacitor Bridge.loadWebView) 반드시 server.url 로 지정합니다.
 * 처음 열 때 인터넷이 없으면 errorPath(offline.html, APK 안에 있음)를 보여 줍니다.
 * CAP_BUNDLED=1 로 빌드하면 예전처럼 코드를 APK 안에 넣습니다.
 */
{
  const conf = JSON.parse(fs.readFileSync(path.join(ROOT, "config.json"), "utf8"));
  const owner = String(conf.owner || "").toLowerCase(), repo = String(conf.repo || "");
  const url = (conf.pagesUrl && conf.pagesUrl.replace(/\/?$/, "/")) ||
    (repo.toLowerCase() === `${owner}.github.io` ? `https://${owner}.github.io/` : `https://${owner}.github.io/${repo}/`);
  const capFile = path.join(ROOT, "capacitor.config.json");
  const cap = JSON.parse(fs.readFileSync(capFile, "utf8"));
  if (process.env.CAP_BUNDLED === "1") {
    if (cap.server) { delete cap.server.url; delete cap.server.errorPath; }
    console.log("APK 모드: 코드를 APK 안에 넣음(CAP_BUNDLED=1)");
  } else {
    cap.server = Object.assign({}, cap.server, { url, errorPath: "offline.html" });
    console.log(`APK 모드: 원격 — ${url} 에서 화면 코드를 받습니다`);
  }
  fs.writeFileSync(capFile, JSON.stringify(cap, null, 2) + "\n");
  const off = path.join(OUT, "offline.html");
  fs.writeFileSync(off, fs.readFileSync(off, "utf8").replace(/__PAGES_URL__/g, url));
}

console.log(`www/ 생성 — ${n}개 파일 (${WEB_ONLY.join(", ")} 제외)`);

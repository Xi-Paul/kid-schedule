/* scripts/native-fingerprint.mjs — APK 에 들어가는 "네이티브 부분"의 지문.
 *
 * APK 는 원격 모드라 화면·기능 코드(app.js 등)는 GitHub Pages 에서 받아 옵니다.
 * 그래서 APK 를 새로 만들 필요가 있는 건 아래 파일이 바뀔 때뿐입니다.
 * 이 지문이 지난 Release 와 같으면 APK 를 만들지 않고, 다르면 버전을 올려 새로 만듭니다.
 *
 *   capacitor.config.json   앱 이름·플러그인 설정
 *   package.json            플러그인 목록(dependencies)만 — version 등 나머지는 무시
 *   android-res/**          런처 아이콘
 *   scripts/patch-android.mjs, scripts/build-www.mjs   권한·서명·원격 주소 주입
 *   offline.html            APK 안에 들어가는 오프라인 안내
 *   config.json 의 owner/repo/pagesUrl   원격 주소가 여기서 정해짐
 *
 * 사용: node scripts/native-fingerprint.mjs   → 64자 hex 한 줄
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const ROOT = process.cwd();
const h = crypto.createHash("sha256");
const add = (label, data) => { h.update(label + "\0"); h.update(data); h.update("\0"); };

function walk(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
}

for (const f of ["capacitor.config.json", "scripts/patch-android.mjs", "scripts/build-www.mjs", "offline.html"]) {
  const p = path.join(ROOT, f);
  add(f, fs.existsSync(p) ? fs.readFileSync(p) : "(없음)");
}
{
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
  add("package.json#deps", JSON.stringify({ d: pkg.dependencies || {}, dd: pkg.devDependencies || {} }));
}
{
  const c = JSON.parse(fs.readFileSync(path.join(ROOT, "config.json"), "utf8"));
  add("config.json#remote", JSON.stringify({ o: c.owner, r: c.repo, u: c.pagesUrl || null }));
}
for (const p of walk(path.join(ROOT, "android-res")).sort()) {
  add(path.relative(ROOT, p).split(path.sep).join("/"), fs.readFileSync(p));
}
process.stdout.write(h.digest("hex") + "\n");
